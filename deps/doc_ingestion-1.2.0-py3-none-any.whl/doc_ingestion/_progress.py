"""進捗コールバックユーティリティ。"""


def _cb_progress(step_callback, prog: float, msg: str) -> None:
    """callbackを安全に呼び出し、例外による解析処理への影響を防ぐ。

    Args:
        step_callback: RagFlowのコールバック関数。
        prog: 進捗率 (0.0〜1.0)。
        msg: ステップ情報メッセージ。
    """
    if step_callback is not None:
        try:
            step_callback(prog, msg)
        except Exception:
            pass
