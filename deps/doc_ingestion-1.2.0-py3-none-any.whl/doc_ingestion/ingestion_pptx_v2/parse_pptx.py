"""
pptx直接パースモジュール

python-pptx を使用して PPTX ファイルから直接テキストを抽出し、
Markdown 形式に変換する。

変換ルール:
- セクション → 見出し1 (# )
- スライドタイトル → 見出し2 (## )
- 表形式 → Markdown テーブル
- 発表者メモ (ノート) → 引用 (>) として本文の後に出力
- ページ番号 → <!-- page:N --> コメント (チャンキング用)

非テキスト要素 (画像 / 図表 / SmartArt 等のオブジェクト) は
Markdown 化せず stats としてカウントのみ行う。
"""

import logging
from pathlib import Path

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.shapes.graphfrm import GraphicFrame

logger = logging.getLogger(__name__)

# PowerPoint 2010+ セクション用名前空間
_NS_P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"


# セクション見出しレイアウトの判定キーワード (日本語/英語)
_SECTION_LAYOUT_KEYWORDS = ("セクション見出し", "section header", "section")


def _is_section_layout(layout_name: str) -> bool:
    """スライドレイアウト名がセクション見出しかどうかを判定する。"""
    name_lower = layout_name.strip().lower()
    return any(kw in name_lower for kw in _SECTION_LAYOUT_KEYWORDS)


def _extract_sections(prs):
    """プレゼンテーションからセクション情報を抽出する。

    以下の2つの方法でセクションを検出する:
    1. XML セクション定義 (presentation.xml 内の p14:sectionLst)
    2. スライドレイアウト名が「セクション見出し」のスライド (フォールバック)

    Returns:
        dict: {slide_index: section_name} のマッピング。
              セクションが未定義の場合は空辞書。
    """
    # 方法1: XML セクション定義から取得
    result = _extract_sections_from_xml(prs)
    if result:
        return result

    # 方法2: スライドレイアウト名から検出 (フォールバック)
    return _extract_sections_from_layout(prs)


def _extract_sections_from_xml(prs):
    """XML の p14:sectionLst からセクション情報を取得する。"""
    try:
        prs_elem = prs._element
        section_elems = prs_elem.findall(f".//{{{_NS_P14}}}section")
        if not section_elems:
            return {}

        slide_id_to_index = {}
        for i, slide in enumerate(prs.slides):
            slide_id_to_index[slide.slide_id] = i

        result = {}
        for section_elem in section_elems:
            section_name = section_elem.get("name", "").strip()
            if not section_name:
                continue
            sld_id_elems = section_elem.findall(f".//{{{_NS_P14}}}sldId")
            first_slide_index = None
            for sld_id_elem in sld_id_elems:
                sid_str = sld_id_elem.get("id", "")
                try:
                    sid = int(sid_str)
                    slide_index = slide_id_to_index.get(sid)
                    if slide_index is not None and (first_slide_index is None or slide_index < first_slide_index):
                        first_slide_index = slide_index
                except ValueError:
                    continue
            if first_slide_index is not None:
                result[first_slide_index] = section_name
        return result
    except Exception as e:
        logger.warning(f"XMLセクション情報の取得に失敗 (継続): {e}")
        return {}


def _extract_sections_from_layout(prs):
    """スライドレイアウト名が「セクション見出し」のスライドを検出する。

    セクション名はスライドタイトルのテキストを使用する。
    """
    result = {}
    for i, slide in enumerate(prs.slides):
        layout_name = slide.slide_layout.name
        if _is_section_layout(layout_name):
            title_text = ""
            if slide.shapes.title and slide.shapes.title.has_text_frame:
                title_text = slide.shapes.title.text.strip()
            if title_text:
                result[i] = title_text
    return result


def _table_to_markdown(table):
    """pptx Table オブジェクトを Markdown テーブルに変換する。

    結合セルは is_merge_origin で判定し、非起点セルは空文字として出力する。
    """
    if len(table.rows) == 0 or len(table.columns) == 0:
        return ""

    num_rows = len(table.rows)
    num_cols = len(table.columns)

    # 結合セルの非起点位置を特定
    covered = set()
    for row_idx in range(num_rows):
        for col_idx in range(num_cols):
            cell = table.cell(row_idx, col_idx)
            if cell.is_merge_origin:
                for r in range(row_idx, row_idx + cell.span_height):
                    for c in range(col_idx, col_idx + cell.span_width):
                        if (r, c) != (row_idx, col_idx):
                            covered.add((r, c))

    rows = []
    for row_idx in range(num_rows):
        cells = []
        for col_idx in range(num_cols):
            if (row_idx, col_idx) in covered:
                cells.append("")
            else:
                cell = table.cell(row_idx, col_idx)
                text = cell.text.replace("\n", " ").replace("|", "\\|").strip()
                cells.append(text)
        rows.append(cells)

    if not rows:
        return ""

    col_count = len(rows[0])
    md_lines = []
    # ヘッダー行
    md_lines.append("| " + " | ".join(rows[0]) + " |")
    md_lines.append("| " + " | ".join(["---"] * col_count) + " |")
    # データ行
    for row in rows[1:]:
        padded = row[:col_count] + [""] * max(0, col_count - len(row))
        md_lines.append("| " + " | ".join(padded) + " |")

    return "\n".join(md_lines)


def _extract_shape_text(shape):
    """Shape からテキストを抽出する。

    対応するシェイプ種別:
    - テキストフレーム (段落・箇条書き)
    - テーブル (Markdown テーブル形式)
    - グループシェイプ (再帰的に処理)

    Returns:
        str: 抽出されたテキスト (空の場合は空文字列)
    """
    if shape.has_table:
        return _table_to_markdown(shape.table)

    if shape.has_text_frame:
        paragraphs = []
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            if para.level and para.level > 0:
                indent = "  " * para.level
                paragraphs.append(f"{indent}- {text}")
            else:
                paragraphs.append(text)
        return "\n".join(paragraphs)

    # グループシェイプの場合は子シェイプを再帰処理
    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        texts = []
        for child_shape in shape.shapes:
            t = _extract_shape_text(child_shape)
            if t:
                texts.append(t)
        return "\n".join(texts)

    return ""


def _extract_notes_text(slide) -> str:
    """スライドの発表者メモ (ノート) を抽出する。

    has_notes_slide でガードし、ノートが無いスライドにアクセスして
    notes part を生成してしまう副作用を避ける。
    """
    if not slide.has_notes_slide:
        return ""
    notes_frame = slide.notes_slide.notes_text_frame
    if notes_frame is None:
        return ""
    return notes_frame.text.strip()


def _append_notes(md_lines: list, slide) -> None:
    """発表者メモを引用 (>) として md_lines の末尾に追加する"""
    notes_text = _extract_notes_text(slide)
    if not notes_text:
        return
    if md_lines and md_lines[-1] != "":
        md_lines.append("")
    for line in notes_text.splitlines():
        md_lines.append(f"> {line}".rstrip())
    md_lines.append("")


def _empty_stats() -> dict:
    """未変換要素カウントのゼロ値 (キーは固定)"""
    return {"images": 0, "charts": 0, "objects": 0}


def _count_shape_stats(shapes, stats: dict) -> None:
    """シェイプツリーを走査して画像 / 図表 / オブジェクトを数える。

    objects は非図表の graphicFrame (SmartArt / OLE オブジェクト)。
    グループシェイプは再帰的に走査する。
    """
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            _count_shape_stats(shape.shapes, stats)
        elif shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            stats["images"] += 1
        elif isinstance(shape, GraphicFrame):
            if shape.has_chart:
                stats["charts"] += 1
            elif not shape.has_table:
                # 表は Markdown 化されるため、非図表 = SmartArt / OLE のみ数える
                stats["objects"] += 1


def _collect_stats(prs) -> dict:
    """プレゼンテーション全体の未変換要素 (画像 / 図表 / オブジェクト) を数える"""
    stats = _empty_stats()
    for slide in prs.slides:
        _count_shape_stats(slide.shapes, stats)
    return stats


def parse_pptx(file_path: str, output_path: str) -> tuple[bool, dict]:
    """PPTX ファイルを直接パースして Markdown ファイルに変換する。

    Args:
        file_path: 入力 PPTX ファイルパス
        output_path: 出力 Markdown ファイルパス

    Returns:
        (成功フラグ, stats)。失敗時は (False, stats)。
        stats は Markdown 化しなかった要素のカウント (キー固定):
        images / charts / objects (int、無しは 0)。
        objects は非図表 graphicFrame (SmartArt / OLE)。
    """
    input_p = Path(file_path)
    output_p = Path(output_path)

    if not input_p.exists():
        logger.error(f"ファイルが見つかりません: {file_path}")
        return False, _empty_stats()

    try:
        prs = Presentation(str(input_p))
    except Exception as e:
        logger.error(f"PPTX ファイルの読み込みに失敗: {file_path} - {e}")
        return False, _empty_stats()

    # 未変換要素 (画像 / 図表 / オブジェクト) を数える
    stats = _collect_stats(prs)

    # セクション情報を取得
    sections = _extract_sections(prs)
    section_count = len(set(sections.values())) if sections else 0
    logger.info(f"セクション数: {section_count}, スライド数: {len(prs.slides)}")

    md_lines = []
    current_section = None

    for slide_idx, slide in enumerate(prs.slides):
        page_num = slide_idx + 1
        is_section_slide = slide_idx in sections

        # セクション見出し (H1) — セクションが変わったときのみ出力
        section_name = sections.get(slide_idx)
        if section_name and section_name != current_section:
            current_section = section_name
            if md_lines:
                md_lines.append("")
            md_lines.append(f"# {section_name}")
            md_lines.append("")

        # ページ番号マーカー (チャンキング時にメタデータとして利用)
        md_lines.append(f"<!-- page:{page_num} -->")

        # セクション見出しスライドはH1で出力済みなのでH2を出さない
        if is_section_slide:
            # セクションスライドの本文 (サブタイトル等) のみ出力
            shapes = sorted(slide.shapes, key=lambda s: (s.top or 0, s.left or 0))
            title_shape = slide.shapes.title
            for shape in shapes:
                if title_shape is not None and shape.shape_id == title_shape.shape_id:
                    continue
                text = _extract_shape_text(shape)
                if text:
                    md_lines.append(text)
                    md_lines.append("")
            _append_notes(md_lines, slide)
            continue

        # スライドタイトル (H2)
        title_shape = slide.shapes.title
        title_text = ""
        if title_shape and title_shape.has_text_frame:
            title_text = title_shape.text.strip()

        if title_text:
            md_lines.append(f"## {title_text}")
        else:
            md_lines.append(f"## ページ {page_num}")
        md_lines.append("")

        # シェイプを Y 座標 → X 座標順にソート (読み順)
        shapes = sorted(slide.shapes, key=lambda s: (s.top or 0, s.left or 0))

        for shape in shapes:
            # タイトルシェイプは処理済みなのでスキップ
            if title_shape is not None and shape.shape_id == title_shape.shape_id:
                continue

            text = _extract_shape_text(shape)
            if text:
                md_lines.append(text)
                md_lines.append("")

        # 発表者メモ (ノート)
        _append_notes(md_lines, slide)

    # Markdown テキストを結合
    md_text = "\n".join(md_lines)

    if not md_text.strip():
        logger.warning(f"テキストが抽出できませんでした: {file_path}")
        return False, stats

    output_p.parent.mkdir(parents=True, exist_ok=True)
    output_p.write_text(md_text, encoding="utf-8")
    logger.info(f"PPTX パース完了: {file_path} -> {output_path}")

    return True, stats
