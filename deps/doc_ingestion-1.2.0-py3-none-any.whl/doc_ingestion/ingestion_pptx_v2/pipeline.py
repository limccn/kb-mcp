#!/usr/bin/env python3
"""
ingestion_pptx — pptx 前処理

処理フロー:
1. パース (pptx → Markdown via python-pptx)
2. チャンキング (Markdown → JSON)

python-pptx を使用して PPTX ファイルから直接テキストを抽出する。
- セクション → 見出し1
- スライドタイトル → 見出し2
- 表形式 → Markdown テーブル
- チャンクメタデータに見出しとページ番号を含む

クレンジングは pptx 非対応のためスキップ。
"""

import json
import logging
import time
from datetime import datetime
from pathlib import Path

from .._progress import _cb_progress
from .chunking_pptx import chunk_markdown_pptx
from .parse_pptx import parse_pptx

logger = logging.getLogger(__name__)


def run(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict | None = None,
    step_callback: callable = None,
) -> None:
    """pptx 前処理パイプラインを実行する。

    Args:
        input_path: 入力ファイルパス (.pptx)。
        work_dir: ワークディレクトリパス。
        output_md_path: 出力パースファイルパス (.md)。
        output_chunk_path: 出力チャンクファイルパス (.json)。
        config: 設定辞書。chunking セクションを含む。
        step_callback: 進捗通知用コールバック関数 (prog: float, msg: str) -> None。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        RuntimeError: 各処理ステップが失敗した場合。
    """
    config = config or {}
    input_p = Path(input_path).resolve()
    work_p = Path(work_dir).resolve()
    output_md_p = Path(output_md_path).resolve()
    output_chunk_p = Path(output_chunk_path).resolve()

    if not input_p.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    work_p.mkdir(parents=True, exist_ok=True)

    processing_times: dict = {}

    # --------------------------------------------------
    # 1. パース (pptx → Markdown via python-pptx)
    # --------------------------------------------------
    output_md_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[1/2] パース (python-pptx): {input_p.name} -> {output_md_p.name}")
    _cb_progress(step_callback, 0.20, f"[1/2] パース (python-pptx): {input_p.name} -> {output_md_p.name}")
    s = time.time()
    success, _stats = parse_pptx(str(input_p), str(output_md_p))
    elapsed = time.time() - s
    if not success:
        _cb_progress(step_callback, -1, f"[1/2] パース失敗: {input_p}")
        raise RuntimeError(f"[1/2] パース失敗: {input_p}")
    processing_times["1_parse_pptx"] = round(elapsed, 2)
    logger.info(f"[1/2] パース完了 ({elapsed:.1f}s): {output_md_p}")
    _cb_progress(step_callback, 0.40, f"[1/2] パース完了 ({elapsed:.1f}s): {output_md_p.name}")

    # --------------------------------------------------
    # 2. チャンキング (Markdown → JSON) — pptx専用分割
    # --------------------------------------------------
    output_chunk_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[2/2] チャンキング (pptx): {output_md_p.name} -> {output_chunk_p.name}")
    _cb_progress(step_callback, 0.45, f"[2/2] チャンキング (pptx): {output_md_p.name} -> {output_chunk_p.name}")
    chunking_config = config.get("chunking", {})
    chunk_size = chunking_config.get("chunk_size", 8192)
    chunk_overlap = chunking_config.get("chunk_overlap", 200)
    intermediate_md_p = work_p / "chunking_intermediate.md"
    s = time.time()
    chunks = chunk_markdown_pptx(
        str(output_md_p),
        str(output_chunk_p),
        intermediate_md_path=str(intermediate_md_p),
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    elapsed = time.time() - s
    processing_times["2_chunking"] = round(elapsed, 2)
    logger.info(f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク -> {output_chunk_p}")
    _cb_progress(step_callback, 0.60, f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク")

    # --------------------------------------------------
    # 処理時間の記録 (work/processing_time.json)
    # --------------------------------------------------
    if processing_times:
        _save_processing_times(work_p, input_p, processing_times)

    logger.info(f"[pptx] 前処理パイプライン完了: {input_path}")


def _save_processing_times(work_p: Path, input_p: Path, processing_times: dict) -> None:
    time_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input": str(input_p),
        "steps": processing_times,
    }
    time_json_p = work_p / "processing_time.json"
    existing: list = []
    if time_json_p.exists():
        try:
            with open(time_json_p, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                existing = [existing]
        except Exception:
            existing = []
    existing.append(time_record)
    with open(time_json_p, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
    logger.info(f"処理時間を記録しました: {time_json_p}")
