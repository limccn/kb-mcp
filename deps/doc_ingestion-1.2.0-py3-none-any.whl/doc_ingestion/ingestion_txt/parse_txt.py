"""TXT 汎用パーサー

エンコーディングを順に試して読み込む:
utf-8-sig → utf-8 → cp932 → cp1252
改行コードは LF に統一する。
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# 試行するエンコーディング (順序固定)
_ENCODINGS = ("utf-8-sig", "utf-8", "cp932", "cp1252")


def parse_txt(file_path: str) -> str:
    """TXT ファイルを読み込み、テキストを返す。

    Args:
        file_path: 入力テキストファイルパス。

    Returns:
        str: ファイル内容 (改行 LF 統一)。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        ValueError: いずれのエンコーディングでもデコードできない場合。
    """
    txt_p = Path(file_path)
    if not txt_p.exists():
        raise FileNotFoundError(f"Input file not found: {file_path}")

    raw_bytes = txt_p.read_bytes()
    for encoding in _ENCODINGS:
        try:
            text = raw_bytes.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError(
            f"テキストをデコードできません (試行: {', '.join(_ENCODINGS)}): {file_path}"
        )

    logger.info(f"[txt] 読み込み完了 ({encoding}): {txt_p.name}")
    return text.replace("\r\n", "\n").replace("\r", "\n")
