#!/usr/bin/env python3
"""
ingestion_txt — txt 前処理

処理フロー:
1. パース (txt → テキスト、エンコーディング自動判定)
2. チャンキング (テキスト → JSON、ingestion_json と同形)

"""

import json
import logging
import time
from datetime import datetime
from pathlib import Path

from .parse_txt import parse_txt
from .chunk_txt import generate_chunks
from .._progress import _cb_progress

logger = logging.getLogger(__name__)


def run(
    input_path,
    work_dir,
    output_md_path,
    output_chunk_path,
    config=None,
    step_callback=None,
):
    config = config or {}
    input_p = Path(input_path).resolve()
    work_p = Path(work_dir).resolve()
    output_md_p = Path(output_md_path).resolve()
    output_chunk_p = Path(output_chunk_path).resolve()

    if not input_p.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    work_p.mkdir(parents=True, exist_ok=True)
    output_md_p.parent.mkdir(parents=True, exist_ok=True)
    output_chunk_p.parent.mkdir(parents=True, exist_ok=True)

    processing_times = {}

    logger.info(f"[1/2] Parse (txt): {input_p.name}")
    _cb_progress(step_callback, 0.10, f"[1/2] Parse: {input_p.name}")
    s = time.time()
    text = parse_txt(str(input_p))
    elapsed = time.time() - s
    processing_times["1_parse"] = round(elapsed, 2)
    logger.info(f"[1/2] Parse done ({elapsed:.1f}s): {len(text)} chars")
    _cb_progress(step_callback, 0.40, f"[1/2] Parse done ({elapsed:.1f}s)")

    output_md_p.write_text(text, encoding="utf-8")
    logger.info(f"Txt written: {output_md_p} ({len(text)} chars)")

    logger.info(f"[2/2] Chunk: {input_p.name}")
    _cb_progress(step_callback, 0.50, "[2/2] Chunking")
    chunking_config = config.get("chunking", {})
    chunk_size = chunking_config.get("chunk_size", 8192)
    chunk_overlap = chunking_config.get("chunk_overlap", 200)
    s = time.time()
    chunks, warnings = generate_chunks(text, chunk_size=chunk_size)
    elapsed = time.time() - s
    processing_times["2_chunk"] = round(elapsed, 2)
    logger.info(f"[2/2] Chunk done ({elapsed:.1f}s): {len(chunks)} chunks")
    _cb_progress(step_callback, 0.75, f"[2/2] Chunk done: {len(chunks)} chunks")

    out_data = {
        "input_file": input_p.name,
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "total_chunks": len(chunks),
        "warnings": warnings,
        "chunks": chunks,
    }
    with open(output_chunk_p, "w", encoding="utf-8") as f:
        json.dump(out_data, f, ensure_ascii=False, indent=2)
    logger.info(f"Chunk JSON written: {output_chunk_p}")

    if processing_times:
        _save_processing_times(work_p, input_p, processing_times)

    _cb_progress(step_callback, 1.0, f"Done: {input_p.name}")
    logger.info(f"Pipeline complete: {input_path}")


def _save_processing_times(work_p, input_p, processing_times):
    time_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input": str(input_p),
        "steps": processing_times,
    }
    time_json_p = work_p / "processing_time.json"
    existing = []
    if time_json_p.exists():
        try:
            with open(time_json_p, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                existing = [existing]
        except Exception:
            existing = []
    existing.append(time_record)
    with open(time_json_p, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
