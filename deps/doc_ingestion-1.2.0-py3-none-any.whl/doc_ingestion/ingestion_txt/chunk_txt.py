"""TXT チャンキング

チャンク JSON の形態は ingestion_json と同形
(chunk_id / metadata / content_length / content / token_count)。
"""

import logging

import tiktoken

logger = logging.getLogger(__name__)

_ENC_NAME = "cl100k_base"


def _count_tokens(text: str) -> int:
    return len(tiktoken.get_encoding(_ENC_NAME).encode(text))


def generate_chunks(
    text: str,
    chunk_size: int = 8192,
) -> tuple[list[dict], list[str]]:
    """テキストを行単位でトークン数 chunk_size 以下のチャンクに分割する。

    1 行だけで chunk_size を超える場合は単独チャンクとし warning を記録する。

    Returns:
        (chunks, warnings)
    """
    lines = text.splitlines()
    chunks: list[dict] = []
    warnings: list[str] = []

    def _flush(start_line: int, end_line: int, buf: list[str]) -> None:
        content = "\n".join(buf)
        token_count = _count_tokens(content)
        if token_count > chunk_size:
            msg = f"WARNING: Chunk {len(chunks) + 1} tokens={token_count} > chunk_size={chunk_size}"
            warnings.append(msg)
            logger.warning(msg)
        chunks.append(
            {
                "chunk_id": len(chunks) + 1,
                "metadata": f"L{start_line}-{end_line}",
                "content_length": len(content),
                "content": content,
                "token_count": token_count,
            }
        )

    start_line = None
    buf: list[str] = []
    buf_tokens = 0
    for line_no, line in enumerate(lines, start=1):
        line_tokens = _count_tokens(line) + 1  # 改行分
        if buf and start_line is not None and buf_tokens + line_tokens > chunk_size:
            _flush(start_line, line_no - 1, buf)
            start_line = None
            buf = []
            buf_tokens = 0
        if start_line is None:
            start_line = line_no
        buf.append(line)
        buf_tokens += line_tokens

    if buf and start_line is not None:
        _flush(start_line, len(lines), buf)

    return chunks, warnings
