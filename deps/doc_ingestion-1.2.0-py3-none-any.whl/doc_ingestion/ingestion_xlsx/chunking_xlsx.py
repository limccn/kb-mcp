"""
xlsx向けMarkdownチャンキングモジュール

xlsx から変換された Markdown は見出し(H1/H2)が少なく、
1シート分の大量データが1つの H2 セクションに入ることが多い。
通常の見出しベース分割では 8192 トークンいっぱいで機械的に分断されてしまう。

本モジュールでは以下の戦略でチャンク分割する:
1. 前処理 (preprocess_markdown) を適用
2. H1 / H2 見出しで一次分割
3. トークン上限内のセクションはそのまま 1 チャンク
4. オーバーするセクションは「トップレベル箇条書き(* )」を
   論理レコード境界として認識し、レコード単位でグループ化
5. 各サブチャンクにセクション見出し + ヘッダー行をコンテキストとして付加
"""

import argparse
import json
import logging
import re
from pathlib import Path

import tiktoken
from langchain_text_splitters import RecursiveCharacterTextSplitter

from ..chunking.preprocess_md import preprocess_markdown

logger = logging.getLogger(__name__)

ENCODING_NAME = "cl100k_base"
MAX_CHUNK_COUNT = 512

# データ行の判定パターン: 「* <数字> 」で始まる行 (例: "* 1 R100.0 ...")
_DATA_ROW_RE = re.compile(r"^\* \d+\s")

# Markdownテーブルのセパレータ行 (例: "|---|---|---|")
_TABLE_SEP_RE = re.compile(r"^\s*\|---")

# Markdownテーブルのデータ行 (例: "| 1 | 認証 | ...")
_TABLE_DATA_ROW_RE = re.compile(r"^\s*\|\s*\d+\s*\|")


def _count_tokens(text: str, enc: tiktoken.Encoding | None = None) -> int:
    """tiktoken でトークン数を計算する"""
    if enc is None:
        enc = tiktoken.get_encoding(ENCODING_NAME)
    return len(enc.encode(text))


def _parse_sections(text: str) -> list[dict]:
    """Markdown テキストを H1/H2 見出しでセクションに分割する。

    Returns:
        [{"heading": "## セクション名", "heading_meta": {...}, "body": "本文..."}, ...]
    """
    lines = text.split("\n")
    sections: list[dict] = []
    current_h1 = ""
    current_h2 = ""
    current_heading = ""
    current_lines: list[str] = []

    def _flush():
        if current_lines or current_heading:
            body = "\n".join(current_lines)
            meta = {}
            if current_h1:
                meta["Header 1"] = current_h1
            if current_h2:
                meta["Header 2"] = current_h2
            sections.append(
                {
                    "heading": current_heading,
                    "heading_meta": meta,
                    "body": body,
                }
            )

    for line in lines:
        if line.startswith("# ") and not line.startswith("## "):
            _flush()
            current_h1 = line[2:].strip()
            current_heading = line
            current_lines = []
        elif line.startswith("## ") and not line.startswith("### "):
            _flush()
            current_h2 = line[3:].strip()
            current_heading = line
            current_lines = []
        elif line.startswith("### "):
            # xlsx では preprocess_markdown が章番号なしの H2 を ### に変換する
            _flush()
            current_h2 = line.lstrip("# ").strip()
            current_heading = line
            current_lines = []
        else:
            current_lines.append(line)

    _flush()
    return sections


def _find_header_end(lines: list[str]) -> int:
    """セクション本文のヘッダー部分(カラム定義等)の終了行インデックスを返す。

    ヘッダー部分 = 最初のデータ行より前の行すべて。
    - 箇条書きデータ行: 「* <数字> 」で始まる行の直前
    - Markdownテーブル: セパレータ行 (|---|) の直後
    データ行が見つからない場合は 0 を返す (ヘッダーなし)。
    """
    # Markdownテーブル: セパレータ行の直後がヘッダー終端
    for i, line in enumerate(lines):
        if _TABLE_SEP_RE.match(line):
            return i + 1
    # 箇条書き: 最初のデータ行の直前がヘッダー終端
    for i, line in enumerate(lines):
        if _DATA_ROW_RE.match(line):
            return i
    return 0


def _split_into_bullet_blocks(lines: list[str]) -> list[list[str]]:
    """行リストをレコード単位のブロックに分割する。

    以下のパターンを新規ブロックの開始として認識する:
    - トップレベル箇条書き: 「* 」で始まる行
    - Markdownテーブルデータ行: 「| <数字> |」で始まる行

    インデントされた箇条書き(  * )は直前のブロックに含む。
    上記以外の行は直前のブロックに含む。
    """
    blocks: list[list[str]] = []
    current: list[str] = []

    for line in lines:
        is_block_start = line.startswith("* ") or _TABLE_DATA_ROW_RE.match(line)
        if is_block_start and current:
            blocks.append(current)
            current = [line]
        else:
            current.append(line)

    if current:
        blocks.append(current)

    return blocks


def _group_blocks_by_token_limit(
    blocks: list[list[str]],
    header_text: str,
    heading_text: str,
    chunk_size: int,
    enc: tiktoken.Encoding,
) -> list[str]:
    """ブロックリストをトークン上限に基づいてグループ化し、チャンクテキストのリストを返す。

    各チャンクには heading_text + header_text がプレフィクスとして付加される。
    """
    prefix = ""
    if heading_text:
        prefix += heading_text + "\n"
    if header_text:
        prefix += header_text + "\n"

    prefix_tokens = _count_tokens(prefix, enc) if prefix else 0
    # 結合時のトークン数差異を考慮して安全マージンを設ける
    available = chunk_size - prefix_tokens - 50

    if available < 256:
        # ヘッダーだけでほぼ上限の場合はプレフィクスを簡略化
        prefix = heading_text + "\n" if heading_text else ""
        prefix_tokens = _count_tokens(prefix, enc) if prefix else 0
        available = chunk_size - prefix_tokens

    chunks: list[str] = []
    current_lines: list[str] = []
    current_tokens = 0

    for block in blocks:
        block_text = "\n".join(block)
        block_tokens = _count_tokens(block_text, enc)

        if block_tokens > available:
            # 単一ブロックが上限を超える場合: 現在のバッファをフラッシュし、
            # RecursiveCharacterTextSplitter で再分割する
            if current_lines:
                chunks.append(prefix + "\n".join(current_lines))
                current_lines = []
                current_tokens = 0
            sub_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name=ENCODING_NAME,
                chunk_size=chunk_size - 50,
                chunk_overlap=0,
            )
            sub_texts = sub_splitter.split_text(prefix + block_text)
            chunks.extend(sub_texts)
            continue

        if current_tokens + block_tokens > available:
            # 現在のバッファをフラッシュ
            if current_lines:
                chunks.append(prefix + "\n".join(current_lines))
            current_lines = list(block)
            current_tokens = block_tokens
        else:
            current_lines.extend(block)
            current_tokens += block_tokens

    if current_lines:
        chunks.append(prefix + "\n".join(current_lines))

    return chunks


def _split_oversized_section(
    section: dict,
    chunk_size: int,
    enc: tiktoken.Encoding,
) -> list[dict]:
    """トークン上限を超えたセクションをレコード単位で分割する。

    Returns:
        [{"heading_meta": {...}, "content": "チャンクテキスト"}, ...]
    """
    body_lines = section["body"].split("\n")
    heading_text = section["heading"]
    heading_meta = section["heading_meta"]

    # ヘッダー行 (カラム定義等) を特定
    header_end = _find_header_end(body_lines)
    header_lines = body_lines[:header_end]
    data_lines = body_lines[header_end:]

    header_text = "\n".join(header_lines) if header_lines else ""

    # データ行をトップレベル箇条書きブロックに分割
    blocks = _split_into_bullet_blocks(data_lines)

    if not blocks:
        # データ行がない場合はそのまま返す
        content = heading_text + "\n" + section["body"] if heading_text else section["body"]
        return [{"heading_meta": heading_meta, "content": content}]

    # ブロックをトークン上限に基づいてグループ化
    chunk_texts = _group_blocks_by_token_limit(blocks, header_text, heading_text, chunk_size, enc)

    results = []
    for text in chunk_texts:
        results.append(
            {
                "heading_meta": dict(heading_meta),
                "content": text,
            }
        )

    return results


def validate_chunks(results: list[dict], chunk_size: int) -> list[str]:
    """チャンク結果を検証し、警告メッセージのリストを返す。"""
    enc = tiktoken.get_encoding(ENCODING_NAME)
    warnings = []

    if len(results) >= MAX_CHUNK_COUNT:
        msg = f"WARNING: チャンク数が {MAX_CHUNK_COUNT} 以上です: {len(results)} チャンク"
        warnings.append(msg)
        logger.warning(msg)

    for chunk in results:
        token_count = _count_tokens(chunk["content"], enc)
        chunk["token_count"] = token_count
        if token_count > chunk_size:
            msg = (
                f"WARNING: Chunk {chunk['chunk_id']} のトークン数が chunk_size を超過: "
                f"{token_count} > {chunk_size}"
            )
            warnings.append(msg)
            logger.warning(msg)

    return warnings


def chunk_markdown_xlsx(
    input_md_path: str,
    output_json_path: str,
    intermediate_md_path: str | None = None,
    chunk_size: int = 8192,
    chunk_overlap: int = 200,
) -> list[dict]:
    """xlsx由来のMarkdownファイルをレコード単位でチャンク分割し、JSONファイルに保存する。

    Args:
        input_md_path: 入力Markdownファイルのパス
        output_json_path: 出力JSONファイルのパス
        intermediate_md_path: 前処理済みMarkdown中間ファイルの保存パス
        chunk_size: チャンクサイズ（トークン数）
        chunk_overlap: チャンク間の重複（トークン数）※xlsx分割では未使用

    Returns:
        チャンク結果のリスト
    """
    input_path = Path(input_md_path)
    if not input_path.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_md_path}")

    markdown_text = input_path.read_text(encoding="utf-8")
    logger.info(f"入力ファイルを読み込みました: {input_md_path}")

    # 前処理
    preprocessed_text = preprocess_markdown(markdown_text)
    logger.info("前処理完了")

    if intermediate_md_path:
        p = Path(intermediate_md_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(preprocessed_text, encoding="utf-8")
        logger.info(f"中間ファイル保存 [前処理済みMarkdown]: {intermediate_md_path}")

    enc = tiktoken.get_encoding(ENCODING_NAME)

    # H1/H2 でセクション分割
    sections = _parse_sections(preprocessed_text)
    logger.info(f"H1/H2 分割後のセクション数: {len(sections)}")

    # 各セクションをチャンク化
    all_chunks: list[dict] = []
    for section in sections:
        full_text = section["heading"] + "\n" + section["body"] if section["heading"] else section["body"]
        section_tokens = _count_tokens(full_text, enc)

        if section_tokens <= chunk_size:
            # トークン上限内: そのまま 1 チャンク
            content = full_text.strip()
            all_chunks.append(
                {
                    "heading_meta": section["heading_meta"],
                    "content": content,
                }
            )
        else:
            # トークン上限超過: レコード単位で分割
            logger.info(f"セクション分割: {section['heading'][:60]}... " f"({section_tokens} tokens > {chunk_size})")
            sub_chunks = _split_oversized_section(section, chunk_size, enc)
            all_chunks.extend(sub_chunks)
            logger.info(f"  → {len(sub_chunks)} サブチャンクに分割")

    logger.info(f"最終的なチャンク数: {len(all_chunks)}")

    # 結果をリストに変換
    results = []
    for i, chunk in enumerate(all_chunks):
        # metadata にシート名 (H2見出し = Header 2) を記載
        metadata_str = chunk["heading_meta"].get("Header 2", "")
        chunk_data = {
            "chunk_id": i + 1,
            "metadata": metadata_str,
            "content_length": len(chunk["content"]),
            "content": chunk["content"],
        }
        results.append(chunk_data)
        logger.info(f"Chunk {i + 1}: Content length={len(chunk['content'])} characters")

    # 検証
    warnings = validate_chunks(results, chunk_size)

    # JSON 保存
    output_path = Path(output_json_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    output_data = {
        "input_file": str(input_md_path),
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "total_chunks": len(results),
        "warnings": warnings,
        "chunks": results,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    logger.info(f"結果をJSONファイルに保存しました: {output_json_path}")
    return results


def main():
    parser = argparse.ArgumentParser(
        description="xlsx由来のMarkdownファイルをレコード単位でチャンク分割し、JSONファイルに保存する"
    )
    parser.add_argument("--input_md_path", type=str, required=True, help="入力Markdownファイルのパス")
    parser.add_argument("--output_json", type=str, required=True, help="出力JSONファイルのパス")
    parser.add_argument("--chunk_size", type=int, default=8192, help="チャンクサイズ（トークン数、デフォルト: 8192）")
    parser.add_argument(
        "--chunk_overlap", type=int, default=200, help="チャンク間の重複（トークン数、デフォルト: 200）"
    )
    parser.add_argument("--intermediate_md", type=str, default=None, help="前処理済みMarkdown中間ファイルの保存パス")

    args = parser.parse_args()
    chunk_markdown_xlsx(
        input_md_path=args.input_md_path,
        output_json_path=args.output_json,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
        intermediate_md_path=args.intermediate_md,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    main()
