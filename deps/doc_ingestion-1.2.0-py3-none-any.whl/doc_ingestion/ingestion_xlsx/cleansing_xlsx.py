#!/usr/bin/env python3
import argparse
import fnmatch
import io
import logging
import re
import zipfile
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.worksheet.header_footer import _HeaderFooterPart

# ロギング設定
logger = logging.getLogger(__name__)


def write_log(log_file: str, message: str):
    """
    ログファイルにメッセージを追加する

    Args:
        log_file: ログファイルのパス
        message: 記録するメッセージ
    """
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_file, "a", encoding="utf-8") as f:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")


def delete_headers_footers(wb, log_file: str = None):
    """
    全シートのヘッダーとフッターを削除する
    """
    removed_count = 0
    deleted_items = []
    for sheet in wb.worksheets:
        # ヘッダーの削除（left, center, rightの各部分）
        for header in [sheet.oddHeader, sheet.evenHeader, sheet.firstHeader]:
            if header:
                if header.left and header.left.text:
                    deleted_items.append(f"Header (left) in {sheet.title}: {header.left.text[:50]}")
                    header.left = _HeaderFooterPart()
                    removed_count += 1
                if header.center and header.center.text:
                    deleted_items.append(f"Header (center) in {sheet.title}: {header.center.text[:50]}")
                    header.center = _HeaderFooterPart()
                    removed_count += 1
                if header.right and header.right.text:
                    deleted_items.append(f"Header (right) in {sheet.title}: {header.right.text[:50]}")
                    header.right = _HeaderFooterPart()
                    removed_count += 1

        # フッターの削除
        for footer in [sheet.oddFooter, sheet.evenFooter, sheet.firstFooter]:
            if footer:
                if footer.left and footer.left.text:
                    deleted_items.append(f"Footer (left) in {sheet.title}: {footer.left.text[:50]}")
                    footer.left = _HeaderFooterPart()
                    removed_count += 1
                if footer.center and footer.center.text:
                    deleted_items.append(f"Footer (center) in {sheet.title}: {footer.center.text[:50]}")
                    footer.center = _HeaderFooterPart()
                    removed_count += 1
                if footer.right and footer.right.text:
                    deleted_items.append(f"Footer (right) in {sheet.title}: {footer.right.text[:50]}")
                    footer.right = _HeaderFooterPart()
                    removed_count += 1

    if removed_count > 0:
        logger.info(f"ヘッダー・フッターを {removed_count} 件削除しました。")
        if log_file:
            write_log(log_file, f"[XLSX] ヘッダー・フッター削除: {removed_count}件")
            for item in deleted_items[:10]:  # 最初の10件を記録
                write_log(log_file, f"  - {item}")
            for item in deleted_items[:10]:  # 最初の10件を記録
                write_log(log_file, f"  - {item}")


def list_sheets(wb):
    """
    ワークブック内のシート名を列挙して表示する
    """
    logger.info("=== シート一覧 ===")
    for i, sheet_name in enumerate(wb.sheetnames, 1):
        logger.info(f"{i:3d}: {sheet_name}")
    logger.info("=== シート一覧 終了 ===")


def delete_sheets_by_keywords(wb, keywords, log_file: str = None):
    """
    指定したキーワードパターンに一致するシート名のシートを削除する
    ワイルドカード（*、?）をサポート

    Args:
        wb: openpyxlのWorkbookオブジェクト
        keywords: 削除対象のシート名パターンのリスト（例: ['表紙', '目次*', '(廃止)*']）
                 * は任意の文字列、? は任意の1文字にマッチ
        log_file: ログファイルのパス
    """
    if not keywords:
        return

    # キーワードを正規化（空白除去）
    normalized_keywords = [kw.strip() for kw in keywords]

    sheets_to_delete = []
    for sheet_name in wb.sheetnames:
        normalized_sheet_name = sheet_name.strip()
        # 各パターンとマッチングを試行
        for pattern in normalized_keywords:
            if fnmatch.fnmatchcase(normalized_sheet_name, pattern):
                if sheet_name not in sheets_to_delete:  # 重複チェック
                    sheets_to_delete.append(sheet_name)
                    logger.info(f"削除対象シートを検出: '{sheet_name}' (パターン: '{pattern}')")
                break  # マッチしたら次のシートへ

    # シート削除実行
    for sheet_name in sheets_to_delete:
        wb.remove(wb[sheet_name])
        logger.info(f"シート '{sheet_name}' を削除しました。")

    # すべてのシートが削除された場合の処理
    if len(wb.sheetnames) == 0:
        logger.warning("すべてのシートが削除されました。空のシートを作成します。")
        wb.create_sheet("Sheet1")
        if log_file:
            write_log(log_file, "[XLSX] 警告: すべてのシートが削除され、空のシートを作成しました")

    if sheets_to_delete and log_file:
        write_log(log_file, f"[XLSX] シート削除: {len(sheets_to_delete)}件")
        for sheet_name in sheets_to_delete:
            write_log(log_file, f"  - {sheet_name}")


def _repair_xlsx_xml(input_path: Path) -> io.BytesIO:
    """
    xlsx ファイルの内部 XML に含まれる未エスケープの & を &amp; に変換して
    BytesIO として返す。
    """
    buf = io.BytesIO()
    # & の後がエンティティ参照形式（英数字 or # + ';'）でないものを置換
    pattern = re.compile(r"&(?!(?:[a-zA-Z][a-zA-Z0-9]*|#[0-9]+|#x[0-9a-fA-F]+);)")
    with zipfile.ZipFile(input_path, "r") as zin, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith(".xml") or item.filename.endswith(".rels"):
                try:
                    text = data.decode("utf-8")
                    text = pattern.sub("&amp;", text)
                    data = text.encode("utf-8")
                except UnicodeDecodeError:
                    pass  # バイナリのままにする
            zout.writestr(item, data)
    buf.seek(0)
    return buf


def _load_workbook_with_repair(input_path):
    """
    openpyxl で xlsx を読み込む。XML パースエラーが発生した場合は
    内部 XML を修復してリトライする。
    """
    try:
        return load_workbook(input_path)
    except Exception as first_err:
        err_msg = str(first_err)
        if "EntityRef" in err_msg or "xmlParseEntityRef" in err_msg or "expecting ';'" in err_msg:
            logger.warning(f"XML パースエラーを検出。& エスケープ修復を試みます: {first_err}")
            try:
                repaired = _repair_xlsx_xml(Path(input_path))
                return load_workbook(repaired)
            except Exception as repair_err:
                logger.error(f"修復後も読み込めませんでした: {repair_err}")
                raise repair_err
        raise


def clensing_xlsx(input_path, output_path, sheets_to_delete=None, show_sheets=False, log_file=None):
    """
    xlsxファイルのヘッダー、フッター、指定シートを削除する

    Args:
        input_path: 入力xlsxファイルのパス
        output_path: 出力xlsxファイルのパス
        sheets_to_delete: 削除対象のシート名キーワードのリスト（省略時はシート削除をスキップ）
        show_sheets: Trueの場合、シート一覧を表示
        log_file: ログファイルのパス
    """
    if sheets_to_delete is None:
        sheets_to_delete = []

    try:
        wb = _load_workbook_with_repair(input_path)

        logger.info(f"処理対象: {input_path}")
        if log_file:
            write_log(log_file, f"[XLSX] 処理開始: {input_path}")

        # シート一覧表示
        if show_sheets:
            list_sheets(wb)

        logger.info("ヘッダー・フッターを削除中...")
        delete_headers_footers(wb, log_file)

        if sheets_to_delete:
            logger.info(f"指定シートを検索・削除中... 対象: {sheets_to_delete}")
            delete_sheets_by_keywords(wb, sheets_to_delete, log_file)

        wb.save(output_path)
        logger.info(f"完了しました。保存先: {output_path}")
        if log_file:
            write_log(log_file, f"[XLSX] 処理完了: {output_path}")

    except Exception as e:
        logger.error(f"エラーが発生しました: {e}")
        if log_file:
            write_log(log_file, f"[XLSX] エラー: {e}")
        raise e


def main():
    parser = argparse.ArgumentParser(
        description="xlsxファイルのヘッダー、フッター、シートを削除するクレンジングツール"
    )
    parser.add_argument("--input", "-i", required=True, help="入力xlsxファイルのパス")
    parser.add_argument("--output", "-o", required=True, help="出力xlsxファイルのパス")
    parser.add_argument(
        "--delete-sheets",
        "-d",
        nargs="*",
        default=None,
        help="削除対象のシート名パターン（複数指定可、ワイルドカード対応）。例: -d 表紙 目次* (廃止)*",
    )
    parser.add_argument("--list-sheets", "-l", action="store_true", help="シート一覧を表示（デバッグ用）")
    args = parser.parse_args()

    clensing_xlsx(args.input, args.output, args.delete_sheets, args.list_sheets)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    main()
