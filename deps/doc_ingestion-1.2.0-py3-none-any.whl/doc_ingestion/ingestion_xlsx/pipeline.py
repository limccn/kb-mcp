#!/usr/bin/env python3
"""
ingestion_xlsx — xlsx 前処理

処理フロー:
1. クレンジング (xlsx / xlsm。旧形式 .xls は openpyxl 非対応のためスキップ)
2. パース (xlsx / xlsm / xls → Markdown via excel_parser)
3. チャンキング (Markdown → JSON)

"""

import json
import logging
import re
import time
import zipfile
from datetime import datetime
from pathlib import Path

from .excel_parser import ExcelToMarkdownConverter
from .excel_parser.schema import ParserConfig
from .._progress import _cb_progress
from .chunking_xlsx import chunk_markdown_xlsx
from .cleansing_xlsx import clensing_xlsx

logger = logging.getLogger(__name__)

_PITCH_FAMILY_PATTERN = re.compile(r'pitchFamily="(\d+)"')


def _clamp_pitch_family(xml_text: str) -> tuple[str, int]:
    """drawing XML 内の pitchFamily 上限超過値を openpyxl 許容範囲へ丸める。"""
    replaced = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal replaced
        value = int(match.group(1))
        if value <= 52:
            return match.group(0)
        replaced += 1
        return 'pitchFamily="52"'

    return _PITCH_FAMILY_PATTERN.sub(_replace, xml_text), replaced


def _prepare_input_for_openpyxl(input_p: Path, work_p: Path) -> Path:
    """openpyxl 読み込み前に drawing XML の既知の不正値だけを最小補正する。"""
    repaired_entries: dict[str, bytes] = {}

    with zipfile.ZipFile(input_p, "r") as zin:
        for item in zin.infolist():
            if not item.filename.startswith("xl/drawings/") or not item.filename.endswith(".xml"):
                continue

            data = zin.read(item.filename)
            try:
                xml_text = data.decode("utf-8")
            except UnicodeDecodeError:
                continue

            repaired_text, replaced = _clamp_pitch_family(xml_text)
            if replaced:
                repaired_entries[item.filename] = repaired_text.encode("utf-8")

    if not repaired_entries:
        return input_p

    repair_dir = work_p / "input_repair"
    repair_dir.mkdir(parents=True, exist_ok=True)
    repaired_path = repair_dir / f"{input_p.stem}_openpyxl_ready{input_p.suffix}"

    with zipfile.ZipFile(input_p, "r") as zin, zipfile.ZipFile(
        repaired_path, "w", zipfile.ZIP_DEFLATED
    ) as zout:
        for item in zin.infolist():
            data = repaired_entries.get(item.filename, zin.read(item.filename))
            zout.writestr(item, data)

    logger.warning(
        "openpyxl 読み込み互換のため pitchFamily を補正しました: %s (%d XML)",
        input_p.name,
        len(repaired_entries),
    )
    return repaired_path


def run(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict | None = None,
    step_callback: callable = None,
) -> None:
    """xlsx 前処理パイプラインを実行する。

    Args:
        input_path: 入力ファイルパス (.xlsx / .xlsm / .xls)。
        work_dir: ワークディレクトリパス。
        output_md_path: 出力パースファイルパス (.md)。
        output_chunk_path: 出力チャンクファイルパス (.json)。
        config: 設定辞書。clensing / excel_parser / chunking セクションを含む。
        step_callback: 進捗通知用コールバック関数 (prog: float, msg: str) -> None。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        RuntimeError: 各処理ステップが失敗した場合。
    """
    config = config or {}
    input_p = Path(input_path).resolve()
    work_p = Path(work_dir).resolve()
    output_md_p = Path(output_md_path).resolve()
    output_chunk_p = Path(output_chunk_path).resolve()

    if not input_p.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    work_p.mkdir(parents=True, exist_ok=True)

    # openpyxl で読み取れない問題の対応 (xlsx/xlsm のみ。.xls は zip ではないため対象外)
    is_xls = input_p.suffix.lower() == ".xls"
    source_input_p = input_p if is_xls else _prepare_input_for_openpyxl(input_p, work_p)
    cleansing_dir = work_p / "cleansing"
    cleansing_dir.mkdir(exist_ok=True)

    processing_times: dict = {}

    # --------------------------------------------------
    # 1. クレンジング (xlsx) — 旧形式 .xls は openpyxl 非対応のためスキップ
    # --------------------------------------------------
    if is_xls:
        current_path = source_input_p
        logger.info("[1/3] クレンジング: スキップ (.xls は openpyxl 非対応)")
        _cb_progress(step_callback, 0.30, "[1/3] クレンジング: スキップ (.xls)")
    else:
        cleansed_path = cleansing_dir / f"{input_p.stem}_cleansing.xlsx"
        logger.info(f"[1/3] クレンジング: {input_p.name}")
        _cb_progress(step_callback, 0.20, f"[1/3] クレンジング: {input_p.name}")
        cleansing_config = config.get("ingestion", {}).get("xlsx", {})
        xlsx_config = cleansing_config.get("cleansing", {})
        log_file = str(work_p / "cleansing.log")
        s = time.time()
        clensing_xlsx(
            input_path=str(source_input_p),
            output_path=str(cleansed_path),
            sheets_to_delete=xlsx_config.get("sheets", []),
            show_sheets=xlsx_config.get("show", True),
            log_file=log_file,
        )
        elapsed = time.time() - s
        current_path = cleansed_path
        processing_times["1_cleansing"] = round(elapsed, 2)
        logger.info(f"[1/3] クレンジング完了 ({elapsed:.1f}s): {current_path.name}")
        _cb_progress(step_callback, 0.30, f"[1/3] クレンジング完了 ({elapsed:.1f}s): {current_path.name}")

    # --------------------------------------------------
    # 2. パース (xlsx → Markdown via excel_parser)
    # --------------------------------------------------
    output_md_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[2/3] パース (excel_parser): {current_path.name} -> {output_md_p.name}")
    _cb_progress(step_callback, 0.35, f"[2/3] パース (excel_parser): {current_path.name} -> {output_md_p.name}")
    parser_config = ParserConfig.from_dict(config.get("excel_parser", {}))
    converter = ExcelToMarkdownConverter(parser_config)
    s = time.time()
    md_text = converter.convert_to_markdown(current_path)
    elapsed = time.time() - s
    output_md_p.write_text(md_text, encoding="utf-8")
    processing_times["2_parse_excel_parser"] = round(elapsed, 2)
    logger.info(f"[2/3] パース完了 ({elapsed:.1f}s): {output_md_p}")
    _cb_progress(step_callback, 0.50, f"[2/3] パース完了 ({elapsed:.1f}s): {output_md_p.name}")

    # --------------------------------------------------
    # 3. チャンキング (Markdown → JSON) — xlsx専用分割
    # --------------------------------------------------
    output_chunk_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[3/3] チャンキング (xlsx): {output_md_p.name} -> {output_chunk_p.name}")
    _cb_progress(step_callback, 0.55, f"[3/3] チャンキング (xlsx): {output_md_p.name} -> {output_chunk_p.name}")
    chunking_config = config.get("chunking", {})
    chunk_size = chunking_config.get("chunk_size", 8192)
    chunk_overlap = chunking_config.get("chunk_overlap", 200)
    intermediate_md_p = work_p / "chunking_intermediate.md"
    s = time.time()
    chunks = chunk_markdown_xlsx(
        str(output_md_p),
        str(output_chunk_p),
        intermediate_md_path=str(intermediate_md_p),
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    elapsed = time.time() - s
    processing_times["3_chunking"] = round(elapsed, 2)
    logger.info(f"[3/3] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク -> {output_chunk_p}")
    _cb_progress(step_callback, 0.60, f"[3/3] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク")

    # --------------------------------------------------
    # 処理時間の記録 (work/processing_time.json)
    # --------------------------------------------------
    if processing_times:
        _save_processing_times(work_p, input_p, processing_times)

    logger.info(f"[xlsx] 前処理パイプライン完了: {input_path}")


def _save_processing_times(work_p: Path, input_p: Path, processing_times: dict) -> None:
    time_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input": str(input_p),
        "steps": processing_times,
    }
    time_json_p = work_p / "processing_time.json"
    existing: list = []
    if time_json_p.exists():
        try:
            with open(time_json_p, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                existing = [existing]
        except Exception:
            existing = []
    existing.append(time_record)
    with open(time_json_p, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
    logger.info(f"処理時間を記録しました: {time_json_p}")
