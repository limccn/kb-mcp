import csv
import glob
import json
import multiprocessing
import os
import time
import warnings
from concurrent.futures import ProcessPoolExecutor
from multiprocessing.connection import Connection
from pathlib import Path

import psutil
from loguru import logger
from tqdm import tqdm

from ._version import __version__
from .core import ExcelToMarkdownConverter

# Global worker instance to hold the converter state within each child process
_worker_converter = None


def _init_worker(config) -> None:
    """
    Initializer for ProcessPoolExecutor workers.
    Sets up a persistent converter instance per process to avoid redundant object creation
    during every task execution.
    """
    global _worker_converter
    _worker_converter = ExcelToMarkdownConverter(config)


def _get_safe_max_workers() -> int:
    """
    Calculates the optimal number of worker processes based on hardware constraints.
    Prevents "Out of Memory" errors by estimating RAM usage per worker (approx 0.5GB).
    """
    physical_cores = psutil.cpu_count(logical=False) or 1
    available_gb = psutil.virtual_memory().available / (1024**3)
    # Ensure at least 1 worker, but limit based on available memory
    memory_limit = max(1, int(available_gb / 0.5))
    max_workers = min(physical_cores - 1 if physical_cores > 1 else 1, memory_limit)
    return max(1, max_workers)


def _run_actual_conversion(
    args: tuple[Path, Path, Path, bool, float | None],
    converter: ExcelToMarkdownConverter | None,
    conn: Connection,
) -> None:
    """
    Internal task logic that performs the file conversion.
    This function is designed to run inside a separate Process to allow for timeouts.
    Results and warnings are sent back to the parent process via a Pipe connection.
    """
    file_path, results_root, rel_path, preserve_struct, timeout = args

    if converter is None:
        conn.send(
            {
                "status": "failed",
                "out_md_size": 0.0,
                "warnings": [
                    "[SYSTEM ERROR] Converter was not initialized in the worker process."
                ],
            }
        )
        conn.close()
        return

    try:
        captured_warnings = []

        # Capture library-specific warnings (e.g., openpyxl styling warnings) to include in the report
        with warnings.catch_warnings(record=True) as w_list:
            warnings.simplefilter("always", UserWarning)

            text, meta = converter.convert_to_content_and_metadata(file_path)

            for w in w_list:
                msg = str(w.message)
                if msg.startswith("["):
                    captured_warnings.append(msg)
                elif "openpyxl" in str(w.filename):
                    captured_warnings.append(f"[openpyxl] {msg}")
                else:
                    captured_warnings.append(f"[system] {msg}")

        # Construct output paths while maintaining subdirectory structure if applicable
        out_dir = results_root / (
            rel_path.parent if preserve_struct else Path(rel_path.name).parent
        )
        out_dir.mkdir(parents=True, exist_ok=True)

        out_md_path = out_dir / f"{file_path.stem}.md"
        out_json_path = out_dir / f"{file_path.stem}.md.metadata.json"

        out_md_path.write_text(text, encoding="utf-8")
        out_json_path.write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        # Notify the parent process of successful completion
        conn.send(
            {
                "status": "success",
                "out_md_size": out_md_path.stat().st_size / 1024,
                "warnings": captured_warnings,
            }
        )
    except Exception as e:
        # Send error details back to parent
        conn.send(
            {
                "status": "failed",
                "out_md_size": 0.0,
                "warnings": [f"[ERROR] {type(e).__name__}: {str(e)}"],
            }
        )
    finally:
        conn.close()


def _process_single_file(args: tuple[Path, Path, Path, bool, float | None]) -> dict:
    """
    Wrapper for processing one Excel file with a robust timeout mechanism.
    It spawns a dedicated child process for each file to ensure that hung
    conversions (e.g., huge files) can be forcibly terminated.
    """
    file_path, results_root, rel_path, preserve_struct, timeout = args
    start_file = time.perf_counter()

    # Pipe for inter-process communication (IPC)
    parent_conn, child_conn = multiprocessing.Pipe()

    p = multiprocessing.Process(
        target=_run_actual_conversion, args=(args, _worker_converter, child_conn)
    )

    p.start()
    p.join(timeout)

    status = "undefined"
    out_md_size = 0.0
    captured_warnings = []

    # Handle process termination if timeout is exceeded
    if timeout is not None and p.is_alive():
        p.terminate()
        p.join()
        status = "timeout"
        out_md_size = 0.0
        captured_warnings.append(f"[TIMEOUT] Process killed after {timeout}s")
    else:
        # Check if the child process sent data through the pipe before exiting
        if parent_conn.poll():
            res = parent_conn.recv()
            status = res["status"]
            out_md_size = res["out_md_size"]
            captured_warnings.extend(res.get("warnings", []))
        else:
            status = "failed"
            out_md_size = 0.0
            captured_warnings.append(
                "[SYSTEM] Subprocess exited without returning data"
            )

    elapsed_file = time.perf_counter() - start_file

    return {
        "file_path_rel": str(rel_path),
        "extension": file_path.suffix,
        "in_size_kb": round(file_path.stat().st_size / 1024, 2),
        "out_md_size_kb": round(out_md_size, 2),
        "time_sec": round(elapsed_file, 4),
        "status": status,
        "messages": sorted(list(set(captured_warnings))),
    }


class BatchProcessor:
    """
    Orchestrator for discovering files and managing parallel execution.
    """

    # Subdirectory name where converted files are stored
    OUTPUT_SUBDIR = "parse_results"

    def __init__(self, config):
        self.config = config

    def expand_paths(
        self,
        input_paths: list[str],
        base_dir: Path | None = None,
        recursive: bool = False,
    ) -> list[Path]:
        """
        Resolves various input formats (files, dirs, globs) into a list of absolute Paths.
        Filters out unsupported file types based on the converter's requirements.
        """
        expanded = []
        for p_str in input_paths:
            p = Path(p_str)
            # Resolve relative paths against base_dir if provided
            if base_dir and not p.is_absolute():
                p = base_dir / p

            path_str = str(p)
            # Handle wildcard patterns (e.g., data/*.xlsx)
            if "*" in path_str or "?" in path_str:
                for match in glob.glob(path_str, recursive=recursive):
                    matched_path = Path(match)
                    if ExcelToMarkdownConverter.is_supported(matched_path):
                        expanded.append(matched_path)
            # Handle directory inputs
            elif p.is_dir():
                search_method = p.rglob if recursive else p.glob
                for ext in ExcelToMarkdownConverter.SUPPORTED_EXTENSIONS:
                    expanded.extend(search_method(f"*{ext}"))
            # Handle direct file paths
            elif p.exists():
                if ExcelToMarkdownConverter.is_supported(p):
                    expanded.append(p)
            else:
                logger.warning(f"Target file not found in path '{p}'")

        # Remove duplicates and return sorted list for deterministic processing order
        return sorted(list(set(f for f in expanded if f.is_file())))

    def process_all(
        self,
        target_files: list[Path],
        output_dir: Path,
        base_dir: Path | None = None,
        preserve_struct: bool = False,
        generate_report: bool = False,
        timeout: float | None = None,
        verbose: bool = False,
    ) -> None:
        """
        Execute the conversion for all discovered files using a process pool.
        """
        results_dir = output_dir / self.OUTPUT_SUBDIR
        results_dir.mkdir(parents=True, exist_ok=True)

        # Prepare a list of tasks where each task contains all necessary info for a worker
        tasks = self._get_tasks(
            target_files,
            results_dir,
            base_dir,
            preserve_struct,
            timeout,
        )

        use_tqdm = len(target_files) > 1
        if not use_tqdm and target_files:
            logger.info(f"Processing: {target_files[0].name}")

        max_workers = _get_safe_max_workers()
        start_total = time.perf_counter()

        # Execute tasks in parallel
        with ProcessPoolExecutor(
            max_workers=max_workers, initializer=_init_worker, initargs=(self.config,)
        ) as executor:
            results = list(
                tqdm(
                    executor.map(_process_single_file, tasks),
                    total=len(target_files),
                    desc="Processing Excel files",
                    unit="file",
                    disable=not use_tqdm,
                )
            )
            stats = [r for r in results if r is not None]

        end_total = time.perf_counter()

        # Finalize output: print summaries and save CSV report
        self._print_warnings_to_console(stats, verbose)

        if generate_report:
            self._write_report(output_dir / "conversion_stats.csv", stats)

        logger.success(f"Output written to: {results_dir}")
        logger.success(
            f"All process finished! Total time: {end_total - start_total:.2f} sec"
        )

    def _get_tasks(
        self,
        target_files: list[Path],
        results_dir: Path,
        base_dir: Path | None,
        preserve_struct: bool,
        timeout: float | None,
    ) -> list[tuple[Path, Path, Path, bool, float | None]]:
        """
        Maps input files to their target output paths within the results directory.
        Returns a list of tuples formatted for consumption by _process_single_file.
        """
        # Determine the root directory used to calculate relative output paths
        common_base = self._get_common_base(target_files, base_dir)

        tasks = []
        for target_file in target_files:
            if common_base:
                try:
                    # e.g., if common_base is 'in/' and file is 'in/sub/f.xlsx', rel_path is 'sub/f.xlsx'
                    rel_path = target_file.resolve().relative_to(common_base.resolve())
                except ValueError:
                    # Fallback to just the filename if the file lies outside the base directory
                    logger.warning(
                        f"base directory '{common_base.resolve()}' not found in input path '{target_file}'. "
                        f"Fallback to just the filename '{target_file.name}'"
                    )
                    rel_path = Path(target_file.name)
            else:
                # Flat output: all files go directly into the output root
                rel_path = Path(target_file.name)

            tasks.append((target_file, results_dir, rel_path, preserve_struct, timeout))

        return tasks

    def _get_common_base(
        self,
        target_files: list[Path],
        base_dir: Path | None,
    ) -> Path | None:
        """
        Calculates the "anchor" directory for maintaining folder structure.
        Priority:
        1. Explicit --base_dir.
        2. Automatic detection of the longest common path among all input files.
        """
        if base_dir:
            return base_dir.resolve()
        elif len(target_files) > 1:
            # Detects the shared parent folder of all inputs
            return Path(os.path.commonpath([f.resolve().parent for f in target_files]))
        elif len(target_files) == 1:
            return target_files[0].resolve().parent
        else:
            return None

    def _print_warnings_to_console(self, stats: list[dict], verbose: bool) -> None:
        """
        Prints a summary of failures and (if verbose) warnings to the console.
        Ensures critical failures are clearly visible at the end of the run.
        """
        display_items = [
            s
            for s in stats
            if s["status"] in ["failed", "timeout"] or (verbose and s["messages"])
        ]

        if not display_items:
            return

        # Sort so that 'failed' items appear before 'success with warnings'
        display_items.sort(key=lambda x: x["status"] != "failed")

        logger.info("=" * 50)
        logger.info("PROCESSING REPORT")
        logger.info("=" * 50)

        for s in display_items:
            if s["status"] == "timeout":
                logger.error(f"FILE: {s['file_path_rel']} {"(TIMEOUT - KILLED)"}")
            elif s["status"] == "failed":
                logger.error(f"FILE: {s['file_path_rel']} {"(FAILED)"}")
            else:
                logger.warning(
                    f"FILE: {s['file_path_rel']} {"(SUCCESS with warnings)"}"
                )

            for w in s["messages"]:
                logger.debug(f"  {w}")

        logger.info("=" * 50)

    def _write_report(self, csv_path: Path, stats: list[dict]) -> None:
        """
        Saves execution statistics to a CSV file.
        Uses 'utf-8-sig' (UTF-8 with BOM) for immediate compatibility with Microsoft Excel.
        """
        if not stats:
            return

        report_data = []
        for s in stats:
            item = s.copy()
            # Convert the list of warning messages into a single string for CSV storage
            item["messages"] = " | ".join(s["messages"])
            report_data.append(item)

        with open(csv_path, "w", encoding="utf-8-sig", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=report_data[0].keys())
            writer.writeheader()
            writer.writerows(report_data)
        logger.success(f"Stats saved: {csv_path}")
