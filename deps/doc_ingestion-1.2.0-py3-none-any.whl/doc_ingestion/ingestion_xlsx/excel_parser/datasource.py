import colorsys
import io
import re
import warnings
from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, get_args

import openpyxl
import xlrd  # type: ignore
from openpyxl.cell.rich_text import CellRichText
from openpyxl.cell.rich_text import TextBlock as OpenpyxlTextBlock
from openpyxl.styles.colors import COLOR_INDEX
from openpyxl.utils import range_boundaries
from openpyxl.xml.functions import QName, fromstring

from .schema import CellData, ExcelValue, ParserConfig, RichTextSegment

# Define valid types for Excel values based on the schema alias
_EXCEL_VALUE_TYPES = tuple(t for t in get_args(ExcelValue) if t is not type(None))


class RawDataSource(ABC):
    """
    Interface for Excel data sources.
    Defines common methods for accessing cell data regardless of the underlying library.
    """

    def __init__(self) -> None:
        # Maps (ri, ci) to (r1, r2, c1, c2) merge boundaries
        self._merged_ranges: dict[tuple[int, int], tuple[int, int, int, int]] = {}

    @property
    @abstractmethod
    def sheet_name(self) -> str:
        """Return the name of the worksheet."""
        ...

    @property
    @abstractmethod
    def start_row(self) -> int:
        """Return the starting row index for processing."""
        ...

    @property
    @abstractmethod
    def start_col(self) -> int:
        """Return the starting column index for processing."""
        ...

    @property
    @abstractmethod
    def nrows(self) -> int:
        """Return the number of rows to process."""
        ...

    @property
    @abstractmethod
    def ncols(self) -> int:
        """Return the number of columns to process."""
        ...

    @property
    @abstractmethod
    def is_visible(self) -> bool:
        """Return True if the sheet is not hidden."""
        ...

    @property
    @abstractmethod
    def print_area(self) -> tuple[int, int, int, int]:
        """Return (r1, r2, c1, c2) coordinates of the active area."""
        ...

    @abstractmethod
    def get_cell_value(self, ri: int, ci: int) -> ExcelValue: ...

    @abstractmethod
    def get_rich_text_segments(self, ri: int, ci: int) -> list[RichTextSegment]: ...

    @abstractmethod
    def get_merged_cell_value(self, ri: int, ci: int) -> ExcelValue: ...

    @abstractmethod
    def get_cell_value_if_primary(self, ri: int, ci: int) -> ExcelValue: ...

    @abstractmethod
    def get_background_rgb(self, ri: int, ci: int) -> tuple[int, int, int] | None: ...

    @abstractmethod
    def get_merged_range(
        self, ri: int, ci: int
    ) -> tuple[int, int, int, int] | None: ...

    @abstractmethod
    def is_merged_cell(self, ri: int, ci: int) -> bool: ...

    @abstractmethod
    def is_date_type(self, ri: int, ci: int) -> bool: ...

    @abstractmethod
    def is_strikethrough_cell(self, ri: int, ci: int) -> bool: ...

    @abstractmethod
    def convert_raw_xldate_to_datetime(self, xldate: float | datetime) -> datetime: ...

    @abstractmethod
    def _get_merged_ranges(self): ...

    @abstractmethod
    def _is_center_across_selection(self, ri: int, ci: int) -> bool: ...

    def _init_merged_ranges(self):
        """Initializes both official merged cells and virtual merges (Center Across Selection)."""
        self._merged_ranges = self._get_merged_ranges()
        self._merged_ranges.update(self._get_center_across_selection_ranges())

    def _get_center_across_selection_ranges(
        self,
    ) -> dict[tuple[int, int], tuple[int, int, int, int]]:
        """
        Scans the sheet for 'Center Across Selection' alignments and treats them as merged cells.
        This ensures labels spanning multiple empty columns are handled as a single unit.
        """
        center_across_selection_ranges = []
        for ri in range(self.start_row, self.nrows):
            ci = self.start_col
            while ci < self.ncols:
                # Skip if already part of a real merge
                if (ri, ci) in self._merged_ranges:
                    ci += 1
                    continue
                center_across_selection = self._get_center_across_selection_range(
                    ri, ci
                )
                if center_across_selection:
                    center_across_selection_ranges.append(center_across_selection)
                    ci = center_across_selection[3]
                else:
                    ci += 1

        # Flatten ranges into the coordinate map
        out_ranges = {}
        for r1, r2, c1, c2 in center_across_selection_ranges:
            for ri in range(r1, r2):
                for ci in range(c1, c2):
                    out_ranges[(ri, ci)] = r1, r2, c1, c2

        return out_ranges

    def _get_center_across_selection_range(
        self, ri: int, ci: int
    ) -> tuple[int, int, int, int] | None:
        """
        Identifies a contiguous horizontal range of cells with 'Center Across Selection' alignment.
        Starting cell must have a value; subsequent cells must be empty.
        """
        if self.get_cell_value(ri, ci) is None or not self._is_center_across_selection(
            ri, ci
        ):
            return None

        c1 = ci
        c2 = ci
        for ci_tmp in range(ci + 1, self.ncols):
            if (
                not self._is_center_across_selection(ri, ci_tmp)
                or self.get_cell_value(ri, ci_tmp) is not None
            ):
                break
            c2 = ci_tmp

        return ri, ri + 1, c1, c2 + 1


class XlsRawDataSource(RawDataSource):
    """
    Implementation for Legacy Excel files (.xls) using xlrd.
    """

    def __init__(self, sheet: xlrd.sheet.Sheet, book: xlrd.Book, config: ParserConfig):
        super().__init__()
        self._sheet = sheet
        self._book = book
        self._config = config
        self._sheet_index = self._find_sheet_index()
        self._print_area: tuple[int, int, int, int] = self._find_print_area()
        self._init_merged_ranges()

    @property
    def sheet_name(self) -> str:
        return self._sheet.name

    @property
    def start_row(self) -> int:
        return max(0, self.print_area[0])

    @property
    def start_col(self) -> int:
        return max(0, self.print_area[2])

    @property
    def nrows(self) -> int:
        return min(self._sheet.nrows, self.print_area[1])

    @property
    def ncols(self) -> int:
        return min(self._sheet.ncols, self.print_area[3])

    @property
    def is_visible(self) -> bool:
        return self._sheet.visibility == 0

    @property
    def print_area(self) -> tuple[int, int, int, int]:
        return self._print_area

    def get_cell_value(self, ri: int, ci: int) -> ExcelValue:
        """Translates xlrd cell types to standard Python types."""
        cell = self._sheet.cell(ri, ci)
        val = cell.value
        ctype = cell.ctype

        if ctype == xlrd.XL_CELL_EMPTY or val == "":
            return None
        if ctype == xlrd.XL_CELL_ERROR:
            return xlrd.error_text_from_code.get(val, "#ERROR!")
        if ctype == xlrd.XL_CELL_BOOLEAN:
            return bool(val)
        if ctype == xlrd.XL_CELL_DATE:
            return self.convert_raw_xldate_to_datetime(val)
        if isinstance(val, float) and val.is_integer():
            return int(val)

        return val

    def get_rich_text_segments(self, ri: int, ci: int) -> list[RichTextSegment]:
        """
        Parses rich text formatting within a cell.
        Requires formatting_info=True during workbook loading.
        Maps xlrd runlists to RichTextSegment objects.
        """
        cell = self._sheet.cell(ri, ci)
        full_text = str(cell.value)

        # rich_text_runlist_map provides (start_index, font_index) pairs
        runs = self._sheet.rich_text_runlist_map.get((ri, ci))

        if not runs:
            return []

        segments: list[RichTextSegment] = []

        # Handle text before the first formatting run
        first_start_idx = runs[0][0]
        if first_start_idx > 0:
            prefix_text = full_text[:first_start_idx]
            if prefix_text:
                segments.append(
                    RichTextSegment(prefix_text, self.is_strikethrough_cell(ri, ci))
                )

        # Process formatted runs by identifying the slice of text between font changes
        for i in range(len(runs)):
            start_idx, font_idx = runs[i]
            end_idx = runs[i + 1][0] if i + 1 < len(runs) else len(full_text)

            substring = full_text[start_idx:end_idx]
            if not substring:
                continue

            font = self._book.font_list[font_idx]

            is_strikethrough = font.struck_out != 0
            if len(segments) > 0 and segments[-1].is_strikethrough == is_strikethrough:
                # Concatenate segments
                last_seg = segments.pop()
                segments.append(
                    RichTextSegment(last_seg.text + substring, is_strikethrough)
                )
            elif is_strikethrough and substring.startswith(("\r", "\n")):
                # Move starting newlines to previous segment
                last_seg = segments.pop()
                last_text = last_seg.text
                while len(substring) > 0 and substring.startswith(("\r", "\n")):
                    last_text += substring[0]
                    substring = substring[1:]
                segments.append(RichTextSegment(last_text, last_seg.is_strikethrough))
                segments.append(RichTextSegment(substring, is_strikethrough))
            else:
                segments.append(RichTextSegment(substring, is_strikethrough))

        return segments

    def get_merged_cell_value(self, ri: int, ci: int) -> ExcelValue:
        """Fetch the value from the top-left cell of the merged region."""
        res = self.get_merged_range(ri, ci)
        if res is None:
            return self.get_cell_value(ri, ci)

        r1, _, c1, _ = res
        return self.get_cell_value(r1, c1)

    def get_cell_value_if_primary(self, ri: int, ci: int) -> ExcelValue:
        """Returns value only if the current cell is the origin (top-left) of a merge."""
        res = self.get_merged_range(ri, ci)
        if res is None:
            return self.get_cell_value(ri, ci)

        r1, _, c1, _ = res
        return self.get_cell_value(r1, c1) if (ri == r1 and ci == c1) else ""

    def get_background_rgb(self, ri: int, ci: int) -> tuple[int, int, int] | None:
        """Resolves background color via the workbook's palette."""
        cell = self._sheet.cell(ri, ci)
        res = self.get_merged_range(ri, ci)
        if res is not None:
            # Merged cells usually store styling in the primary cell
            r1, _, c1, _ = res
            cell = self._sheet.cell(r1, c1)

        xf = self._book.xf_list[cell.xf_index]
        return self._book.colour_map.get(xf.background.pattern_colour_index)

    def get_merged_range(self, ri: int, ci: int) -> tuple[int, int, int, int] | None:
        return self._merged_ranges.get((ri, ci))

    def is_merged_cell(self, ri: int, ci: int) -> bool:
        return self.get_merged_range(ri, ci) is not None

    def is_date_type(self, ri: int, ci: int) -> bool:
        return self._sheet.cell(ri, ci).ctype == xlrd.XL_CELL_DATE

    def is_strikethrough_cell(self, ri: int, ci: int) -> bool:
        """Checks if the cell font is set to struck out."""
        cell = self._sheet.cell(ri, ci)
        xf = self._book.xf_list[cell.xf_index]
        font = self._book.font_list[xf.font_index]
        return font.struck_out != 0

    def convert_raw_xldate_to_datetime(self, xldate) -> datetime:
        """Uses xlrd's internal datemode to handle 1900/1904 date systems."""
        datetime_value = xlrd.xldate_as_datetime(xldate, self._book.datemode)
        if isinstance(xldate, float) and xldate < 1.0:
            return datetime_value.time()
        else:
            return datetime_value

    def _find_sheet_index(self) -> int:
        for i in range(self._book.nsheets):
            if self._book.sheet_by_index(i) is self._sheet:
                return i
        return -1

    def _find_print_area(self) -> tuple[int, int, int, int]:
        """Restricts parsing to the 'Print_Area' if it exists and config is enabled."""
        if self._config.remove_outside_print_area:
            for name in self._book.name_obj_list:
                if name.name == "Print_Area" and name.scope == self._sheet_index:
                    if hasattr(name, "result") and name.result is not None:
                        # Handle xlrd error codes in named ranges
                        if getattr(name.result, "kind", None) == 0x04:
                            continue
                    try:
                        # area2d returns (sheet_index, r1, r2, c1, c2)
                        return name.area2d(False)[1:]
                    except xlrd.XLRDError:
                        pass
        return (0, self._sheet.nrows, 0, self._sheet.ncols)

    def _get_merged_ranges(
        self,
    ) -> dict[tuple[int, int], tuple[int, int, int, int]]:
        """Pre-maps every coordinate within a merge to its bounding box (r1, r2, c1, c2)."""
        if not self._sheet.merged_cells:
            return {}

        merged_ranges = {}
        for r1, r2, c1, c2 in self._sheet.merged_cells:
            for ri in range(r1, r2):
                for ci in range(c1, c2):
                    merged_ranges[(ri, ci)] = r1, r2, c1, c2
        return merged_ranges

    def _is_center_across_selection(self, ri: int, ci: int) -> bool:
        """xlrd-specific check for alignment constant 6 (Center Across Selection)."""
        cell = self._sheet.cell(ri, ci)
        xf = self._book.xf_list[cell.xf_index]
        return xf.alignment.hor_align == 6


class XlsxRawDataSource(RawDataSource):
    """
    Implementation for modern Excel files (.xlsx) using openpyxl.
    Note: openpyxl uses 1-based indexing internally, but this class exposes 0-based for consistency.
    """

    def __init__(
        self, sheet: openpyxl.worksheet.worksheet.Worksheet, config: ParserConfig
    ):
        super().__init__()
        self._sheet = sheet
        self._config = config
        self._max_row = sheet.max_row
        self._max_col = sheet.max_column
        self._print_area: tuple[int, int, int, int] = self._find_print_area()
        self._theme_colors = self._get_theme_colors()
        self._init_merged_ranges()

    @property
    def sheet_name(self) -> str:
        return self._sheet.title

    @property
    def start_row(self) -> int:
        return max(0, self.print_area[0])

    @property
    def start_col(self) -> int:
        return max(0, self.print_area[2])

    @property
    def nrows(self) -> int:
        return min(self._max_row, self.print_area[1])

    @property
    def ncols(self) -> int:
        return min(self._max_col, self.print_area[3])

    @property
    def is_visible(self) -> bool:
        return self._sheet.sheet_state == "visible"

    @property
    def print_area(self) -> tuple[int, int, int, int]:
        return self._print_area

    def get_cell_value(self, ri: int, ci: int) -> ExcelValue:
        """Gets the cell value and normalizes it for the converter."""
        # Convert 0-indexed coords to openpyxl 1-indexed
        raw_val = self._sheet.cell(row=ri + 1, column=ci + 1).value

        if raw_val is None:
            return None

        # Normalize special decimal/rich text types to basic Python types
        if isinstance(raw_val, Decimal):
            raw_val = float(raw_val)
        elif isinstance(raw_val, CellRichText):
            raw_val = str(raw_val)

        if self.is_date_type(ri, ci) and isinstance(raw_val, (int, float)):
            raw_val = self.convert_raw_xldate_to_datetime(raw_val)

        if isinstance(raw_val, float) and raw_val.is_integer():
            return int(raw_val)

        if isinstance(raw_val, _EXCEL_VALUE_TYPES):
            return raw_val

        return str(raw_val)

    def get_rich_text_segments(self, ri: int, ci: int) -> list[RichTextSegment]:
        """Extracts individual formatting runs from a cell containing CellRichText."""
        cell = self._sheet.cell(row=ri + 1, column=ci + 1)
        val = cell.value

        if not isinstance(val, CellRichText):
            return []

        segments: list[RichTextSegment] = []
        for run in val:
            if isinstance(run, OpenpyxlTextBlock):
                is_strike = bool(run.font.strike) if run.font else False
                segments.append(RichTextSegment(run.text or "", is_strike))
            else:
                # Fallback for plain strings within a rich text container
                segments.append(
                    RichTextSegment(str(run), self.is_strikethrough_cell(ri, ci))
                )
        return segments

    def get_merged_cell_value(self, ri: int, ci: int) -> ExcelValue:
        r1, _, c1, _ = self.get_merged_range(ri, ci) or (ri, None, ci, None)
        return self.get_cell_value(r1, c1)

    def get_cell_value_if_primary(self, ri: int, ci: int) -> ExcelValue:
        res = self.get_merged_range(ri, ci)
        if res is None:
            return self.get_cell_value(ri, ci)

        r1, _, c1, _ = res
        return self.get_cell_value(r1, c1) if (ri == r1 and ci == c1) else ""

    def _get_theme_colors(self) -> list[str] | None:
        """Parses the workbook theme XML to extract the hex color palette."""
        wb: Any = self._sheet.parent
        if wb is None or not hasattr(wb, "loaded_theme") or wb.loaded_theme is None:
            return None

        try:
            xlmns = "http://schemas.openxmlformats.org/drawingml/2006/main"
            root = fromstring(wb.loaded_theme)
            theme_el = root.find(QName(xlmns, "themeElements").text)
            color_schemes = theme_el.findall(QName(xlmns, "clrScheme").text)
            first_scheme = color_schemes[0]

            colors = []
            # Maps standard theme indices (Background, Text, Accent 1-6) to hex codes
            for child in first_scheme:
                srgb = child.find(QName(xlmns, "srgbClr").text)
                if srgb is not None:
                    colors.append(srgb.attrib["val"])
                else:
                    sys = child.find(QName(xlmns, "sysClr").text)
                    if sys is not None:
                        colors.append(sys.attrib.get("lastClr", "FFFFFF"))
            return colors
        except Exception:
            return None

    def _apply_tint(self, rgb_hex: str, tint: float) -> str:
        """Applies Excel's specific tint logic to a base RGB hex string."""
        if not tint:
            return rgb_hex

        r = int(rgb_hex[0:2], 16) / 255.0
        g = int(rgb_hex[2:4], 16) / 255.0
        b = int(rgb_hex[4:6], 16) / 255.0

        h, l, s = colorsys.rgb_to_hls(r, g, b)

        # Excel formula for tinting: if tint < 0, darken. if tint > 0, lighten.
        if tint < 0:
            l = l * (1.0 + tint)
        else:
            l = l * (1.0 - tint) + tint

        r, g, b = colorsys.hls_to_rgb(h, l, s)
        return "{:02X}{:02X}{:02X}".format(
            int(round(r * 255)), int(round(g * 255)), int(round(b * 255))
        )

    def get_background_rgb(self, ri: int, ci: int) -> tuple[int, int, int] | None:
        """Determines the effective RGB color, resolving themes and tints."""
        cell = self._sheet.cell(row=ri + 1, column=ci + 1)
        res = self.get_merged_range(ri, ci)
        if res:
            # For merges, formatting is retrieved from the primary (top-left) cell
            cell = self._sheet.cell(row=res[0] + 1, column=res[2] + 1)

        fill = cell.fill
        if not hasattr(fill, "start_color") or not fill.start_color:
            return None

        color_obj = fill.start_color
        rgb_str = None

        if color_obj.type == "rgb" and isinstance(color_obj.rgb, str):
            rgb_str = color_obj.rgb
        elif color_obj.type == "theme" and color_obj.theme is not None:
            if self._theme_colors and color_obj.theme < len(self._theme_colors):
                base_rgb = self._theme_colors[color_obj.theme]
                rgb_str = self._apply_tint(base_rgb, color_obj.tint or 0.0)
            else:
                # Return a dummy near-gray if theme resolution fails to allow header candidate detection
                rgb_str = "FFD3D3D4"
        elif color_obj.type == "indexed":
            try:
                rgb_str = COLOR_INDEX[color_obj.indexed]
            except (IndexError, KeyError, TypeError):
                pass

        if not rgb_str or not isinstance(rgb_str, str) or rgb_str == "00000000":
            return None

        # Extract RGB from ARGB (strip leading alpha if present)
        hex_val = rgb_str[-6:]
        try:
            return (
                int(hex_val[0:2], 16),
                int(hex_val[2:4], 16),
                int(hex_val[4:6], 16),
            )
        except (ValueError, IndexError):
            return None

    def get_merged_range(self, ri: int, ci: int) -> tuple[int, int, int, int] | None:
        return self._merged_ranges.get((ri, ci))

    def is_merged_cell(self, ri: int, ci: int) -> bool:
        return (ri, ci) in self._merged_ranges

    def is_date_type(self, ri: int, ci: int) -> bool:
        res = self.get_merged_range(ri, ci)
        target_ri, target_ci = (res[0], res[2]) if res else (ri, ci)
        cell = self._sheet.cell(row=target_ri + 1, column=target_ci + 1)
        return getattr(cell, "is_date", False)

    def is_strikethrough_cell(self, ri: int, ci: int) -> bool:
        res = self.get_merged_range(ri, ci)
        if res:
            cell = self._sheet.cell(row=res[0] + 1, column=res[2] + 1)
        else:
            cell = self._sheet.cell(row=ri + 1, column=ci + 1)
        return cell.font.strike if cell.font else False

    def convert_raw_xldate_to_datetime(self, xldate) -> datetime:
        if isinstance(xldate, datetime):
            return xldate
        if xldate is None or xldate == "":
            return datetime(1900, 1, 1)
        return xldate

    def _find_print_area(self) -> tuple[int, int, int, int]:
        """Parses the print_area string (e.g., 'Sheet1!$A$1:$C$10') into coordinate boundaries."""
        print_area = self._sheet.print_area
        if self._config.remove_outside_print_area and print_area:
            try:
                area_str: str = (
                    print_area[0]
                    if isinstance(print_area, (list, tuple))
                    else str(print_area)
                )

                if "!" in area_str:
                    area_str = area_str.split("!")[-1]

                if area_str.strip():
                    min_col, min_row, max_col, max_row = range_boundaries(area_str)
                    # Convert 1-based openpyxl coordinates to 0-based
                    r1 = min_row - 1 if min_row is not None else 0
                    c1 = min_col - 1 if min_col is not None else 0
                    r2 = max_row if max_row is not None else self._max_row
                    c2 = max_col if max_col is not None else self._max_col
                    return (r1, r2, c1, c2)
            except (ValueError, IndexError):
                pass

        return (0, self._sheet.max_row, 0, self._sheet.max_column)

    def _get_merged_ranges(
        self,
    ) -> dict[tuple[int, int], tuple[int, int, int, int]]:
        """Maps every cell coordinate in an openpyxl range to its merge bounding box."""
        merged_map = {}
        for m_range in self._sheet.merged_cells.ranges:
            min_col, min_row, max_col, max_row = range_boundaries(m_range.coord)
            if min_col is None or min_row is None or max_col is None or max_row is None:
                continue
            # Store as (r1, r2, c1, c2) where r2/c2 are exclusive boundaries
            bounding_box = (min_row - 1, max_row, min_col - 1, max_col)
            for r in range(min_row - 1, max_row):
                for c in range(min_col - 1, max_col):
                    merged_map[(r, c)] = bounding_box
        return merged_map

    def _is_center_across_selection(self, ri: int, ci: int) -> bool:
        """openpyxl-specific check for 'centerContinuous' alignment."""
        cell = self._sheet.cell(row=ri + 1, column=ci + 1)
        return cell.alignment.horizontal == "centerContinuous"


class WarningRedirector(io.StringIO):
    """
    A custom log redirector for the xlrd library.
    xlrd writes internal warnings/logs to a file-like object (logfile).
    This class intercepts those strings and issues them as Python UserWarnings,
    allowing the BatchProcessor to capture and report them to the user.
    """

    def write(self, s: str):
        if s.strip():
            # Standardizes xlrd logs into the application's warning system
            warnings.warn(f"[xlrd] {s.strip()}", UserWarning)
        return super().write(s)


class DataSourceFactory:
    """Factory to initialize the appropriate RawDataSource based on file extension."""

    SUPPORTED_EXTENSIONS = {".xls", ".xlsx", ".xlsm"}

    @classmethod
    def create_from_file(
        cls, file_path: Path, config: ParserConfig
    ) -> list[RawDataSource]:
        suffix = file_path.suffix.lower()

        raw_sources: list[RawDataSource] = []
        if suffix == ".xls":
            raw_sources = cls._create_xls_sources(file_path, config)
        elif suffix == ".xlsx" or suffix == ".xlsm":
            raw_sources = cls._create_xlsx_sources(file_path, config)
        else:
            raise ValueError(f"Unsupported file extension: {suffix}")

        return cls._filter_sources(raw_sources, config)

    @staticmethod
    def _create_xls_sources(
        file_path: Path, config: ParserConfig
    ) -> list[RawDataSource]:
        # Create the redirector to catch library-level logging
        redirector = WarningRedirector()
        # formatting_info=True is required by xlrd to extract background colors and fonts.
        # logfile=redirector: Plugs our redirector into xlrd to catch issues.
        book = xlrd.open_workbook(file_path, logfile=redirector, formatting_info=True)
        return [
            XlsRawDataSource(book.sheet_by_index(i), book, config)
            for i in range(book.nsheets)
        ]

    @staticmethod
    def _create_xlsx_sources(
        file_path: Path, config: ParserConfig
    ) -> list[RawDataSource]:
        # data_only=True returns evaluated formula results instead of the formulas themselves
        # rich_text=True is required for segment-level formatting extraction
        wb = openpyxl.load_workbook(
            str(file_path), data_only=True, read_only=False, rich_text=True
        )
        return [XlsxRawDataSource(sheet, config) for sheet in wb.worksheets]

    @staticmethod
    def _filter_sources(
        sources: list[RawDataSource], config: ParserConfig
    ) -> list[RawDataSource]:
        """Removes sheets based on visibility or exclusion lists defined in config."""
        filtered: list[RawDataSource] = []
        for source in sources:
            if config.remove_hidden_sheets and not source.is_visible:
                continue
            if source.sheet_name in config.exclude_sheet_names:
                continue
            filtered.append(source)
        return filtered


class ExcelRowReader:
    """
    Reader responsible for converting raw library values into high-level CellData objects.
    Handles Markdown-specific text transformations like escaping newlines and strikethroughs.
    """

    def __init__(self, data_source: RawDataSource, config: ParserConfig) -> None:
        self.data_source = data_source
        self._config = config

    def parse_row_cells(self, ri: int) -> list[CellData]:
        """Converts an entire row into a list of normalized CellData objects."""
        return [self._create_cell_data(ri, ci) for ci in range(self.data_source.ncols)]

    def _create_cell_data(self, ri, ci) -> CellData:
        """Compiles all metadata (value, formatting, merges) for a single cell."""
        rich_text = self.data_source.get_rich_text_segments(ri, ci)
        raw_text = self._convert_cell_to_string(ri, ci)
        is_strikethrough_cell = self.data_source.is_strikethrough_cell(ri, ci)

        return CellData(
            ri,
            ci,
            self.data_source.get_cell_value_if_primary(ri, ci),
            raw_text,
            self._get_display_cell_text(raw_text, is_strikethrough_cell, rich_text),
            is_strikethrough_cell,
            self.data_source.get_background_rgb(ri, ci),
            self.data_source.get_merged_range(ri, ci),
            rich_text,
        )

    def _convert_cell_to_string(self, ri: int, ci: int) -> str:
        """Standardizes values (including dates) into a base string format."""
        val = self.data_source.get_cell_value_if_primary(ri, ci)

        if val is None or val == "":
            return ""

        if isinstance(val, datetime):
            return val.strftime("%Y-%m-%d %H:%M:%S")

        if isinstance(val, bool):
            return str(val).upper()

        return str(val)

    def _get_display_cell_text(
        self,
        raw_text: str,
        is_strikethrough_cell: bool,
        rich_text: list[RichTextSegment],
    ) -> str:
        """
        Applies Markdown formatting to text, ensuring it is safe for table cells.
        Escapes newlines and wraps strikethrough segments.
        """
        if rich_text:
            text = "".join(
                self._apply_strikethrough(s.text, s.is_strikethrough) for s in rich_text
            )
        else:
            text = self._apply_strikethrough(raw_text, is_strikethrough_cell)

        if text.strip() == "":
            return ""

        # Use <br> because Markdown tables do not support literal newlines in cells
        return re.sub(r"\r\n|\r|\n", "<br>", text)

    def _apply_strikethrough(self, text: str, is_strikethrough: bool) -> str:
        """Wraps text in Markdown strikethrough syntax (~~text~~)."""
        if text and is_strikethrough:
            if self._config.remove_strikethrough:
                return ""
            else:
                return f"~~{text}~~"
        else:
            return text
