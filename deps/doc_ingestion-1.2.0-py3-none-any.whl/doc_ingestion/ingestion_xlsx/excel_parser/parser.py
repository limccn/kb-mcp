from .schema import (CellData, DocumentBlock, HeaderBlock, HeaderCell,
                     HorizontalRuleBlock, IndentManager, ListItemBlock,
                     ParserConfig, RowBoundary, RowType, TableBlock, TableCell,
                     TextBlock)


class RowTypeResolver:
    """
    Analyzes cell patterns (styling and distribution) to determine
    if a row is a header, a data row, a section index, or empty.
    """

    def __init__(self, min_valid_header_cell_rate: float = 0.7):
        # Ratio threshold to determine if colored cells represent a header row
        self._min_valid_header_cell_rate = min_valid_header_cell_rate
        self._prev_row_boundary = RowBoundary(-1, -1, -1, -1, False, 0.0, 0.0)
        self._prev_row_type = RowType.EMPTY
        self._current_row_type = RowType.EMPTY

    @property
    def prev_row_type(self) -> RowType:
        return self._prev_row_type

    def determine_row_type(self, row_cells: list[CellData]) -> RowType:
        """Core logic to classify the current row and update internal history."""
        if self._current_row_type != RowType.EMPTY:
            self._prev_row_type = self._current_row_type

        row_boundary = self._detect_row_boundaries(row_cells)
        self._current_row_type = self._resolve_row_type(row_boundary)
        self._prev_row_boundary = row_boundary
        return self._current_row_type

    def _detect_row_boundaries(self, row_cells: list[CellData]) -> RowBoundary:
        """
        Scans a row to find where content starts and ends,
        identifying areas with header styling (e.g., background color).
        """
        active_cells = [cell for cell in row_cells if not cell.is_effectively_empty]

        if not active_cells:
            return RowBoundary(
                -1,
                -1,
                -1,
                -1,
                False,
                0.0,
                0.0,
            )

        valid_col_from = active_cells[0].left
        valid_col_to = max(cell.right for cell in active_cells)
        active_header_cells = [
            cell for cell in active_cells if cell.is_header_candidate
        ]

        if not active_header_cells:
            return RowBoundary(
                valid_col_from,
                valid_col_to,
                -1,
                -1,
                False,
                0.0,
                0.0,
            )

        header_cells = [cell for cell in row_cells if cell.is_header_candidate]

        valid_header_col_from = active_header_cells[0].left
        valid_header_col_to = max(cell.right for cell in active_header_cells)

        # Complex row: contains value cells mixed with or following header cells.
        is_complex_row = any(
            not cell.is_header_candidate and cell.right < valid_header_col_to
            for cell in active_cells
        )

        valid_header_width = sum(
            cell.right - cell.ci + 1 for cell in active_header_cells
        )
        valid_header_cell_rate_of_header = (
            valid_header_width / len(header_cells) if header_cells else 0.0
        )
        valid_header_cell_rate_of_valid = (
            len(active_header_cells) / len(active_cells) if active_cells else 0.0
        )

        return RowBoundary(
            valid_col_from,
            valid_col_to,
            valid_header_col_from,
            valid_header_col_to,
            is_complex_row,
            valid_header_cell_rate_of_header,
            valid_header_cell_rate_of_valid,
        )

    def _resolve_row_type(self, row_boundary: RowBoundary) -> RowType:
        """Maps physical row metrics to structural RowType enums."""
        if row_boundary.valid_col_from < 0:
            return RowType.EMPTY

        if row_boundary.header_col_from < 0:
            return RowType.VALUE

        # If the start of content doesn't match the start of the header, it's ambiguous
        if row_boundary.valid_col_from != row_boundary.header_col_from:
            return RowType.UNKNOWN

        if row_boundary.is_complex_row:
            return RowType.COMPLEX

        # Multi-row headers often have identical column spans; carry over the previous type.
        if (
            row_boundary.header_col_from == self._prev_row_boundary.header_col_from
            and row_boundary.header_col_to == self._prev_row_boundary.header_col_to
            and self._prev_row_type != RowType.HEADER
        ):
            return self._prev_row_type

        # Full-width header rows.
        if (
            row_boundary.valid_col_to == row_boundary.header_col_to
            and row_boundary.valid_header_cell_rate_of_header
            > self._min_valid_header_cell_rate
        ):
            return RowType.HEADER

        if (
            self._prev_row_type == RowType.HEADER
            and row_boundary.header_col_from >= self._prev_row_boundary.header_col_from
            and row_boundary.header_col_to <= self._prev_row_boundary.header_col_to
            and row_boundary.valid_header_cell_rate_of_valid
            > self._min_valid_header_cell_rate
        ):
            # Continuous header: header integration candidate
            return RowType.HEADER

        # Standalone header cells that don't span the whole data width are treated as row header (index).
        if (
            row_boundary.valid_col_to != row_boundary.header_col_to
            and row_boundary.valid_header_cell_rate_of_header
            > self._min_valid_header_cell_rate
        ):
            return RowType.INDEX

        return RowType.VALUE


class ExcelStructureParser:
    """
    Stateful parser that converts Excel rows into higher-level document components
    like Tables, Lists, and Headings.
    """

    def __init__(self) -> None:
        self._resolver = RowTypeResolver()
        self._current_table: TableBlock | None = None
        # Stores (column_index, is_value_row) to manage bullet point indentation levels
        self._indent_manager: IndentManager = IndentManager()
        self._min_column_matching_rate = 0.5

        self._sheet_cells: list[list[CellData]] | None = None

    def process(self, sheet_cells: list[list[CellData]]) -> list[DocumentBlock]:
        """Main execution loop for parsing cell rows into document blocks."""
        self._sheet_cells = sheet_cells

        blocks = []
        for ri, _ in enumerate(sheet_cells):
            blocks.extend(self._process_row(ri))
        return blocks

    def _get_row_cells(self, ri: int) -> list[CellData] | None:
        if self._sheet_cells is None or not (0 <= ri < len(self._sheet_cells)):
            return None
        return self._sheet_cells[ri]

    def _get_cell(self, ri: int, ci: int) -> CellData | None:
        if (
            self._sheet_cells is None
            or not (0 <= ri < len(self._sheet_cells))
            or not (0 <= ci < len(self._sheet_cells[ri]))
        ):
            return None
        return self._sheet_cells[ri][ci]

    def _get_primary_cell(self, ri: int, ci: int) -> CellData | None:
        cell = self._get_cell(ri, ci)
        if not cell:
            return None
        return self._get_cell(cell.top, cell.left)

    def _process_row(self, ri: int) -> list[DocumentBlock]:
        """Main dispatcher for row processing based on structural analysis."""
        row_cells = self._get_row_cells(ri)
        if not row_cells:
            return []
        row_type = self._resolver.determine_row_type(row_cells)

        match row_type:
            case RowType.EMPTY:
                return []
            case RowType.HEADER:
                return self._process_header_row(ri, row_cells)
            case RowType.INDEX | RowType.COMPLEX:
                # Process the divider part, then treat any following content as values
                blocks = self._process_index_row(
                    row_cells, self._resolver.prev_row_type
                )
                value_blocks = self._process_value_row(row_cells, True)
                if value_blocks:
                    return blocks + value_blocks + [TextBlock("\n")]
                else:
                    return blocks
            case RowType.VALUE | RowType.UNKNOWN:
                value_blocks = self._process_value_row(row_cells, False)
                if value_blocks:
                    return value_blocks + [TextBlock("\n")]
                else:
                    return []

    def _process_header_row(self, ri, row_cells: list[CellData]) -> list[DocumentBlock]:
        """Handles rows identified as table headers or major section labels."""
        blocks, header_cells, non_header_cells = self._collect_header_elements(
            row_cells
        )

        if not header_cells:
            return blocks

        if self._current_table and self._resolver.prev_row_type == RowType.HEADER:
            if self._current_table.integrate_sub_headers(header_cells):
                for cell in non_header_cells:
                    self._current_table.add_cell_data(cell)
                self._current_table.commit_row()
                return blocks

        self._reset_current_table()

        # Multiple header cells trigger a new Markdown table
        level = self._indent_manager.calculate_indent_level(
            header_cells[0].col_from, True
        )
        self._current_table = TableBlock(
            ri, header_cells[0].col_from, level, header_cells
        )
        blocks.append(self._current_table)

        for cell in non_header_cells:
            self._current_table.add_cell_data(cell)
        self._current_table.commit_row()

        return blocks

    def _is_row_header_candidate_of_current_table(self, cell: CellData) -> bool:
        """Determines if a cell is on the left side and could be a row-index label."""
        if not self._current_table:
            return False

        primary_cell = self._get_primary_cell(self._current_table.ri, cell.ci)
        if not primary_cell:
            return False

        if (
            self._current_table.columns
            and cell.right + 1 >= self._current_table.columns[-1].col_to
        ):
            return False

        return (
            not primary_cell.is_header_candidate
            or primary_cell.top > self._current_table.ri
            or cell.left >= self._current_table.ci
        )

    def _add_row_header(self, cell: CellData) -> bool:
        if not self._current_table:
            return False
        if self._is_row_header_candidate_of_current_table(cell):
            self._current_table.commit_row()
            self._current_table.add_row_header(cell)
            return True
        return False

    def _process_index_row(
        self, row_cells: list[CellData], prev_row_type: RowType
    ) -> list[DocumentBlock]:
        """Handles row headers (INDEX rows), potentially resetting table context."""
        if prev_row_type == RowType.VALUE:
            self._reset_current_table()

        if self._current_table and len(self._current_table.columns) > 0:
            if not self._is_value_row_in_current_table(
                row_cells, False, self._min_column_matching_rate
            ) or not self._current_table.match_cell_ranges(row_cells):
                self._reset_current_table()

        blocks: list[DocumentBlock] = []
        for cell in row_cells:
            if cell.is_effectively_empty:
                continue
            if cell.is_header_candidate:
                if not self._add_row_header(cell):
                    self._reset_current_table()
                    level = self._indent_manager.calculate_indent_level(cell.ci, True)
                    blocks.append(ListItemBlock(level, f"{cell.display_text}\n"))
                break
        return blocks

    def _process_value_row(
        self, row_cells: list[CellData], skip_first_header_cell: bool
    ) -> list[DocumentBlock]:
        """Determines if a data row belongs to an active table or should be a list item."""
        if len(self._get_active_cells(row_cells, skip_first_header_cell)) == 0:
            return []
        elif self._is_value_row_in_current_table(
            row_cells, skip_first_header_cell, self._min_column_matching_rate
        ):
            return self._process_table_value_row(row_cells, skip_first_header_cell)
        else:
            self._reset_current_table()
            return self._process_list_value_row(row_cells, skip_first_header_cell)

    def _is_value_row_in_current_table(
        self,
        row_cells: list[CellData],
        skip_first_header_cell: bool,
        min_column_matching_rate: float,
    ) -> bool:
        """
        Validates if the current row's filled columns align
        with the current table's header structure.
        """
        if self._current_table is None:
            return False

        active_cells = self._get_active_cells(row_cells, skip_first_header_cell)
        if len(active_cells) == 0:
            return False

        # Calculate how many cells fit into existing table columns
        # TODO: Add table column for small overflow cell.
        matches = sum(
            self._current_table.find_column_index(cell.ci)[1] for cell in active_cells
        )

        return matches / len(active_cells) > min_column_matching_rate

    def _collect_header_elements(
        self, row_cells: list[CellData]
    ) -> tuple[list[DocumentBlock], list[HeaderCell], list[CellData]]:
        """Separates row-level headers (vertical merges) from table-level headers (horizontal)."""
        blocks: list[DocumentBlock] = []
        header_cells: list[HeaderCell] = []
        non_header_cells: list[CellData] = []
        is_first_header = True
        for cell in row_cells:
            if cell.is_effectively_empty:
                continue

            if not cell.is_header_candidate:
                non_header_cells.append(cell)
                continue

            if is_first_header and self._is_row_header_cell(cell, row_cells):
                if not self._add_row_header(cell):
                    level = self._indent_manager.calculate_indent_level(cell.ci, True)
                    blocks.append(ListItemBlock(level, f"{cell.display_text}\n"))
            else:
                header_cells.append(
                    HeaderCell(cell.display_text, cell.left, cell.right + 1)
                )
            is_first_header = False
        return blocks, header_cells, non_header_cells

    def _is_row_header_cell(self, cell: CellData, row_cells: list[CellData]) -> bool:
        """Identifies vertically merged cells that act as labels for the rows beside them."""
        # Must span more than one row vertically
        if not (cell.top < cell.bottom):
            return False
        if cell.right + 1 >= len(row_cells):
            return True
        next_cells = [
            cell
            for cell in row_cells[cell.right + 1 :]
            if not cell.is_effectively_empty
        ]
        next_cell = next_cells[0] if next_cells else row_cells[cell.right + 1]
        # If the neighbor cell doesn't share the vertical span, this is likely a row label
        return not (cell.top == next_cell.top and cell.bottom == next_cell.bottom)

    def _process_table_value_row(
        self, row_cells: list[CellData], skip_first: bool
    ) -> list[DocumentBlock]:
        """Appends cell data to the active table and commits the row."""
        if self._current_table is None:
            return []
        active_cells = self._get_active_cells(row_cells, skip_first)
        for cell in active_cells:
            self._current_table.add_cell_data(cell)
        self._current_table.commit_row()
        return []

    def _process_list_value_row(
        self, row_cells: list[CellData], skip_first_header: bool
    ) -> list[DocumentBlock]:
        """Converts values into indented bullet points based on their column position."""
        active_cells = self._get_active_cells(row_cells, skip_first_header)
        blocks: list[DocumentBlock] = []
        for i, cell in enumerate(active_cells):
            if i == 0:
                # First cell in the row gets the bullet
                level = self._indent_manager.calculate_indent_level(cell.ci, True)
                blocks.append(ListItemBlock(level, cell.display_text))
            else:
                # Following cells in the same row are appended as text
                blocks.append(TextBlock(" " + cell.display_text))
        return blocks

    def _get_active_cells(
        self, row_cells: list[CellData], skip_first_header: bool
    ) -> list[CellData]:
        """Filters empty cells and optionally ignores the leading header-styled cell."""
        active_cells = [cell for cell in row_cells if not cell.is_effectively_empty]
        if not active_cells:
            return []

        first_active_cell = active_cells[0]
        if skip_first_header and first_active_cell.is_header_candidate:
            active_cells = active_cells[1:]

        return active_cells

    def _reset_current_table(self) -> None:
        """Finalizes and clears the current table context."""
        if self._current_table:
            self._current_table.commit_row()
        self._current_table = None


class MarkdownFormatter:
    """Renders structured DocumentBlocks into a Markdown-formatted string."""

    def __init__(self, config: ParserConfig):
        self._indent_spaces = config.indent_spaces
        self._table_indent_offset_spaces = 2

    def format(self, blocks: list[DocumentBlock]) -> str:
        """Iterates through blocks and applies Markdown syntax rules."""
        res: list[str] = []
        prev_block: DocumentBlock | None = None
        for block in blocks:
            match block:
                case HeaderBlock(level, text):
                    res.append(f"\n{'#' * level} {text}\n")
                    prev_block = block

                case ListItemBlock(level, text):
                    res.append(f"{self._make_indent(level)}* {text}")
                    prev_block = block

                case TableBlock(_, _, level, columns, rows):
                    if len(block.get_leaf_headers()) == 1:
                        current_headers = columns
                        while current_headers:
                            res.append(
                                f"{self._make_indent(level)}* {current_headers[0].value}\n"
                            )
                            current_headers = current_headers[0].children
                        for row in rows:
                            if row.row_header:
                                res.append(
                                    self.format_cell(row.row_header, False, level)
                                )
                                res.append("\n")
                            for cell in row.cells:
                                res.append(self.format_cell(cell, False, level))
                            if row.cells:
                                res.append("\n")
                        prev_block = ListItemBlock(level, columns[0].value)
                    else:
                        indent1 = self._make_indent(level)
                        # Data rows are further indented to align with the list bullet
                        indent2 = indent1 + " " * self._table_indent_offset_spaces
                        # Empty lines help downstream consumers (like LLMs) parse structure
                        if not isinstance(prev_block, TableBlock):
                            res.append("\n")
                        # Render Table Header
                        has_row_header = any(row.row_header for row in rows)
                        col_texts = []
                        if has_row_header:
                            col_texts.append("項目")
                        col_texts.extend(block.get_flattened_header_texts())
                        res.append(f"{indent1}* | {' | '.join(col_texts)} |\n")
                        # Render Markdown Table Separator (|---|---|)
                        res.append(f"{indent2}|{'|'.join(['---'] * len(col_texts))}|\n")
                        # Render Data Rows
                        for row in rows:
                            row_texts = []
                            if has_row_header:
                                row_texts.append(self.format_cell(row.row_header, True))
                            row_texts.extend(
                                [self.format_cell(cell, True) for cell in row.cells]
                            )
                            res.append(f"{indent2}| {' | '.join(row_texts)} |\n")
                        res.append("\n")
                        prev_block = block

                case TextBlock(text):
                    res.append(text)
                    prev_block = block

                case HorizontalRuleBlock():
                    # Ensure vertical spacing for the HR
                    if isinstance(prev_block, TableBlock):
                        res.append("---\n")
                    else:
                        res.append("\n---\n")
                    prev_block = block
        return "".join(res).strip() + "\n"

    def format_cell(
        self, cell: TableCell, is_in_md_table: bool, table_level: int = 0
    ) -> str:
        """Formats content within a table cell, handling mixed text and list items."""
        if not cell:
            return ""

        texts: list[str] = []
        for block in cell:
            match block:
                case TextBlock(text):
                    texts.append(text)
                case ListItemBlock(level, text):
                    if is_in_md_table:
                        texts.append(text)
                    else:
                        actual_level = table_level + level + 1
                        texts.append(f"{self._make_indent(actual_level)}* {text}")
                case _:
                    raise NotImplementedError()

        return " ".join(texts)

    def _make_indent(self, level: int) -> str:
        """Returns the appropriate number of leading spaces for an indent level."""
        return " " * self._indent_spaces * level
