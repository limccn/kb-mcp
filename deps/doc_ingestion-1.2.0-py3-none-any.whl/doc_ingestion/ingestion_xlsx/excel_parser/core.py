from datetime import datetime, timezone
from pathlib import Path

from ._version import __version__
from .datasource import DataSourceFactory, ExcelRowReader
from .parser import ExcelStructureParser, MarkdownFormatter
from .schema import (DocumentBlock, HeaderBlock, HorizontalRuleBlock,
                     ParserConfig)


class ExcelToMarkdownConverter:
    """
    Orchestrates the conversion process by bridging data sources,
    structural parsing, and markdown formatting.
    """

    SUPPORTED_EXTENSIONS = DataSourceFactory.SUPPORTED_EXTENSIONS

    @classmethod
    def is_supported(cls, file_path: str | Path) -> bool:
        """Determines if the file extension is supported by available data sources."""
        return Path(file_path).suffix.lower() in cls.SUPPORTED_EXTENSIONS

    def __init__(self, config: ParserConfig = ParserConfig()):
        self.config = config

    def convert_to_markdown(self, file_path: Path) -> str:
        """
        Main entry point for converting an entire Excel file into a Markdown string.
        Processes all worksheets and combines them into one document.
        """
        data_sources = DataSourceFactory.create_from_file(file_path, self.config)
        readers = [ExcelRowReader(ds, self.config) for ds in data_sources]

        document_blocks = self._get_document_blocks(readers)

        # Set the filename as the primary H1 header
        document_blocks.insert(0, HeaderBlock(1, file_path.name))

        formatter = MarkdownFormatter(self.config)
        return formatter.format(document_blocks)

    def convert_to_content_and_metadata(self, file_path: Path) -> tuple[str, dict]:
        """
        Converts the file and returns both the Markdown content and
        a metadata dictionary containing version and timestamp info.
        """
        full_text = self.convert_to_markdown(file_path)
        return full_text, {
            "metadataAttributes": {
                "extraction_method": "custom_excel_parser",
                "parser_version": __version__,
                "extracted_at": datetime.now(timezone.utc).isoformat(),
            }
        }

    def convert_sheet(self, reader: ExcelRowReader) -> str:
        """Helper to convert a single worksheet into Markdown."""
        formatter = MarkdownFormatter(self.config)
        return formatter.format(self._get_sheet_blocks(reader))

    def _get_document_blocks(
        self, readers: list[ExcelRowReader]
    ) -> list[DocumentBlock]:
        """Iterates through readers and compiles all document blocks across sheets."""
        all_blocks: list[DocumentBlock] = []

        for reader in readers:
            blocks = self._get_sheet_blocks(reader)

            if not blocks:
                continue

            # Separate sheets with a horizontal rule if content already exists
            if all_blocks:
                all_blocks.append(HorizontalRuleBlock())

            all_blocks.extend(blocks)

        return all_blocks

    def _get_sheet_blocks(self, reader: ExcelRowReader) -> list[DocumentBlock]:
        """Parses a sheet row-by-row and prepends a sheet name header (H2)."""
        # Read every row within the data source boundaries
        sheet_cells = [
            reader.parse_row_cells(ri)
            for ri in range(reader.data_source.start_row, reader.data_source.nrows)
        ]

        parser = ExcelStructureParser()
        blocks: list[DocumentBlock] = parser.process(sheet_cells)

        # Add sheet title unless it's empty and configuration says to remove it
        if not (self.config.remove_empty_sheets and not blocks):
            blocks.insert(0, HeaderBlock(2, reader.data_source.sheet_name))

        return blocks
