import copy
from dataclasses import dataclass, field, fields
from datetime import datetime
from enum import Enum, auto

# Type alias for basic values extracted from Excel
type ExcelValue = str | float | int | datetime | bool | None

type TableCell = list[DocumentBlock]

# Type alias for all possible block types in the document tree
type DocumentBlock = TextBlock | HeaderBlock | ListItemBlock | TableBlock | HorizontalRuleBlock


@dataclass(frozen=True)
class ParserConfig:
    """Settings to control filtering and formatting during parsing."""

    exclude_sheet_names: list[str] = field(default_factory=list)
    remove_hidden_sheets: bool = True
    remove_outside_print_area: bool = True
    remove_strikethrough: bool = True
    remove_empty_sheets: bool = True
    indent_spaces: int = 2

    @classmethod
    def from_dict(cls, data: dict | None) -> "ParserConfig":
        """Instantiates config from a dictionary, filtering out unknown keys."""
        if not data:
            return cls()
        valid_keys = {f.name for f in fields(cls)}
        filtered_data = {
            k: v for k, v in data.items() if k in valid_keys and v is not None
        }
        return cls(**filtered_data)


class RowType(Enum):
    """Structural classification of an Excel row."""

    # No visible data.
    EMPTY = auto()
    # Standard data row.
    VALUE = auto()
    # A table header defining column labels.
    HEADER = auto()
    # A row header (often a single colored cell).
    INDEX = auto()
    # A row with mixed key-value patterns.
    COMPLEX = auto()
    # State when the pattern is ambiguous.
    UNKNOWN = auto()


@dataclass(frozen=True)
class RichTextSegment:
    """Represents a fragment of text with its own formatting (e.g., strikethrough)."""

    text: str
    is_strikethrough: bool


@dataclass(frozen=True)
class CellData:
    """Normalized data container for an Excel cell, abstracted from library-specific types."""

    ri: int
    ci: int
    value: ExcelValue
    raw_text: str
    display_text: str  # Post-processed text with Markdown tags (e.g. <br>, ~~)
    is_strikethrough: bool
    background_rgb: tuple[int, int, int] | None
    merge_range: tuple[int, int, int, int] | None  # (r1, r2, c1, c2)
    rich_text: list[RichTextSegment] = field(default_factory=list)

    @property
    def top(self) -> int:
        return self.merge_range[0] if self.merge_range else self.ri

    @property
    def bottom(self) -> int:
        return self.merge_range[1] - 1 if self.merge_range else self.ri

    @property
    def left(self) -> int:
        return self.merge_range[2] if self.merge_range else self.ci

    @property
    def right(self) -> int:
        return self.merge_range[3] - 1 if self.merge_range else self.ci

    @property
    def is_empty(self) -> bool:
        return self.value == ""

    @property
    def is_effectively_empty(self) -> bool:
        """Returns True if text is empty after removing struck-out content."""
        return self.display_text == ""

    @property
    def has_background_color(self) -> bool:
        return self.background_rgb is not None

    @property
    def is_gray(self) -> bool:
        """Returns True if the background color is a shade of gray (R=G=B)."""
        if self.background_rgb is None:
            return False
        r, g, b = self.background_rgb
        return r == g == b

    @property
    def is_header_candidate(self) -> bool:
        """Heuristic: non-gray background color usually indicates a header/label."""
        return self.has_background_color and not self.is_gray


class IndentManager:
    def __init__(self) -> None:
        self._indent_level_cols: list[tuple[int, bool]] = []

    def calculate_indent_level(self, ci: int, is_value_row: bool) -> int:
        """
        Computes the indentation depth by tracking column indexes.
        Deepens or shallows the 'stack' as columns move right or left.
        Identical column indices may exist for different semantic types (header vs value).
        """
        new_stack = []
        for s_ci, s_is_value in self._indent_level_cols:
            if s_ci < ci:
                new_stack.append((s_ci, s_is_value))
            elif s_ci == ci:
                # Overwrite if switching from a value-row to a header-row at the same column
                if not is_value_row and s_is_value:
                    continue
                new_stack.append((s_ci, s_is_value))
        self._indent_level_cols = new_stack

        key = (ci, is_value_row)
        if key not in self._indent_level_cols:
            self._indent_level_cols.append(key)

        return self._indent_level_cols.index(key)

    def clear(self) -> None:
        self._indent_level_cols.clear()


# --- Document Block Definitions ---


@dataclass(frozen=True)
class TextBlock:
    """Simple raw text wrapper."""

    text: str


@dataclass(frozen=True)
class HeaderBlock:
    """Markdown header (H1, H2, etc.)."""

    level: int
    text: str


@dataclass(frozen=True)
class ListItemBlock:
    """Markdown bullet point with indentation level."""

    level: int
    text: str


@dataclass(frozen=True)
class RowBoundary:
    """Internal metrics used by RowTypeResolver to determine structural role of a row."""

    valid_col_from: int
    valid_col_to: int
    header_col_from: int
    header_col_to: int
    is_complex_row: bool
    valid_header_cell_rate_of_header: float
    valid_header_cell_rate_of_valid: float


@dataclass(frozen=False)
class HeaderCell:
    """Defines a table column's label and its physical Excel column span (0-indexed)."""

    value: str
    col_from: int
    col_to: int
    children: list["HeaderCell"] = field(default_factory=list)

    @property
    def is_leaf(self) -> bool:
        return len(self.children) == 0

    def contains(self, ci: int) -> bool:
        return self.col_from <= ci < self.col_to

    def contains_header(self, header: "HeaderCell") -> bool:
        return self.col_from <= header.col_from and header.col_to <= self.col_to

    def get_leaf_columns(self) -> list["HeaderCell"]:
        """Flattens the header tree into leaf columns."""
        if self.is_leaf:
            return [self]
        leaves = []
        for child in self.children:
            leaves.extend(child.get_leaf_columns())
        return leaves


@dataclass(frozen=False)
class TableRow:
    row_header: TableCell = field(default_factory=list)
    cells: list[TableCell] = field(default_factory=list)


@dataclass(frozen=False)
class TableBlock:
    """
    Constructs a Markdown table row-by-row.
    Maps Excel cells to columns using col_from/col_to boundaries.
    """

    _ri: int
    _ci: int
    _indent_level: int
    _columns: list[HeaderCell]
    _column_managers: list[IndentManager] = field(init=False, repr=False)
    _rows: list[TableRow] = field(default_factory=list, repr=False)

    # State tracking for the row currently being parsed
    _current_row_header: TableCell = field(init=False, default_factory=list)
    _current_line: list[TableCell] = field(init=False, default_factory=list)
    _current_cell: TableCell = field(init=False, default_factory=list)
    _is_current_row_finished: bool = field(init=False, default=False)

    _extra_header_name_left = "付帯情報"
    _extra_header_name_right = "備考"

    def __post_init__(self):
        self._column_managers = [IndentManager() for _ in range(len(self._columns))]

    @property
    def ri(self) -> int:
        return self._ri

    @property
    def ci(self) -> int:
        return self._ci

    @property
    def indent_level(self) -> int:
        return self._indent_level

    @indent_level.setter
    def indent_level(self, value: int):
        self._indent_level = value

    @property
    def columns(self) -> list[HeaderCell]:
        return list(self._columns)

    @property
    def rows(self) -> list[TableRow]:
        return copy.deepcopy(self._rows)

    def add_row_header(self, cell: CellData) -> None:
        """Handles vertical headers by assigning them to the row_header buffer."""
        h_idx, h_idx_found = self.find_column_index(cell.ci)
        if h_idx_found:
            header = self._columns[h_idx]
            if cell.left == header.col_from and cell.right + 1 == header.col_to:
                self.add_cell_data(cell)
                return

        manager = self._column_managers[0] if self._column_managers else IndentManager()
        level = manager.calculate_indent_level(cell.ci, True)
        self._current_row_header.append(ListItemBlock(level, cell.display_text))

    def integrate_sub_headers(self, new_cells: list[HeaderCell]) -> bool:
        """Merges a new row of header cells into the existing multi-level structure."""
        if not self._contains_any_header(new_cells) or not self.match_cell_ranges(
            new_cells
        ):
            return False

        remain_cells = [cell for cell in new_cells if not self._insert_column(cell)]
        for parent in self._columns:
            self._integrate_sub_headers(parent, remain_cells)

        self._extend_columns(new_cells)

        self._column_managers.extend([IndentManager() for _ in range(len(new_cells))])

        return True

    def _integrate_sub_headers(
        self, parent: HeaderCell, new_cells: list[HeaderCell]
    ) -> None:
        """Recursively inserts sub-headers into the appropriate parent."""
        sub_children = [nc for nc in new_cells if parent.contains_header(nc)]

        if not sub_children:
            return

        if parent.is_leaf:
            parent.children = sub_children
        else:
            for child in parent.children:
                self._integrate_sub_headers(child, sub_children)

    def _extend_columns(self, cells: list[HeaderCell]) -> None:
        """Extends table boundaries if header cells are detected outside current range."""
        for cell in reversed(cells):
            if cell.col_to - 1 < self.columns[0].col_from:
                self._extend_column_left(cell.value, cell.col_from, cell.col_to)
        for cell in cells:
            if cell.col_from > self.columns[-1].col_to - 1:
                self._extend_column_right(cell.value, cell.col_from, cell.col_to)

    def _insert_column(self, cell: HeaderCell) -> bool:
        """Inserts a column between existing headers if a physical gap exists."""
        for i in range(len(self._columns[:-1])):
            column1 = self._columns[i]
            column2 = self._columns[i + 1]
            if column1.col_to <= cell.col_from and cell.col_to <= column2.col_from:
                self._columns.insert(i + 1, cell)
                return True
        return False

    def _extend_column_left(self, value: str, col_from: int, col_to: int) -> None:
        self._columns.insert(
            0,
            HeaderCell(value, col_from, col_to),
        )
        self._column_managers.insert(0, IndentManager())
        for row in self._rows:
            row.cells.insert(0, [])

    def _extend_column_right(self, value: str, col_from: int, col_to: int) -> None:
        self._columns.append(HeaderCell(value, col_from, col_to))
        self._column_managers.append(IndentManager())

    def add_cell_data(self, cell: CellData) -> None:
        """Finds the correct column for an Excel cell and handles text concatenation."""
        if self._is_current_row_finished:
            return

        h_idx, h_idx_found = self.find_leaf_column_index(cell.ci)

        if not h_idx_found and len(self._columns) > 0:
            leaf_headers = self.get_leaf_headers()
            if cell.ci < leaf_headers[0].col_from:
                if leaf_headers[0].value != self._extra_header_name_left:
                    self._extend_column_left(
                        self._extra_header_name_left,
                        cell.ci,
                        self._columns[0].col_from,
                    )
                    leaf_headers = self.get_leaf_headers()
                else:
                    leaf_headers[0] = HeaderCell(
                        self._extra_header_name_left,
                        cell.ci,
                        leaf_headers[0].col_to,
                    )
                h_idx = 0
                h_idx_found = True
            elif cell.ci >= leaf_headers[-1].col_to:
                if leaf_headers[-1].value != self._extra_header_name_right:
                    self._extend_column_right(
                        self._extra_header_name_right,
                        self._columns[-1].col_to,
                        cell.ci + 1,
                    )
                    leaf_headers = self.get_leaf_headers()
                else:
                    leaf_headers[-1] = HeaderCell(
                        self._extra_header_name_right,
                        leaf_headers[-1].col_from,
                        cell.ci + 1,
                    )
                h_idx = len(leaf_headers) - 1
                h_idx_found = True

        # Fill any skipped columns with empty values if the data skips over them
        while len(self._current_line) < h_idx:
            self._current_line.append(copy.deepcopy(self._current_cell))
            self._current_cell = []

        # If cell is outside defined column range, consider the row finished
        if not h_idx_found and (
            len(leaf_headers) > 0
            and not (leaf_headers[0].col_from <= cell.ci < leaf_headers[-1].col_to)
        ):
            self._is_current_row_finished = True
            return

        if not self._current_cell:
            manager = self._column_managers[h_idx]
            relative_level = manager.calculate_indent_level(cell.ci, True)
            self._current_cell.append(ListItemBlock(relative_level, cell.display_text))
        else:
            self._current_cell.append(TextBlock(cell.display_text))

    def commit_row(self) -> None:
        """Finalizes buffered cell data and adds it to the internal row list."""
        if self._current_cell:
            self._current_line.append(self._current_cell)
            self._current_cell = []
        if self._current_row_header or self._current_line:
            self._rows.append(
                TableRow(
                    copy.deepcopy(self._current_row_header),
                    copy.deepcopy(self._current_line),
                )
            )

        # Reset state for the next row
        self._current_row_header = []
        self._current_line = []
        self._current_cell = []
        self._is_current_row_finished = False

    def match_cell_ranges(self, cells: list[CellData] | list[HeaderCell]) -> bool:
        """Validates if cell spans match the boundaries of defined table columns."""
        leaves = self.get_leaf_headers()
        for cell in cells:
            for header in leaves:
                if isinstance(cell, CellData):
                    c1, c2 = cell.left, cell.right + 1
                else:
                    c1, c2 = cell.col_from, cell.col_to
                if header.contains(c1) != header.contains(c2 - 1):
                    return False
        return True

    def _contains_any_header(self, cells: list[CellData] | list[HeaderCell]) -> bool:
        """Checks if any provided cells overlap with the table's defined column range."""
        for cell in cells:
            for header in self._columns:
                if isinstance(cell, CellData):
                    c1, c2 = cell.left, cell.right + 1
                else:
                    c1, c2 = cell.col_from, cell.col_to
                if header.contains(c1) or header.contains(c2 - 1):
                    return True
        return False

    def find_column_index(self, excel_ci: int) -> tuple[int, bool]:
        """Maps an Excel column index (integer) to the index of HeaderCell list."""
        for i, header_cell in enumerate(self.columns):
            if excel_ci < header_cell.col_from:
                return i, False
            elif excel_ci < header_cell.col_to:
                return i, True
        else:
            return len(self.columns), False

    def get_flattened_header_texts(
        self, headers: list[HeaderCell] | None = None, prefix=""
    ) -> list[str]:
        """Returns breadcrumb-style text labels for all leaf headers."""
        if headers is None:
            headers = self._columns
        texts = []
        for h in headers:
            current_label = f"{prefix}{h.value}"
            if h.is_leaf:
                texts.append(current_label)
            else:
                texts.extend(
                    self.get_flattened_header_texts(h.children, f"{current_label} > ")
                )
        return texts

    def get_leaf_headers(self) -> list[HeaderCell]:
        leaves = []
        for col in self._columns:
            leaves.extend(col.get_leaf_columns())
        return leaves

    def find_leaf_column_index(self, excel_ci: int) -> tuple[int, bool]:
        """Maps index to a specific leaf header."""
        leaves = self.get_leaf_headers()
        for i, leaf in enumerate(leaves):
            if leaf.col_from <= excel_ci < leaf.col_to:
                return i, True
        return -1, False


@dataclass(frozen=True)
class HorizontalRuleBlock:
    """Represents '---' divider in Markdown."""

    pass
