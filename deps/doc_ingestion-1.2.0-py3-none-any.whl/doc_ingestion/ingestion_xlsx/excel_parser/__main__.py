import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

import yaml
from loguru import logger

from ._version import __version__
from .runner import BatchProcessor
from .schema import ParserConfig

DEFAULT_CONFIG = Path("parser_config.yaml")
DEFAULT_TIMEOUT_SECONDS = 40.0


def setup_logging(verbose: bool, output_dir: Path) -> None:
    """
    Sets up a dual-logging system:
    1. Colorized console output to stderr.
    2. Persistent log file with rotation in the output directory.
    """
    logger.remove()

    level = "DEBUG" if verbose else "INFO"
    logger.add(
        sys.stderr,
        level=level,
        colorize=True,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
            "<level>{message}</level>"
        ),
    )

    log_file = output_dir / "process.log"
    logger.add(
        log_file,
        rotation="10 MB",
        level="DEBUG",
        encoding="utf-8",
        enqueue=True,  # Thread-safe logging for multiprocessing
    )


def load_config(config_path: str | Path | None = None) -> ParserConfig:
    """
    Load parser configuration from YAML file.
    If no file is provided, default values are used.
    Returns a ParserConfig instance with either loaded or default values.
    """
    if not config_path:
        logger.info("No Config file specified. Using defaults.")
        return ParserConfig()

    config_path = Path(config_path)

    if config_path.is_file():
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            logger.info(f"Config file {config_path} was used.")
            return ParserConfig.from_dict(data)

    logger.warning(f"Config file {config_path} not found. Using defaults.")
    return ParserConfig()


@dataclass
class Args:
    """Type-safe container for parsed CLI arguments."""

    input_files: list[Path]
    output_dir: Path
    config: Path
    base_dir: Path | None
    preserve_struct: bool
    recursive: bool
    stats: bool
    timeout: float
    verbose: bool


def parse_args() -> Args:
    """Defines and parses the command line interface."""
    parser = argparse.ArgumentParser(
        prog="python -m src.excel_parser",
        usage="python -m src.excel_parser <inputs>... [options]",
        description="Convert Excel files to Markdown. Supports glob patterns and .txt list files.",
    )

    parser.add_argument(
        "input_files",
        type=Path,
        nargs="+",
        help=(
            "One or more paths to Excel files, directories, or .txt list files. "
            "By default, directories are searched non-recursively unless -r is specified."
        ),
    )

    parser.add_argument(
        "-o",
        "--output_dir",
        type=Path,
        default=Path.cwd(),
        help=(
            f"Directory where '{BatchProcessor.OUTPUT_SUBDIR}/' and stats will be created "
            "(default: current directory)."
        ),
    )

    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        default=DEFAULT_CONFIG,
        help=(
            "Path to parser configuration YAML file. "
            "If omitted, default config file is used."
        ),
    )

    parser.add_argument(
        "-b",
        "--base_dir",
        type=Path,
        default=None,
        help=(
            "Base directory for resolving relative paths in .txt lists. "
            "Also serves as the root for --preserve_struct calculation."
        ),
    )

    parser.add_argument(
        "-p",
        "--preserve_struct",
        action="store_true",
        help=(
            f"Replicate input directory structure inside '{BatchProcessor.OUTPUT_SUBDIR}/'. "
            "Uses --base_dir as root if provided, otherwise calculates the common ancestor."
        ),
    )

    parser.add_argument(
        "-r",
        "--recursive",
        action="store_true",
        help="Search for Excel files in subdirectories recursively when a directory is specified.",
    )

    parser.add_argument(
        "-s",
        "--stats",
        action="store_true",
        help="Generate 'conversion_stats.csv' in the output directory.",
    )

    parser.add_argument(
        "-t",
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT_SECONDS,
        help="Maximum time (seconds) allowed for each individual file conversion.",
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"Excel Parser Version: {__version__}",
    )

    parser.add_argument(
        "-V",
        "--verbose",
        action="store_true",
        help="Show all warnings in the console after processing.",
    )

    return Args(**vars(parser.parse_args()))


def run(args: Args) -> None:
    """
    Main execution flow:
    1. Initialize the processor with config.
    2. Expand input paths (handling .txt files and globs).
    3. Execute the batch conversion process.
    """
    processor = BatchProcessor(load_config(args.config))

    # Pre-process input_files: extract paths from .txt files if encountered
    raw_inputs: list[str] = []
    for input_file in args.input_files:
        if input_file.suffix == ".txt":
            with open(input_file, "r", encoding="utf-8") as f:
                # Filter out empty lines and comments starting with '#'
                lines = [
                    line.strip()
                    for line in f
                    if line.strip() and not line.startswith("#")
                ]
            raw_inputs.extend(lines)
        else:
            raw_inputs.append(str(input_file))

    # Resolve all patterns/directories into a flat list of valid Excel files
    target_files = processor.expand_paths(raw_inputs, args.base_dir, args.recursive)

    if not target_files:
        logger.error("No valid Excel files found.")
        sys.exit(1)

    processor.process_all(
        target_files,
        args.output_dir,
        args.base_dir,
        args.preserve_struct,
        args.stats,
        args.timeout,
        args.verbose,
    )


def main() -> None:
    """Entry point for the console script."""
    args = parse_args()
    setup_logging(args.verbose, args.output_dir)
    run(args)


if __name__ == "__main__":
    main()
