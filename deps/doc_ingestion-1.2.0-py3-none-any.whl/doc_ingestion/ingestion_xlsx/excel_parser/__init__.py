"""
Package initialization for the Excel-to-Markdown converter.
Exposes the main converter class for easier imports.
"""

from .core import ExcelToMarkdownConverter
from .schema import ParserConfig

# Define the public API of the package
__all__ = ["ExcelToMarkdownConverter", "ParserConfig"]
