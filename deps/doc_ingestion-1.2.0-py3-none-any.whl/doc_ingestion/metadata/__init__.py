from .bedrock import write_metadata_json
