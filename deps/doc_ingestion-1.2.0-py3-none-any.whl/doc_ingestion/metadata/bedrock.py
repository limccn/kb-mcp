import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def write_metadata_json(pdf_path, output_path, chunk_result, config=None):
    config = config or {}
    pdf_p = Path(pdf_path)

    title = pdf_p.stem
    for h in chunk_result.get("heading_page_map", []):
        if h.get("level", 1) == 1:
            title = h["heading"]
            break

    pages = {h.get("page", 1) for h in chunk_result.get("heading_page_map", [])}
    page_count = max(pages) if pages else 0

    chunk_count = len(chunk_result.get("chunks", []))

    document_type = config.get("document_type", "datasheet")
    include_for_embedding = set(config.get("include_for_embedding", ["title"]))

    def _attr(value, type_name, key, include):
        if type_name == "STRING":
            return {
                "value": {"type": "STRING", "stringValue": str(value)},
                "includeForEmbedding": include,
            }
        elif type_name == "NUMBER":
            return {
                "value": {"type": "NUMBER", "numberValue": int(value)},
                "includeForEmbedding": include,
            }

    metadata = {
        "metadataAttributes": {
            "source": _attr(pdf_p.name, "STRING", "source", False),
            "title": _attr(title, "STRING", "title", "title" in include_for_embedding),
            "page_count": _attr(page_count, "NUMBER", "page_count", False),
            "chunk_count": _attr(chunk_count, "NUMBER", "chunk_count", False),
            "document_type": _attr(document_type, "STRING", "document_type", False),
        }
    }

    out_p = Path(output_path)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(metadata, ensure_ascii=False, indent=2)
    out_p.write_text(content, encoding="utf-8")

    size = out_p.stat().st_size
    if size >= 10240:
        logger.warning(f"metadata.json is {size} bytes, exceeds Bedrock 10KB limit")
    logger.info(f"metadata.json written: {out_p} ({size} bytes)")
