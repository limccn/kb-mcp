"""
pptx向けMarkdownチャンキングモジュール

parse_pptx で変換された Markdown をスライド単位でチャンク分割し、
各チャンクのメタデータに見出し情報 (Header 1 / Header 2) と
ページ番号 (page) を含める。

入力 Markdown にはページ番号マーカー (<!-- page:N -->) が埋め込まれており、
これをメタデータとして活用する。

分割戦略:
1. H2 (スライドタイトル) で一次分割
2. H1 (セクション) は分割せず各スライドのコンテキストとして保持
3. トークン上限内のスライドはそのまま 1 チャンク
4. トークン上限超過のスライドは RecursiveCharacterTextSplitter で再分割
5. 各チャンクにセクション見出し (H1) を付加してコンテキストを保持
"""

import argparse
import json
import logging
import re
from pathlib import Path

import tiktoken
from langchain_text_splitters import RecursiveCharacterTextSplitter
from ..chunking.page_metadata import (
    format_page_metadata,
    parse_markdown_page_markers,
    resolve_chunk_page_ranges,
)

logger = logging.getLogger(__name__)

ENCODING_NAME = "cl100k_base"
MAX_CHUNK_COUNT = 512

# ページマーカーのパターン
_PAGE_MARKER_RE = re.compile(r"<!--\s*page:(\d+)\s*-->")


def _count_tokens(text: str, enc=None) -> int:
    """tiktoken でトークン数を計算する"""
    if enc is None:
        enc = tiktoken.get_encoding(ENCODING_NAME)
    return len(enc.encode(text))


def _parse_slides(text: str) -> list[dict]:
    """Markdown テキストをスライド単位 (H2) で分割する。

    H1 はセクション見出しとして追跡し、各スライドの metadata に含める。
    ページマーカー (<!-- page:N -->) はページ番号メタデータとしてのみ使用し、
    それ自体では分割しない。

    Returns:
        [{"h1": str, "h2": str, "page": int|None,
          "heading_meta": dict, "body": str}, ...]
    """
    lines = text.split("\n")
    slides = []
    current_h1 = ""
    current_h2 = ""
    current_page = None
    section_page = None
    current_lines = []
    current_lines_with_markers = []
    leading_markers = []
    pending_page_markers = []

    def _flush():
        nonlocal current_h2, section_page, current_lines, current_lines_with_markers, leading_markers

        if current_h2 or current_lines:
            body = "\n".join(current_lines)
            body_with_markers = "\n".join(current_lines_with_markers)
            meta = {}
            if current_h1:
                meta["Header 1"] = current_h1
            if current_h2:
                meta["Header 2"] = current_h2
            slides.append(
                {
                    "h1": current_h1,
                    "h2": current_h2,
                    "page": section_page,
                    "heading_meta": meta,
                    "body": body,
                    "body_with_markers": body_with_markers,
                    "leading_markers": list(leading_markers),
                }
            )
        current_h2 = ""
        section_page = None
        current_lines = []
        current_lines_with_markers = []
        leading_markers = []

    def _append_body_line(line: str):
        nonlocal current_lines, current_lines_with_markers, pending_page_markers

        if pending_page_markers:
            current_lines_with_markers.extend(pending_page_markers)
            pending_page_markers = []
        current_lines.append(line)
        current_lines_with_markers.append(line)

    for line in lines:
        stripped = line.strip()

        # ページマーカー
        page_match = _PAGE_MARKER_RE.match(stripped)
        if page_match:
            current_page = int(page_match.group(1))
            pending_page_markers.append(line)
            continue

        if line.startswith("# ") and not line.startswith("## "):
            # H1: セクション見出し (分割せず追跡のみ)
            current_h1 = line[2:].strip()
        elif line.startswith("## ") and not line.startswith("### "):
            # H2: スライドタイトル (ここで分割)
            _flush()
            current_h2 = line[3:].strip()
            section_page = current_page
            leading_markers = list(pending_page_markers)
            pending_page_markers = []
        else:
            _append_body_line(line)

    _flush()
    return slides


def _resolve_page_range(markdown_with_markers: str, chunks: list[str]) -> list[tuple[int | None, int | None]]:
    """Resolve page ranges for chunk texts within a local markdown section."""
    page_marker_data = parse_markdown_page_markers(markdown_with_markers)
    if not page_marker_data["has_markers"]:
        return [(None, None) for _ in chunks]

    ranges, _ = resolve_chunk_page_ranges(chunks, page_marker_data)
    return ranges


def validate_chunks(results: list[dict], chunk_size: int) -> list[str]:
    """チャンク結果を検証し、警告メッセージのリストを返す。"""
    enc = tiktoken.get_encoding(ENCODING_NAME)
    warnings = []

    if len(results) >= MAX_CHUNK_COUNT:
        msg = f"WARNING: チャンク数が {MAX_CHUNK_COUNT} 以上です: {len(results)} チャンク"
        warnings.append(msg)
        logger.warning(msg)

    for chunk in results:
        token_count = _count_tokens(chunk["content"], enc)
        chunk["token_count"] = token_count
        if token_count > chunk_size:
            msg = (
                f"WARNING: Chunk {chunk['chunk_id']} のトークン数が chunk_size を超過: "
                f"{token_count} > {chunk_size}"
            )
            warnings.append(msg)
            logger.warning(msg)

    return warnings


def chunk_markdown_pptx(
    input_md_path: str,
    output_json_path: str,
    intermediate_md_path: str | None = None,
    chunk_size: int = 8192,
    chunk_overlap: int = 200,
) -> list[dict]:
    """pptx由来のMarkdownをスライド単位でチャンク分割する。

    各チャンクのメタデータに見出し (Header 1 / Header 2) と
    ページ番号 (page) を含める。

    Args:
        input_md_path: 入力Markdownファイルのパス
        output_json_path: 出力JSONファイルのパス
        intermediate_md_path: 中間Markdownファイルの保存パス
        chunk_size: チャンクサイズ (トークン数)
        chunk_overlap: チャンク間の重複 (トークン数)

    Returns:
        チャンク結果のリスト
    """
    input_path = Path(input_md_path)
    if not input_path.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_md_path}")

    markdown_text = input_path.read_text(encoding="utf-8")
    logger.info(f"入力ファイルを読み込みました: {input_md_path}")
    # 中間ファイル保存
    if intermediate_md_path:
        p = Path(intermediate_md_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(markdown_text, encoding="utf-8")
        logger.info(f"中間ファイル保存 [Markdown]: {intermediate_md_path}")

    enc = tiktoken.get_encoding(ENCODING_NAME)

    # スライド単位で分割
    slides = _parse_slides(markdown_text)
    logger.info(f"スライド分割数: {len(slides)}")

    # 各スライドをチャンク化
    all_chunks = []
    for slide_section in slides:
        # チャンクコンテンツを構築 (H1 + H2 + body)
        parts = []
        parts_with_markers = []
        if slide_section["h1"]:
            h1_text = f"# {slide_section['h1']}"
            parts.append(h1_text)
            parts_with_markers.append(h1_text)
        if slide_section["leading_markers"]:
            parts_with_markers.append("\n".join(slide_section["leading_markers"]))
        if slide_section["h2"]:
            h2_text = f"## {slide_section['h2']}"
            parts.append(h2_text)
            parts_with_markers.append(h2_text)
        body_clean = slide_section["body"].strip()
        if body_clean:
            parts.append(body_clean)
        body_with_markers = slide_section["body_with_markers"].strip()
        if body_with_markers:
            parts_with_markers.append(body_with_markers)

        full_text = "\n\n".join(parts)
        full_text_with_markers = "\n\n".join(parts_with_markers)
        if not full_text.strip():
            continue

        section_tokens = _count_tokens(full_text, enc)

        if section_tokens <= chunk_size:
            page_range = _resolve_page_range(full_text_with_markers, [full_text])[0]
            # トークン上限内: そのまま 1 チャンク
            all_chunks.append(
                {
                    "heading_meta": slide_section["heading_meta"],
                    "page": page_range[0] if page_range[0] is not None else slide_section["page"],
                    "page_end": page_range[1] if page_range[1] is not None else slide_section["page"],
                    "content": full_text,
                }
            )
        else:
            # トークン上限超過: RecursiveCharacterTextSplitter で再分割
            logger.info(f"スライド分割: page={slide_section['page']} " f"({section_tokens} tokens > {chunk_size})")
            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name=ENCODING_NAME,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
            sub_texts = text_splitter.split_text(full_text)
            page_ranges = _resolve_page_range(full_text_with_markers, sub_texts)
            for sub_text, page_range in zip(sub_texts, page_ranges):
                all_chunks.append(
                    {
                        "heading_meta": dict(slide_section["heading_meta"]),
                        "page": page_range[0] if page_range[0] is not None else slide_section["page"],
                        "page_end": page_range[1] if page_range[1] is not None else slide_section["page"],
                        "content": sub_text,
                    }
                )
            logger.info(f"  → {len(sub_texts)} サブチャンクに分割")

    logger.info(f"最終的なチャンク数: {len(all_chunks)}")

    # 結果リスト作成
    results = []
    for i, chunk in enumerate(all_chunks):
        page = chunk["page"]
        page_end = chunk["page_end"]
        metadata_str = format_page_metadata(page, page_end)

        chunk_data = {
            "chunk_id": i + 1,
            "metadata": metadata_str,
            "content_length": len(chunk["content"]),
            "content": chunk["content"],
        }
        results.append(chunk_data)
        logger.info(f"Chunk {i + 1}: Metadata={metadata_str}, " f"Content length={len(chunk['content'])} characters")

    # 検証
    warnings = validate_chunks(results, chunk_size)

    # JSON 保存
    output_path = Path(output_json_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    output_data = {
        "input_file": str(input_md_path),
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "total_chunks": len(results),
        "warnings": warnings,
        "chunks": results,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    logger.info(f"結果をJSONファイルに保存しました: {output_json_path}")

    return results


def main():
    parser = argparse.ArgumentParser(description="pptx由来Markdownをチャンク分割")
    parser.add_argument("--input_md_path", type=str, required=True, help="入力Markdownファイルのパス")
    parser.add_argument("--output_json", type=str, required=True, help="出力JSONファイルのパス")
    parser.add_argument("--chunk_size", type=int, default=8192, help="チャンクサイズ (トークン数)")
    parser.add_argument("--chunk_overlap", type=int, default=200, help="チャンク間の重複 (トークン数)")
    parser.add_argument("--intermediate_md", type=str, default=None, help="中間Markdown保存パス")
    args = parser.parse_args()

    chunk_markdown_pptx(
        input_md_path=args.input_md_path,
        output_json_path=args.output_json,
        intermediate_md_path=args.intermediate_md,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    main()
