import json
import sys
import tempfile
import unittest
from pathlib import Path


_HERE = Path(__file__).resolve().parent
_MODULE_ROOT = _HERE.parent.parent
if str(_MODULE_ROOT) not in sys.path:
    sys.path.insert(0, str(_MODULE_ROOT))

from doc_ingestion.ingestion_pptx.chunking_pptx import chunk_markdown_pptx


class ChunkingPptxTest(unittest.TestCase):
    def test_page_markers_become_page_range_metadata(self):
        markdown = """# Section
<!-- page:1 -->
## Overview

alpha

<!-- page:2 -->
beta

<!-- page:3 -->
gamma

## Details

delta
"""

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            input_md = tmp_path / "sample.md"
            output_json = tmp_path / "sample.json"
            input_md.write_text(markdown, encoding="utf-8")

            chunks = chunk_markdown_pptx(
                str(input_md),
                str(output_json),
                chunk_size=8192,
                chunk_overlap=200,
            )

            self.assertEqual(len(chunks), 2)
            self.assertEqual(chunks[0]["metadata"], "p.1-3")
            self.assertIn("## Overview", chunks[0]["content"])
            self.assertIn("alpha", chunks[0]["content"])
            self.assertIn("beta", chunks[0]["content"])
            self.assertIn("gamma", chunks[0]["content"])
            self.assertEqual(chunks[1]["metadata"], "p.3")
            self.assertIn("## Details", chunks[1]["content"])

            saved = json.loads(output_json.read_text(encoding="utf-8"))
            self.assertEqual(saved["total_chunks"], 2)

    def test_h1_only_slides_keep_content_and_gain_range_metadata(self):
        markdown = """# Title Slide
<!-- page:1 -->
cover

# Agenda
<!-- page:2 -->
alpha

<!-- page:3 -->
beta
"""

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            input_md = tmp_path / "sample.md"
            output_json = tmp_path / "sample.json"
            input_md.write_text(markdown, encoding="utf-8")

            chunks = chunk_markdown_pptx(
                str(input_md),
                str(output_json),
                chunk_size=8192,
                chunk_overlap=200,
            )

            self.assertEqual(len(chunks), 1)
            self.assertEqual(chunks[0]["metadata"], "p.1-3")
            self.assertIn("cover", chunks[0]["content"])
            self.assertIn("alpha", chunks[0]["content"])
            self.assertIn("beta", chunks[0]["content"])


if __name__ == "__main__":
    unittest.main()