from .ingestion import ingestion

__all__ = ["ingestion"]
