"""Page marker based metadata helpers for markdown chunking."""

import hashlib
import logging
import re
import unicodedata

logger = logging.getLogger(__name__)

PAGE_MARKER_RE = re.compile(r"<!--\s*page:(\d+)\s*-->")
PAGE_MARKER_LINE_RE = re.compile(r"^\s*(?:[-*]\s*)?<!--\s*page:(\d+)\s*-->\s*$")
CONTINUATION_MARKER = "※ 前のチャンクからの続き"


def parse_markdown_page_markers(text: str) -> dict:
    """Split page marker lines from markdown and keep page-to-line spans."""
    lines = text.split("\n")
    stripped_lines: list[str] = []
    stripped_line_pages: list[int | None] = []
    current_page: int | None = None
    marker_pages: list[int] = []

    for line in lines:
        line_match = PAGE_MARKER_LINE_RE.match(line)
        if line_match:
            if stripped_lines:
                stripped_lines[-1] = stripped_lines[-1].rstrip(" ")
            current_page = int(line_match.group(1))
            marker_pages.append(current_page)
            continue

        marker_matches = list(PAGE_MARKER_RE.finditer(line))
        if marker_matches:
            current_page = int(marker_matches[-1].group(1))
            marker_pages.extend(int(match.group(1)) for match in marker_matches)
            cleaned_line = PAGE_MARKER_RE.sub("", line).rstrip(" ")
            if re.fullmatch(r"\s*(?:[-*])?\s*", cleaned_line):
                if stripped_lines:
                    stripped_lines[-1] = stripped_lines[-1].rstrip(" ")
                continue
            line = cleaned_line

        stripped_lines.append(line)
        stripped_line_pages.append(current_page)

    stripped_text = "\n".join(stripped_lines)
    line_spans: list[dict] = []
    normalized_lines: list[str] = []
    non_empty_line_spans: list[dict] = []
    normalized_non_empty_lines: list[str] = []
    offset = 0
    for index, line in enumerate(stripped_lines):
        start = offset
        end = start + len(line)
        normalized_line = unicodedata.normalize("NFKC", line.rstrip())
        normalized_line = re.sub(r"\s+", " ", normalized_line).strip()
        line_spans.append(
            {
                "line_index": index,
                "start": start,
                "end": end,
                "page": stripped_line_pages[index],
                "normalized": normalized_line,
            }
        )
        normalized_lines.append(normalized_line)
        if normalized_line:
            non_empty_line_spans.append(line_spans[-1])
            normalized_non_empty_lines.append(normalized_line)
        if index < len(stripped_lines) - 1:
            offset = end + 1
        else:
            offset = end

    return {
        "has_markers": bool(marker_pages),
        "marker_count": len(marker_pages),
        "marker_pages": marker_pages,
        "stripped_text": stripped_text,
        "line_spans": line_spans,
        "normalized_lines": normalized_lines,
        "non_empty_line_spans": non_empty_line_spans,
        "normalized_non_empty_lines": normalized_non_empty_lines,
    }


def strip_page_markers(text: str) -> str:
    """Remove page marker lines from markdown text."""
    return parse_markdown_page_markers(text)["stripped_text"]


def format_page_metadata(page: int | None, page_end: int | None) -> str:
    """Format page metadata into the existing output format."""
    if page is not None and page_end is not None and page_end > page:
        return f"p.{page}-{page_end}"
    if page is not None:
        return f"p.{page}"
    return ""


def _lookup_text_for_chunk(content: str) -> str:
    """Extract the source-backed part of a chunk for marker lookup."""
    marker = f"{CONTINUATION_MARKER}\n\n"
    if marker in content:
        return content.split(marker, 1)[1]
    return content


def _normalize_lookup_lines(text: str) -> list[str]:
    """Normalize chunk content into comparable non-empty lines."""
    lines: list[str] = []
    for line in text.split("\n"):
        normalized = unicodedata.normalize("NFKC", line.rstrip())
        normalized = re.sub(r"\s+", " ", normalized).strip()
        if normalized:
            lines.append(normalized)
    return lines


def _find_line_sequence(needle_lines: list[str], haystack_lines: list[str], start_index: int) -> int:
    """Find a line sequence in the normalized markdown lines."""
    if not needle_lines:
        return -1

    max_start = len(haystack_lines) - len(needle_lines)
    if max_start < 0:
        return -1

    candidate_ranges = list(range(start_index, max_start + 1)) + list(range(0, start_index))
    for idx in candidate_ranges:
        if haystack_lines[idx: idx + len(needle_lines)] == needle_lines:
            return idx
    return -1


def _resolve_pages_for_span(start: int, end: int, line_spans: list[dict]) -> tuple[int | None, int | None]:
    """Resolve the page range for a character span in stripped markdown."""
    pages: list[int] = []
    for span in line_spans:
        span_page = span["page"]
        if span_page is None:
            continue
        span_start = span["start"]
        span_end = span["end"]
        overlaps = start <= span_end and end >= span_start
        if overlaps:
            pages.append(span_page)

    if not pages:
        return None, None

    return min(pages), max(pages)


def resolve_chunk_page_ranges(chunks: list[str], page_marker_data: dict) -> tuple[list[tuple[int | None, int | None]], dict]:
    """Resolve page ranges for ordered chunk contents against marker-free markdown."""
    line_spans = page_marker_data["non_empty_line_spans"]
    normalized_lines = page_marker_data["normalized_non_empty_lines"]
    cursor_line = 0
    results: list[tuple[int | None, int | None]] = []
    failures: list[int] = []

    for index, content in enumerate(chunks, start=1):
        lookup_text = _lookup_text_for_chunk(content)
        if not lookup_text.strip():
            results.append((None, None))
            continue

        lookup_lines = _normalize_lookup_lines(lookup_text)
        found_line = _find_line_sequence(lookup_lines, normalized_lines, cursor_line)
        if found_line < 0:
            logger.warning("Chunk %s could not be located in marker-free markdown", index)
            results.append((None, None))
            failures.append(index)
            continue

        matched_spans = line_spans[found_line: found_line + len(lookup_lines)]
        pages = [span["page"] for span in matched_spans if span["page"] is not None]
        if pages:
            results.append((min(pages), max(pages)))
        else:
            results.append((None, None))
        cursor_line = found_line + len(lookup_lines)

    verification = {
        "marker_count": page_marker_data["marker_count"],
        "marker_pages": page_marker_data["marker_pages"],
        "total_chunks": len(chunks),
        "located_chunks": len(chunks) - len(failures),
        "failed_chunk_ids": failures,
        "all_chunks_located": not failures,
        "stripped_markdown_sha256": hashlib.sha256(page_marker_data["stripped_text"].encode("utf-8")).hexdigest(),
        "chunk_content_sha256": hashlib.sha256("\x1e".join(chunks).encode("utf-8")).hexdigest(),
    }
    return results, verification
