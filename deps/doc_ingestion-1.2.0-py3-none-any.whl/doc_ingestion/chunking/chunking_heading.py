"""
見出しベース Markdown チャンキング (DOCX / PDF 共通)

見出し・ページ番号メタデータをチャンクに付与し、
トークン超過時のスマート分割 (H3 プレ分割 + 見出しコンテキスト継承) を行う。
"""

import json
import logging
import re
import unicodedata
from pathlib import Path

import tiktoken
from .preprocess_md import clean_table_spaces, clean_whitespace
from .page_metadata import (
    format_page_metadata,
    parse_markdown_page_markers,
    resolve_chunk_page_ranges,
)
from langchain_text_splitters import (MarkdownHeaderTextSplitter,
                                      RecursiveCharacterTextSplitter)

logger = logging.getLogger(__name__)

ENCODING_NAME = "cl100k_base"
MAX_CHUNK_COUNT = 512


def _count_tokens(text: str) -> int:
    """tiktoken でトークン数を計算する"""
    enc = tiktoken.get_encoding(ENCODING_NAME)
    return len(enc.encode(text))


# ---------------------------------------------
# 前処理
# ---------------------------------------------


def preprocess_parsed_markdown(text: str) -> str:
    """
    パース済み Markdown を前処理する。

    parse_docx / parse_pdf が既に正しい見出しレベルを付与しているため、
    見出しレベルの再調整は行わない。
    """
    # Unicode正規化 (NFKC): 康熙部首→CJK統合漢字、全角英数→半角 等
    text = unicodedata.normalize("NFKC", text)
    text = clean_table_spaces(text)
    text = clean_whitespace(text)
    return text


# ---------------------------------------------
# ページ番号マッピング
# ---------------------------------------------


def _find_page_for_heading(
    heading_text: str, heading_page_map: list[dict]
) -> tuple[int | None, int | None]:
    """
    チャンクの見出しテキストに対応するページ番号(開始・終了)を見出しマップから検索する。

    マッチ優先度:
      1. 完全一致
      2. 見出しマップの見出しがクエリの部分文字列 (最長優先)
      3. クエリが見出しマップの部分文字列 (最短=最も近い一致を優先)

    比較時は NFKC 正規化を適用し、全角/半角の差異を吸収する。

    Returns:
        (page, page_end): 開始ページと終了ページのタプル。見つからない場合は (None, None)。
    """
    if not heading_page_map:
        return None, None

    normalized = unicodedata.normalize("NFKC", heading_text.strip())
    if not normalized:
        return None, None

    # 1. 完全一致
    for entry in heading_page_map:
        if unicodedata.normalize("NFKC", entry["heading"].strip()) == normalized:
            return entry["page"], entry.get("page_end")

    # 2. h ⊂ query (見出しマップ側がクエリに含まれる) → 最長優先
    best_contains = None
    best_contains_len = 0
    # 3. query ⊂ h (クエリが見出しマップ側に含まれる) → 最短優先
    best_within = None
    best_within_len = float("inf")

    for entry in heading_page_map:
        h = unicodedata.normalize("NFKC", entry["heading"].strip())
        if h in normalized:
            if len(h) > best_contains_len:
                best_contains = entry
                best_contains_len = len(h)
        elif normalized in h:
            if len(h) < best_within_len:
                best_within = entry
                best_within_len = len(h)

    match = best_contains or best_within
    if match:
        return match["page"], match.get("page_end")
    return None, None


# ---------------------------------------------
# スマート分割
# ---------------------------------------------


def _merge_adjacent_chunks(docs: list, chunk_size: int) -> list:
    """同一 H1 内の隣接チャンクをトークン上限までグリーディにマージする。

    MarkdownHeaderTextSplitter が H1/H2 で細かく分割した結果を、
    H1 単位でなるべく大きなチャンクにまとめ直す。

    - H1 全体が chunk_size 以内 → 1チャンクにまとめる
    - H1 が大きい → 隣接 H2 をグルーピングして chunk_size 内に収める
    - マージ時のメタデータは先頭チャンクの H2 を保持（content 内に全見出しが
      インラインで含まれるため、H2 メタデータは参照用）
    """
    from langchain_core.documents import Document as LCDocument

    if not docs:
        return docs

    merged: list = []
    # 現在のマージ候補バッファ
    buf_content: list[str] = []
    buf_tokens = 0
    buf_metadata: dict = {}
    buf_h1: str | None = None

    def _flush():
        nonlocal buf_content, buf_tokens, buf_metadata, buf_h1
        if buf_content:
            merged.append(
                LCDocument(
                    page_content="\n\n".join(buf_content),
                    metadata=dict(buf_metadata),
                )
            )
            buf_content = []
            buf_tokens = 0
            buf_metadata = {}
            buf_h1 = None

    for doc in docs:
        h1 = doc.metadata.get("Header 1")
        content = doc.page_content
        tokens = _count_tokens(content)

        # H1 が変わったらフラッシュ
        if h1 != buf_h1 and buf_content:
            _flush()

        # バッファに追加すると超過する場合もフラッシュ
        # (join 用の \n\n ≒ 1 token を余裕として加算)
        if buf_content and buf_tokens + tokens + 1 > chunk_size:
            _flush()

        if not buf_content:
            buf_metadata = dict(doc.metadata)
            buf_h1 = h1

        buf_content.append(content)
        buf_tokens += tokens

    _flush()
    return merged


def _smart_split_large_document(doc, chunk_size: int, chunk_overlap: int):
    """
    トークン超過のドキュメントを分割する際に、見出しコンテキストを保持する。

    1. まず ### (H3) 境界で試行分割
    2. それでも大きい場合は RecursiveCharacterTextSplitter で分割
    3. 分割後の後続チャンクに親見出しコンテキストを付与
    """
    content = doc.page_content
    metadata = doc.metadata

    token_count = _count_tokens(content)
    if token_count <= chunk_size:
        return [doc]

    # H3 境界での分割を試みる
    h3_pattern = re.compile(r"^(### .+)$", re.MULTILINE)
    sections = h3_pattern.split(content)

    if len(sections) > 1:
        from langchain_core.documents import Document as LCDocument

        sub_docs = []
        current_text = ""
        current_h3 = None

        for section in sections:
            if h3_pattern.match(section.strip()):
                if current_text.strip():
                    sub_docs.append(
                        LCDocument(
                            page_content=current_text.strip(),
                            metadata={
                                **metadata,
                                **({"Header 3": current_h3} if current_h3 else {}),
                            },
                        )
                    )
                current_h3 = section.strip().lstrip("# ").strip()
                current_text = section + "\n"
            else:
                current_text += section

        if current_text.strip():
            sub_docs.append(
                LCDocument(
                    page_content=current_text.strip(),
                    metadata={
                        **metadata,
                        **({"Header 3": current_h3} if current_h3 else {}),
                    },
                )
            )

        result = []
        for sub_doc in sub_docs:
            if _count_tokens(sub_doc.page_content) <= chunk_size:
                result.append(sub_doc)
            else:
                result.extend(_fallback_split(sub_doc, chunk_size, chunk_overlap))
        return result

    return _fallback_split(doc, chunk_size, chunk_overlap)


# ---------------------------------------------
# ブロック分割ヘルパー
# ---------------------------------------------


def _is_header_only(text: str) -> bool:
    """テキストが見出し行のみで構成されているか判定する"""
    lines = [line for line in text.strip().split("\n") if line.strip()]
    return bool(lines) and all(line.strip().startswith("#") for line in lines)


def _is_table_block(text: str) -> bool:
    """テキストブロックが Markdown テーブルか判定する"""
    lines = [line for line in text.strip().split("\n") if line.strip()]
    return len(lines) >= 2 and all(line.strip().startswith("|") for line in lines)


def _split_into_blocks(text: str) -> list[str]:
    """テキストを段落・テーブル境界でブロックに分割する。

    \\n\\n 境界に加え、テーブル行 (| で始まる行) と非テーブル行の
    境界でも分割する。MarkdownHeaderTextSplitter が \\n のみで
    ヘッダー/本文/テーブルを結合するケースに対応する。
    """
    blocks: list[str] = []
    current_lines: list[str] = []
    in_table = False

    for line in text.split("\n"):
        stripped = line.strip()
        is_table_line = stripped.startswith("|")

        # 空行 = ブロック境界
        if not stripped:
            if current_lines:
                blocks.append("\n".join(current_lines))
                current_lines = []
            in_table = False
            continue

        # テーブル ↔ 非テーブルの切り替え = ブロック境界
        if is_table_line != in_table and current_lines:
            blocks.append("\n".join(current_lines))
            current_lines = []

        in_table = is_table_line
        current_lines.append(line)

    if current_lines:
        blocks.append("\n".join(current_lines))

    return [b for b in blocks if b.strip()]


def _split_table_rows(table_text: str, chunk_size: int) -> list[str]:
    """テーブルブロックを行単位で分割し、各チャンクにヘッダー行を付加する"""
    lines = [line for line in table_text.split("\n") if line.strip()]
    if len(lines) < 3:
        return [table_text]

    header_lines = lines[:2]  # 見出し行 + セパレータ行
    header_tokens = _count_tokens("\n".join(header_lines))
    data_rows = lines[2:]

    chunks: list[str] = []
    current_rows = list(header_lines)
    current_tokens = header_tokens

    for row in data_rows:
        row_tokens = _count_tokens(row)
        if current_tokens + row_tokens > chunk_size and len(current_rows) > 2:
            chunks.append("\n".join(current_rows))
            current_rows = list(header_lines)
            current_tokens = header_tokens
        current_rows.append(row)
        current_tokens += row_tokens

    if len(current_rows) > 2:
        chunks.append("\n".join(current_rows))

    return chunks if chunks else [table_text]


def _fallback_split(doc, chunk_size: int, chunk_overlap: int):
    """
    トークン超過ドキュメントをブロック単位で分割する。

    - 段落 (\\n\\n) およびテーブル境界で分割
    - テーブルは行境界で分割しヘッダーを各チャンクに保持
    - 見出しのみのブロックは後続コンテンツに結合
    - 後続チャンクに見出しコンテキストを付与
    """
    from langchain_core.documents import Document as LCDocument

    content = doc.page_content
    metadata = doc.metadata

    # --- Step 1: 段落・テーブル境界でブロック分割 ---
    raw_blocks = _split_into_blocks(content)
    blocks: list[str] = []
    for raw in raw_blocks:
        block = raw.strip()
        if not block:
            continue
        if _is_table_block(block) and _count_tokens(block) > chunk_size:
            blocks.extend(_split_table_rows(block, chunk_size))
        else:
            blocks.append(block)

    # --- Step 2: ブロックをトークン上限でグルーピング ---
    grouped: list[str] = []
    current_parts: list[str] = []
    current_tokens = 0

    for block in blocks:
        block_tokens = _count_tokens(block)

        if block_tokens > chunk_size:
            # 見出しのみの蓄積があればプレフィックスとして保持
            header_prefix = ""
            header_prefix_tokens = 0
            if current_parts and all(_is_header_only(p) for p in current_parts):
                header_prefix = "\n\n".join(current_parts) + "\n\n"
                header_prefix_tokens = _count_tokens(header_prefix)
                current_parts = []
                current_tokens = 0
            elif current_parts:
                grouped.append("\n\n".join(current_parts))
                current_parts = []
                current_tokens = 0

            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name=ENCODING_NAME,
                chunk_size=max(chunk_size - header_prefix_tokens, chunk_size // 2),
                chunk_overlap=chunk_overlap,
            )
            sub_splits = text_splitter.split_text(block)
            if header_prefix and sub_splits:
                sub_splits[0] = header_prefix + sub_splits[0]
            grouped.extend(sub_splits)
            continue

        if current_tokens + block_tokens > chunk_size and current_parts:
            grouped.append("\n\n".join(current_parts))
            current_parts = []
            current_tokens = 0

        current_parts.append(block)
        current_tokens += block_tokens

    if current_parts:
        grouped.append("\n\n".join(current_parts))

    # --- Step 3: 見出しのみの先頭チャンクをマージ ---
    while len(grouped) > 1 and _is_header_only(grouped[0]):
        grouped[1] = grouped[0] + "\n\n" + grouped[1]
        grouped.pop(0)

    # --- Step 4: LCDocument に変換 + 見出しコンテキスト付与 ---
    splits = [LCDocument(page_content=text, metadata=dict(metadata)) for text in grouped]

    if len(splits) > 1:
        heading_context_parts = []
        for key in ["Header 1", "Header 2", "Header 3"]:
            if key in metadata:
                level = int(key.split()[-1])
                prefix = "#" * level
                heading_context_parts.append(f"{prefix} {metadata[key]}")

        if heading_context_parts:
            heading_context = "\n".join(heading_context_parts) + "\n\n"
            for i in range(1, len(splits)):
                split_content = splits[i].page_content
                if not split_content.startswith("#"):
                    splits[i].page_content = heading_context + "※ 前のチャンクからの続き\n\n" + split_content

    return splits


# ---------------------------------------------
# メインチャンク関数
# ---------------------------------------------


def chunk_markdown_with_metadata(
    input_md_path: str,
    output_json_path: str,
    heading_page_map: list[dict] | None = None,
    intermediate_md_path: str | None = None,
    chunk_size: int = 8192,
    chunk_overlap: int = 200,
) -> list[dict]:
    """
    Markdown ファイルをチャンク分割し、見出し・ページメタデータを付与する。

    Args:
        input_md_path: 入力 Markdown ファイルパス
        output_json_path: 出力 JSON ファイルパス
        heading_page_map: 見出し・ページ番号マッピング (extract_heading_page_map の結果)
        intermediate_md_path: 前処理済み Markdown 中間ファイル保存パス
        chunk_size: チャンクサイズ (トークン数)
        chunk_overlap: チャンク間重複 (トークン数)

    Returns:
        チャンク結果のリスト
    """
    heading_page_map = heading_page_map or []

    input_path = Path(input_md_path)
    if not input_path.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_md_path}")

    markdown_text = input_path.read_text(encoding="utf-8")
    logger.info(f"入力ファイル読み込み: {input_md_path}")

    # --- ステップ0: 前処理 ---
    normalized_text = preprocess_parsed_markdown(markdown_text)
    page_marker_data = parse_markdown_page_markers(normalized_text)
    preprocessed_text = page_marker_data["stripped_text"] if page_marker_data["has_markers"] else normalized_text
    logger.info("前処理完了")

    if intermediate_md_path:
        p = Path(intermediate_md_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(preprocessed_text, encoding="utf-8")
        logger.info(f"中間ファイル保存: {intermediate_md_path}")

    # --- ステップ1: ヘッダー構造分割 ---
    headers_to_split_on = [
        ("#", "Header 1"),
        ("##", "Header 2"),
    ]
    markdown_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on, strip_headers=False)
    md_header_splits = markdown_splitter.split_text(preprocessed_text)
    logger.info(f"ヘッダー分割後: {len(md_header_splits)} チャンク")

    # --- ステップ1.5: 同一 H1 内の隣接チャンクをマージ ---
    merged_splits = _merge_adjacent_chunks(md_header_splits, chunk_size)
    logger.info(f"H1 マージ後: {len(merged_splits)} チャンク (マージ前: {len(md_header_splits)})")

    # --- ステップ2: スマート分割 (トークン制限) ---
    final_splits = []
    for doc in merged_splits:
        final_splits.extend(_smart_split_large_document(doc, chunk_size, chunk_overlap))
    logger.info(f"最終チャンク数: {len(final_splits)}")

    # --- ステップ3: 結果構築 + メタデータ付与 ---
    marker_page_ranges: list[tuple[int | None, int | None]] = []
    if page_marker_data["has_markers"]:
        marker_page_ranges, _verification = resolve_chunk_page_ranges(
            [doc.page_content for doc in final_splits],
            page_marker_data,
        )

    results = []
    for i, doc in enumerate(final_splits):
        meta = dict(doc.metadata)

        if marker_page_ranges:
            page, page_end = marker_page_ranges[i]
        else:
            page, page_end = None, None

        # ページ番号の付与 (marker を優先、なければ H2/H1 見出しマップにフォールバック)
        if page is None:
            h1_name = meta.get("Header 1") or ""
            h2_name = meta.get("Header 2") or ""
            p1, pe1 = _find_page_for_heading(h1_name, heading_page_map)
            p2, pe2 = _find_page_for_heading(h2_name, heading_page_map)
            if p2 is not None:
                page, page_end = p2, pe2
            elif p1 is not None:
                page, page_end = p1, pe1

        # 見出しなしチャンク (タイトル等): 最初の見出しの前ページを推定
        if page is None and heading_page_map:
            first_heading_page = heading_page_map[0]["page"]
            if first_heading_page > 1:
                page = 1
                page_end = first_heading_page - 1
            else:
                page = 1
                page_end = 1

        metadata_str = format_page_metadata(page, page_end)

        chunk_data = {
            "chunk_id": i + 1,
            "metadata": metadata_str,
            "content_length": len(doc.page_content),
            "content": doc.page_content,
        }
        results.append(chunk_data)

    # --- ステップ4: 検証 ---
    warnings = _validate_chunks(results, chunk_size)

    # --- 出力 ---
    output_path = Path(output_json_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    output_data = {
        "input_file": str(input_md_path),
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "total_chunks": len(results),
        "warnings": warnings,
        "chunks": results,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    logger.info(f"チャンク結果保存: {output_json_path}")
    return results


def _validate_chunks(results: list[dict], chunk_size: int) -> list[str]:
    """チャンク結果を検証し警告を返す"""
    warnings = []

    if len(results) >= MAX_CHUNK_COUNT:
        msg = f"WARNING: チャンク数が {MAX_CHUNK_COUNT} 以上: {len(results)} チャンク"
        warnings.append(msg)
        logger.warning(msg)

    for chunk in results:
        token_count = _count_tokens(chunk["content"])
        chunk["token_count"] = token_count
        if token_count > chunk_size:
            msg = f"WARNING: Chunk {chunk['chunk_id']} のトークン数が超過: " f"{token_count} > {chunk_size}"
            warnings.append(msg)
            logger.warning(msg)

    return warnings
