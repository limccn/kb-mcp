#!/usr/bin/env python3
"""
chunking_heading.py のテスト

テスト観点:
1. 見出し (H1/H2) メタデータがチャンクに付与されること
2. heading_page_map からページ番号がメタデータに付与されること
3. トークン超過時に H3 境界でスマート分割されること
4. H3 がない場合に RecursiveCharacterTextSplitter でフォールバック分割され、
   後続チャンクに見出しコンテキスト (続き) が付与されること
"""

import json
import sys
from pathlib import Path

# ingestion ルートをパスに追加
_HERE = Path(__file__).resolve().parent
_INGESTION_ROOT = _HERE.parent
if str(_INGESTION_ROOT) not in sys.path:
    sys.path.insert(0, str(_INGESTION_ROOT))

from chunking.chunking_heading import chunk_markdown_with_metadata

# テストデータのディレクトリ
TEST_DATA_DIR = _HERE / "test_data"
TEST_OUTPUT_DIR = _HERE / "test_output"


def _run_chunking(
    md_filename: str,
    chunk_size: int = 8192,
    chunk_overlap: int = 200,
    heading_page_map: list[dict] | None = None,
    output_name: str | None = None,
) -> list[dict]:
    """テストデータをチャンキングし結果を返すヘルパー

    結果は test_output/ に JSON と前処理済み MD として保存される。
    """
    input_md = str(TEST_DATA_DIR / md_filename)
    TEST_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    stem = output_name or Path(md_filename).stem
    output_json = str(TEST_OUTPUT_DIR / f"{stem}.json")
    intermediate_md = str(TEST_OUTPUT_DIR / f"{stem}_preprocessed.md")

    return chunk_markdown_with_metadata(
        input_md_path=input_md,
        output_json_path=output_json,
        heading_page_map=heading_page_map,
        intermediate_md_path=intermediate_md,
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )


# =============================================================
# テスト1: 見出しメタデータの付与
# =============================================================
def test_heading_metadata():
    """H1/H2 見出しがチャンクの metadata に正しく付与されること"""
    results = _run_chunking("heading_basic.md", output_name="test1_heading_metadata")

    assert len(results) > 0, "チャンクが0件"

    # Header 1 を持つチャンクが存在すること
    h1_values = {r["metadata"].get("Header 1") for r in results}
    assert "1. はじめに" in h1_values, f"Header 1 '1. はじめに' が見つからない: {h1_values}"
    assert "2. インストール" in h1_values, f"Header 1 '2. インストール' が見つからない: {h1_values}"

    # H1 単位でマージされるため、H2 見出しはコンテンツ内にインラインで含まれる
    all_content = "\n".join(r["content"] for r in results)
    assert "## 1.1. 目的" in all_content, "H2 '1.1. 目的' がコンテンツに含まれない"
    assert "## 2.2. セットアップ手順" in all_content, "H2 '2.2. セットアップ手順' がコンテンツに含まれない"

    print("  PASS: 見出しメタデータが正しく付与された")


# =============================================================
# テスト2: ページ番号メタデータの付与
# =============================================================
def test_page_number_metadata():
    """heading_page_map からページ番号(範囲)が正しくメタデータに付与されること"""
    heading_page_map = [
        {"heading": "1. はじめに", "page": 1, "page_end": 1},
        {"heading": "1.1. 目的", "page": 2, "page_end": 2},
        {"heading": "1.2. 対象読者", "page": 3, "page_end": 4},
        {"heading": "2. インストール", "page": 5, "page_end": 9},
        {"heading": "2.1. 動作環境", "page": 6, "page_end": 7},
        {"heading": "2.2. セットアップ手順", "page": 8, "page_end": 9},
    ]
    results = _run_chunking("heading_basic.md", heading_page_map=heading_page_map, output_name="test2_page_number")

    # ページ番号が付与されたチャンクが存在すること (metadata は "p.X" or "p.X-Y" 形式)
    pages_found = [r["metadata"] for r in results if r["metadata"].startswith("p.")]
    assert len(pages_found) > 0, "ページ番号が1件も付与されていない"

    # 範囲指定 (p.X-Y) が含まれること
    range_pages = [p for p in pages_found if "-" in p]
    assert len(range_pages) > 0, "ページ範囲指定 (p.X-Y) が1件も付与されていない"

    print("  PASS: ページ番号メタデータが正しく付与された (範囲指定対応)")


# =============================================================
# テスト3: H3 境界でのスマート分割
# =============================================================
def test_h3_smart_split():
    """トークン超過時に H3 境界でスマート分割されること"""
    # chunk_size=150 で全体 410 tokens を分割させる
    results = _run_chunking("heading_h3_split.md", chunk_size=150, chunk_overlap=0, output_name="test3_h3_split")

    # H3 が3つあるので、H3 境界で分割されて複数チャンクになるはず
    assert len(results) >= 3, f"H3 分割でチャンク数が3未満: {len(results)}"

    # metadata は "p.xxx" 形式の文字列になった（Header 3 は含まない）

    # H3 見出しテキストが含まれていること
    all_content = " ".join(r["content"] for r in results)
    assert "機能Aの説明" in all_content, "機能Aの説明が見つからない"
    assert "機能Bの説明" in all_content, "機能Bの説明が見つからない"
    assert "機能Cの説明" in all_content, "機能Cの説明が見つからない"

    print(f"  PASS: H3 境界でスマート分割された ({len(results)} チャンク)")


# =============================================================
# テスト4: フォールバック分割 + 見出しコンテキスト継承
# =============================================================
def test_fallback_split_with_context():
    """H3 なしの長大テキストがフォールバック分割され、
    後続チャンクに見出しコンテキストが付与されること"""
    # chunk_size=150 で全体 345 tokens を分割させる
    results = _run_chunking("heading_fallback.md", chunk_size=150, chunk_overlap=0, output_name="test4_fallback")

    # 複数チャンクに分割されること
    assert len(results) >= 2, f"フォールバック分割でチャンク数が2未満: {len(results)}"

    # 1番目のチャンクが見出しだけでなく本文も含むこと
    first_content = results[0]["content"]
    has_heading = any(line.strip().startswith("#") for line in first_content.split("\n") if line.strip())
    non_heading_lines = [
        line for line in first_content.split("\n") if line.strip() and not line.strip().startswith("#")
    ]
    assert has_heading, "1番目のチャンクに見出しがない"
    assert len(non_heading_lines) > 0, "1番目のチャンクが見出しのみで本文がない"

    # 2番目以降のチャンクにコンテキスト情報が含まれること
    continuation_chunks = [r for r in results[1:] if "※ 前のチャンクからの続き" in r["content"]]
    assert len(continuation_chunks) > 0, "フォールバック分割後にコンテキスト情報が付与されていない"

    # コンテキスト情報の前に見出しが含まれること
    for chunk in continuation_chunks:
        content = chunk["content"]
        assert "# " in content.split("※")[0], f"見出しコンテキストがない:\n{content[:200]}"

    print(f"  PASS: フォールバック分割 + 見出しコンテキスト継承 ({len(results)} チャンク)")


# =============================================================
# テスト5: 出力 JSON ファイルの構造
# =============================================================
def test_output_json_structure():
    """出力 JSON ファイルが正しい構造を持つこと"""
    _run_chunking(
        "heading_basic.md",
        heading_page_map=[{"heading": "1. はじめに", "page": 1}],
        output_name="test5_json_structure",
    )
    output_json = str(TEST_OUTPUT_DIR / "test5_json_structure.json")
    with open(output_json, "r", encoding="utf-8") as f:
        data = json.load(f)

        # トップレベル構造
        assert "input_file" in data, "input_file がない"
        assert "chunk_size" in data, "chunk_size がない"
        assert "chunk_overlap" in data, "chunk_overlap がない"
        assert "total_chunks" in data, "total_chunks がない"
        assert "heading_page_map" not in data, "heading_page_map が含まれている"
        assert "warnings" in data, "warnings がない"
        assert "chunks" in data, "chunks がない"
        assert data["total_chunks"] == len(data["chunks"]), "total_chunks と chunks 数が不一致"

        # チャンク構造
        for chunk in data["chunks"]:
            assert "chunk_id" in chunk, "chunk_id がない"
            assert "metadata" in chunk, "metadata がない"
            assert "content_length" in chunk, "content_length がない"
            assert "content" in chunk, "content がない"
            assert "token_count" in chunk, "token_count がない"

        print("  PASS: 出力 JSON 構造が正しい")


# =============================================================
# テスト6: テーブル分割時のヘッダー保持
# =============================================================
def test_table_split_preserves_header():
    """テーブル分割時にヘッダー行が各チャンクに保持されること"""
    results = _run_chunking("heading_table.md", chunk_size=150, chunk_overlap=0, output_name="test6_table")

    assert len(results) >= 2, f"テーブル分割でチャンク数が2未満: {len(results)}"

    # テーブル行を含むチャンクを抽出
    table_chunks = [r for r in results if "|" in r["content"]]
    assert len(table_chunks) >= 2, f"テーブルを含むチャンクが2件未満: {len(table_chunks)}"

    # 各テーブルチャンクにヘッダー行とセパレータ行が含まれること
    for i, chunk in enumerate(table_chunks):
        content = chunk["content"]
        table_lines = [line for line in content.split("\n") if line.strip().startswith("|")]
        assert len(table_lines) >= 3, f"テーブルチャンク{i+1}の行数が不足: {len(table_lines)}"
        assert "テスト項目" in table_lines[0], f"テーブルチャンク{i+1}にヘッダー行がない: {table_lines[0]}"
        assert "---" in table_lines[1], f"テーブルチャンク{i+1}にセパレータ行がない: {table_lines[1]}"

    # 全データ行が欠損なく含まれていること
    all_content = "\n".join(r["content"] for r in results)
    for no in range(1, 13):
        assert f"| {no} |" in all_content, f"データ行 No.{no} が欠損している"

    print(
        f"  PASS: テーブル分割でヘッダー行が保持された "
        f"({len(results)} チャンク, うちテーブル {len(table_chunks)} チャンク)"
    )


# =============================================================
# テスト7: H1 単位のグリーディマージ
# =============================================================
def test_h1_greedy_merge():
    """トークンに余裕がある場合、同一 H1 内の H2 チャンクがマージされること"""
    # heading_basic.md は全178トークン。H1 が2つあり、それぞれ ~97, ~81 トークン
    # chunk_size=8192 なら H1 単位で 2 チャンクにマージされるはず
    results = _run_chunking("heading_basic.md", chunk_size=8192, chunk_overlap=200, output_name="test7_merge")

    # H1 が2つなので 2 チャンクになるはず
    assert len(results) == 2, f"マージ後のチャンク数が2でない: {len(results)}"

    # 各チャンクに H1 のみ異なる値が設定されていること
    h1_values = [r["metadata"].get("Header 1") for r in results]
    assert h1_values[0] == "1. はじめに", f"Chunk 1 の H1 が不正: {h1_values[0]}"
    assert h1_values[1] == "2. インストール", f"Chunk 2 の H1 が不正: {h1_values[1]}"

    # Chunk 1 内に H2 コンテンツがすべて含まれること
    content1 = results[0]["content"]
    assert "1.1. 目的" in content1, "Chunk 1 に '1.1. 目的' が含まれない"
    assert "1.2. 対象読者" in content1, "Chunk 1 に '1.2. 対象読者' が含まれない"

    # Chunk 2 内に H2 コンテンツがすべて含まれること
    content2 = results[1]["content"]
    assert "2.1. 動作環境" in content2, "Chunk 2 に '2.1. 動作環境' が含まれない"
    assert "2.2. セットアップ手順" in content2, "Chunk 2 に '2.2. セットアップ手順' が含まれない"

    print(f"  PASS: H1 単位でグリーディマージされた ({len(results)} チャンク)")


# =============================================================
# メイン
# =============================================================
def main():
    tests = [
        ("1. 見出しメタデータ付与", test_heading_metadata),
        ("2. ページ番号メタデータ付与", test_page_number_metadata),
        ("3. H3 境界スマート分割", test_h3_smart_split),
        ("4. フォールバック分割 + コンテキスト継承", test_fallback_split_with_context),
        ("5. 出力 JSON 構造", test_output_json_structure),
        ("6. テーブル分割ヘッダー保持", test_table_split_preserves_header),
        ("7. H1 単位グリーディマージ", test_h1_greedy_merge),
    ]

    print("=" * 60)
    print("chunking_heading.py テスト")
    print("=" * 60)

    passed = 0
    failed = 0

    for name, func in tests:
        print(f"\n[{name}]")
        try:
            func()
            passed += 1
        except AssertionError as e:
            print(f"  FAIL: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR: {type(e).__name__}: {e}")
            failed += 1

    print("\n" + "=" * 60)
    print(f"結果: {passed} passed, {failed} failed / {len(tests)} tests")
    print("=" * 60)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
