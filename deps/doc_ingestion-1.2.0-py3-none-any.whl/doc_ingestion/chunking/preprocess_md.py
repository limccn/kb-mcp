"""
Markdown前処理モジュール

チャンキング前にMarkdownファイルを前処理する。
- Unicode正規化 (NFKC: 康熙部首→CJK統合漢字、全角英数→半角 等)
- 不要要素の除去 (<!-- image -->, 無駄な改行・空白, テーブル内連続空白)
- 見出しレベルの適正化 (章番号に基づくレベル設定, 空見出しの補完)
"""

import logging
import re
import unicodedata

logger = logging.getLogger(__name__)

# 全角数字→半角数字の変換テーブル
FULLWIDTH_DIGIT_MAP = str.maketrans("０１２３４５６７８９", "0123456789")
# 全角ピリオド→半角
FULLWIDTH_PERIOD_MAP = str.maketrans("．", ".")


def _normalize_chapter_number(text: str) -> str:
    """全角数字・全角ピリオドを半角に変換する"""
    return text.translate(FULLWIDTH_DIGIT_MAP).translate(FULLWIDTH_PERIOD_MAP)


def _get_chapter_depth(heading_text: str) -> int | None:
    """
    見出しテキストから章番号の深さを判定する。

    例:
        "1. 共通画面"       → 1  (章レベル)
        "1.1. 共通画面詳細"  → 2  (節レベル)
        "1.1.1. 日付選択"    → 3  (項レベル)
        "1.ログイン画面"     → 1  (章レベル、ピリオド後スペースなし)
        "1.1.ログイン画面"   → 2  (節レベル、ピリオド後スペースなし)
        "Ａ. カレンダー"     → None (章番号なし)
        "はじめに"           → None (章番号なし)

    Returns:
        章番号の深さ (int) or None
    """
    normalized = _normalize_chapter_number(heading_text.strip())
    # 章番号パターン: "1." "1.1." "1.1.1." など（数字とピリオドの繰り返し）
    # ピリオドの後のスペースは任意（"1.ログイン" のようなケースに対応）
    match = re.match(r"^(\d+(?:\.\d+)*)\.\s?", normalized)
    if match:
        chapter_str = match.group(1)
        depth = chapter_str.count(".") + 1
        return depth
    # "1 " のようにピリオドなしの単独数字パターン
    match = re.match(r"^(\d+)\s", normalized)
    if match:
        return 1
    return None


def remove_image_comments(text: str) -> str:
    """<!-- image --> コメントを除去する"""
    # <!-- image --> とその前後の空行を除去
    text = re.sub(r"\n*<!-- image -->\n*", "\n", text)
    return text


def clean_whitespace(text: str) -> str:
    """
    無駄な改行・空白を除去する。
    - 3行以上の連続空行を2行に制限
    - 行末の空白を除去
    """
    # 行末の空白を除去
    text = re.sub(r"[ \t]+$", "", text, flags=re.MULTILINE)
    # 3行以上の連続空行を2行(1つの空行)に制限
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text


def clean_table_spaces(text: str) -> str:
    """
    テーブル行(|ではじまる行)の連続空白を1つに圧縮する。
    """
    lines = text.split("\n")
    result = []
    for line in lines:
        if line.startswith("|"):
            # テーブル行の連続空白を1つに圧縮
            line = re.sub(r" {2,}", " ", line)
        result.append(line)
    return "\n".join(result)


def fix_heading_levels(text: str) -> str:
    """
    見出しレベルを適正化する。

    ルール:
    - 最初の見出しは # (H1)
    - 章番号の深さに基づいてレベルを決定:
        - 深さ1 (例: "1.") → # (H1)
        - 深さ2 (例: "1.1.") → ## (H2)
        - 深さ3+ (例: "1.1.1.") → ### (H3)
    - 章番号なしの見出し → ### (H3)
    - 空の見出しは次の非空行をテキストとして取り込む
    """
    lines = text.split("\n")
    result = []
    is_first_heading = True
    i = 0

    while i < len(lines):
        line = lines[i]

        # 見出し行の判定 (# または ## または ### で始まる行)
        heading_match = re.match(r"^(#{1,6})\s*(.*)", line)

        if heading_match:
            heading_text = heading_match.group(2).strip()

            # 空見出しの処理: 次の非空行をテキストとして取り込む
            if not heading_text:
                j = i + 1
                while j < len(lines) and lines[j].strip() == "":
                    j += 1
                if j < len(lines):
                    heading_text = lines[j].strip()
                    i = j  # 取り込んだ行をスキップ
                else:
                    # ファイル末尾まで空行だった場合はスキップ
                    i += 1
                    continue

            # 見出しレベルの決定
            if is_first_heading:
                new_level = "#"
                is_first_heading = False
            else:
                depth = _get_chapter_depth(heading_text)
                if depth is not None:
                    if depth == 1:
                        new_level = "#"
                    elif depth == 2:
                        new_level = "##"
                    else:
                        new_level = "###"
                else:
                    new_level = "###"

            result.append(f"{new_level} {heading_text}")
        else:
            result.append(line)

        i += 1

    return "\n".join(result)


def preprocess_markdown(text: str) -> str:
    """
    Markdownテキストに対して全前処理を適用する。

    処理順序:
    1. Unicode正規化 (NFKC)
    2. <!-- image --> 除去
    3. テーブル内連続空白の圧縮
    4. 無駄な改行・空白の除去
    5. 見出しレベルの適正化
    """
    logger.info("前処理開始")

    # Step 1: Unicode正規化 (NFKC)
    # 康熙部首(U+2F00等)→CJK統合漢字(U+4E00等)、全角英数→半角 等
    text = unicodedata.normalize("NFKC", text)
    logger.info("Unicode正規化(NFKC)完了")

    # Step 2: <!-- image --> 除去
    text = remove_image_comments(text)
    logger.info("<!-- image --> 除去完了")

    # Step 3: テーブル内連続空白の圧縮
    text = clean_table_spaces(text)
    logger.info("テーブル内空白圧縮完了")

    # Step 4: 無駄な改行・空白の除去
    text = clean_whitespace(text)
    logger.info("空白・改行整理完了")

    # Step 5: 見出しレベルの適正化
    text = fix_heading_levels(text)
    logger.info("見出しレベル適正化完了")

    logger.info("前処理完了")
    return text
