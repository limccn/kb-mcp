import sys
import unittest
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_INGESTION_ROOT = _HERE.parent
if str(_INGESTION_ROOT) not in sys.path:
    sys.path.insert(0, str(_INGESTION_ROOT))

from chunking.page_metadata import parse_markdown_page_markers, resolve_chunk_page_ranges


class PageMetadataTest(unittest.TestCase):
    def test_parse_markers_and_resolve_multi_page_chunk(self):
        markdown = """# Title

<!-- page:1 -->
alpha
beta
<!-- page:2 -->
gamma
delta
"""
        marker_data = parse_markdown_page_markers(markdown)
        self.assertTrue(marker_data["has_markers"])
        self.assertEqual(marker_data["marker_pages"], [1, 2])

        ranges, verification = resolve_chunk_page_ranges(["alpha\nbeta\ngamma"], marker_data)
        self.assertEqual(ranges, [(1, 2)])
        self.assertTrue(verification["all_chunks_located"])

    def test_continuation_marker_lookup(self):
        markdown = """<!-- page:3 -->
first line
second line
third line
"""
        marker_data = parse_markdown_page_markers(markdown)
        chunk = "# 見出し\n\n※ 前のチャンクからの続き\n\nsecond line\nthird line"
        ranges, verification = resolve_chunk_page_ranges([chunk], marker_data)
        self.assertEqual(ranges, [(3, 3)])
        self.assertTrue(verification["all_chunks_located"])


if __name__ == "__main__":
    unittest.main()