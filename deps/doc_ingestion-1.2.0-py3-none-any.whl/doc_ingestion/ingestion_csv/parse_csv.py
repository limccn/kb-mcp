"""CSV → Markdown テーブル変換

先頭行をヘッダとして GFM テーブルに描く。区切りは**カンマ固定** —
``csv.Sniffer`` は小さな標本や列数の揃わない行で結論が変わるため使わない
（「決定的で機械検証できる」ことのほうが、区切り自動判定より価値がある）。
TSV は対象外。

エンコーディングは ingestion_txt と同じ凍結チェーンを使う
(utf-8-sig → utf-8 → cp932 → cp1252)。鎖は一箇所にしか置かない。
"""

import csv
import io
import logging

from doc_ingestion.ingestion_txt.parse_txt import parse_txt

logger = logging.getLogger(__name__)


def _cell(value: str) -> str:
    """セル一つを GFM テーブルで安全な形にする。

    ``|`` は列区切りなので必ずエスケープする。改行はテーブル内に置けないため
    ``<br>`` に置き換える（黙って消すと内容が変わる）。
    """
    return value.replace("|", "\\|").replace("\n", "<br>")


def _rows(text: str) -> list[list[str]]:
    """CSV の行を取り出す。完全な空行は落とす。

    ``csv.reader`` は空行を ``[]`` として返す — セルが一つも無い行は
    テーブルでも意味を持たないため落とす。中の空行も同じ扱い
    （Excel 出力に混ざる区切り用の空行が典型）。
    """
    rows = list(csv.reader(io.StringIO(text)))
    return [r for r in rows if any(c.strip() for c in r)]


def parse_csv(file_path: str) -> str:
    """CSV を読み、GFM テーブルの Markdown を返す。

    Args:
        file_path: 入力 CSV パス。

    Returns:
        markdown 文字列。行が一つも無いときは空文字列
        （空出力の判定は ``convert()`` が一箇所で持つ契約）。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        ValueError: 凍結チェーンのいずれでもデコードできない場合。
    """
    rows = _rows(parse_txt(file_path))
    if not rows:
        return ""

    width = max(len(r) for r in rows)
    header, *body = rows

    def line(cells: list[str]) -> str:
        padded = [*cells, *[""] * (width - len(cells))]
        return "| " + " | ".join(_cell(c) for c in padded) + " |"

    # 区切り行もヘッダと同じ幅で描く（描画は ingestion_pdf の表と同じ形）。
    sep = "| " + " | ".join(["---"] * width) + " |"
    table = [line(header), sep, *(line(r) for r in body)]

    logger.info(f"[csv] 読み込み完了 ({file_path}): {len(body)} 行 × {width} 列")
    return "\n".join(table)