#!/usr/bin/env python3
"""
ingestion_json — JSON 前処理

JSON は 1 次元目 (配列の各要素 / dict の各キー) で区切り、
各要素をそのままチャンクとする (dict のキーは保持する)。

metadata 例: "index=2/line=10"
"""

import json
import logging
from pathlib import Path

import tiktoken

from .._progress import _cb_progress

logger = logging.getLogger(__name__)

_ENC_NAME = "cl100k_base"
_MAX_CHUNKS = 512


def _count_tokens(text: str) -> int:
    return len(tiktoken.get_encoding(_ENC_NAME).encode(text))


def _find_element_lines(raw: str, data) -> list[tuple[int, int]]:
    """JSON のトップレベル各要素の (開始行, 終了行) (1-based) のリストを返す。"""
    decoder = json.JSONDecoder()
    lines: list[tuple[int, int]] = []

    if isinstance(data, list):
        i = raw.index("[") + 1
        while i < len(raw):
            while i < len(raw) and raw[i] in " \t\n\r,":
                i += 1
            if i >= len(raw) or raw[i] == "]":
                break
            start_line = raw[:i].count("\n") + 1
            _, end_idx = decoder.raw_decode(raw, i)
            end_line = raw[:end_idx].count("\n") + 1
            lines.append((start_line, end_line))
            i = end_idx
    elif isinstance(data, dict):
        i = raw.index("{") + 1
        while i < len(raw):
            while i < len(raw) and raw[i] in " \t\n\r,":
                i += 1
            if i >= len(raw) or raw[i] == "}":
                break
            # キーをスキップ
            _, key_end = decoder.raw_decode(raw, i)
            colon = raw.index(":", key_end) + 1
            while colon < len(raw) and raw[colon] in " \t\n\r":
                colon += 1
            start_line = raw[:colon].count("\n") + 1
            _, end_idx = decoder.raw_decode(raw, colon)
            end_line = raw[:end_idx].count("\n") + 1
            lines.append((start_line, end_line))
            i = end_idx
    else:
        total_lines = raw.count("\n") + 1
        lines.append((1, total_lines))

    return lines


# ======================================================================
# エントリポイント
# ======================================================================
def run(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict | None = None,
    step_callback: callable = None,
) -> None:
    """JSON 前処理パイプラインを実行する。"""
    config = config or {}
    work_p = Path(work_dir).resolve()
    work_p.mkdir(parents=True, exist_ok=True)
    out_md = Path(output_md_path)
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_chunk = Path(output_chunk_path)
    out_chunk.parent.mkdir(parents=True, exist_ok=True)

    logger.info("[json 1/1] チャンキング")
    _cb_progress(step_callback, 0.20, "[json 1/1] チャンキング")

    raw = Path(input_path).read_text("utf-8-sig")
    raw = raw.replace("\r\n", "\n")
    data = json.loads(raw)

    # 1 次元目を要素リストとして扱う (dict はキーを保持する)
    if isinstance(data, list):
        elements = [(None, elem) for elem in data]
    elif isinstance(data, dict):
        elements = list(data.items())
    else:
        elements = [(None, data)]

    ch_cfg = config.get("chunking", {})
    chunk_size = ch_cfg.get("chunk_size", 8192)
    chunk_overlap = ch_cfg.get("chunk_overlap", 200)

    element_lines = _find_element_lines(raw, data)

    chunks: list[dict] = []
    warnings: list[str] = []
    md_parts: list[str] = []

    for idx, (key, elem) in enumerate(elements):
        entry = {key: elem} if key is not None else elem
        content = json.dumps(entry, ensure_ascii=False, indent=2)
        start_line, end_line = element_lines[idx] if idx < len(element_lines) else (0, 0)
        metadata = f"L{start_line}-{end_line}"

        token_count = _count_tokens(content)
        if token_count > chunk_size:
            msg = f"WARNING: Chunk {idx + 1} tokens={token_count} > chunk_size={chunk_size}"
            warnings.append(msg)
            logger.warning(msg)

        chunks.append(
            {
                "chunk_id": idx + 1,
                "metadata": metadata,
                "content_length": len(content),
                "content": content,
                "token_count": token_count,
            }
        )
        md_parts.append(f"## {metadata}\n\n```json\n{content}\n```\n")

    if len(chunks) >= _MAX_CHUNKS:
        msg = f"WARNING: チャンク数 {len(chunks)} >= {_MAX_CHUNKS}"
        warnings.append(msg)
        logger.warning(msg)

    # Markdown 出力 (参照用)
    out_md.write_text(f"# {Path(input_path).name}\n\n" + "\n".join(md_parts), "utf-8")

    # チャンク JSON 出力
    out_data = {
        "input_file": Path(input_path).name,
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "total_chunks": len(chunks),
        "warnings": warnings,
        "chunks": chunks,
    }
    out_chunk.write_text(json.dumps(out_data, ensure_ascii=False, indent=2), "utf-8")

    logger.info(f"[json] 完了: {len(chunks)} チャンク")
    _cb_progress(step_callback, 0.60, f"[json 1/1] チャンキング完了: {len(chunks)}チャンク")
