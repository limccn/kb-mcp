#!/usr/bin/env python3
"""
Parse Quality Check Result Checker

phase2_rag結果ディレクトリ内の全MDファイルのパース品質をチェックし、
CSV形式で出力する。
"""

import argparse
import csv
import logging
import sys
from pathlib import Path
from typing import Any, Dict, List

# parse_quality_checkモジュールをインポート
from parse_quality_check import calculate_parse_confidence

# ロギング設定
logger = logging.getLogger(__name__)


def find_md_files(base_dir: Path) -> List[Dict[str, Any]]:
    """
    base_dir/unit/XXXX/ingestion/*.md のパターンでMDファイルを検索する。

    Args:
        base_dir (Path): 基準ディレクトリ (例: /path/to/phase2_rag)

    Returns:
        List[Dict[str, Any]]: ファイル情報のリスト
            - unit_id: ユニットID (例: "0001")
            - file_path: ファイルパス
            - file_name: ファイル名
            - source_ext: ソースファイルの拡張子
            - source_size_kb: ソースファイルサイズ(KB)
            - md_size_kb: MDファイルサイズ(KB)
    """
    unit_dir = base_dir / "unit"

    if not unit_dir.exists():
        logger.error(f"Unit directory not found: {unit_dir}")
        return []

    # ユニットディレクトリを取得してソート
    unit_dirs = sorted([d for d in unit_dir.iterdir() if d.is_dir() and d.name.isdigit()])

    logger.info(f"Found {len(unit_dirs)} unit directories")

    md_files = []
    for unit_path in unit_dirs:
        unit_id = unit_path.name
        ingestion_dir = unit_path / "ingestion"
        source_dir = unit_path / "source"

        if not ingestion_dir.exists():
            logger.warning(f"Ingestion directory not found: {ingestion_dir}")
            continue

        # MDファイルを検索
        for md_file in sorted(ingestion_dir.glob("*.md")):
            # MDファイルサイズ（KB）を計算
            md_size_kb = round(md_file.stat().st_size / 1024, 2)

            # ソースファイルの拡張子とサイズを検索
            source_ext = ""
            source_size_kb = 0.0
            if source_dir.exists():
                base_name = md_file.stem  # 拡張子を除いたファイル名
                # 同じベース名を持つファイルを検索
                source_files = list(source_dir.glob(f"{base_name}.*"))
                if source_files:
                    source_ext = source_files[0].suffix  # .pdf, .xlsx など
                    source_size_kb = round(source_files[0].stat().st_size / 1024, 2)

            md_files.append(
                {
                    "unit_id": unit_id,
                    "file_path": md_file,
                    "file_name": md_file.name,
                    "source_ext": source_ext,
                    "source_size_kb": source_size_kb,
                    "md_size_kb": md_size_kb,
                }
            )
            logger.debug(
                f"Found: {unit_id} - {md_file.name} (MD: {md_size_kb}KB, Source: {source_ext} {source_size_kb}KB)"
            )

    logger.info(f"Total MD files found: {len(md_files)}")
    return md_files


def analyze_files(md_files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    MDファイルのパース品質を分析する。

    Args:
        md_files (List[Dict[str, Any]]): ファイル情報のリスト

    Returns:
        List[Dict[str, Any]]: 分析結果のリスト
    """
    results = []

    for i, file_info in enumerate(md_files, 1):
        unit_id = file_info["unit_id"]
        file_path = file_info["file_path"]
        file_name = file_info["file_name"]
        source_ext = file_info["source_ext"]
        source_size_kb = file_info["source_size_kb"]
        md_size_kb = file_info["md_size_kb"]

        logger.info(
            f"[{i}/{len(md_files)}] Analyzing: {unit_id}/{file_name} (MD: {md_size_kb}KB, Source: {source_ext} {source_size_kb}KB)"
        )

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                text = f.read()

            # パース品質チェック
            scores = calculate_parse_confidence(text)

            # 結果をマージ
            result = {
                "unit_id": unit_id,
                "file_name": file_name,
                "source_ext": source_ext,
                "source_size_kb": source_size_kb,
                "md_size_kb": md_size_kb,
                **scores,  # score, qc_01_repetition, ... qc_10_length
            }

            results.append(result)
            logger.info(f"  Score: {scores['score']:.3f}")

        except Exception as e:
            logger.error(f"Failed to analyze {file_path}: {e}")
            # エラー時もレコードを追加（スコアは0）
            results.append(
                {
                    "unit_id": unit_id,
                    "file_name": file_name,
                    "source_ext": source_ext,
                    "source_size_kb": source_size_kb,
                    "md_size_kb": md_size_kb,
                    "score": 0.0,
                    "qc_01_repetition": 0.0,
                    "qc_02_density": 0.0,
                    "qc_03_blank_lines": 0.0,
                    "qc_04_consecutive_spaces": 0.0,
                    "qc_05_control_chars": 0.0,
                    "qc_06_validity": 0.0,
                    "qc_07_digit_only": 0.0,
                    "qc_08_single_char": 0.0,
                    "qc_09_whitespace": 0.0,
                    "qc_10_length": 0.0,
                    "error": str(e),
                }
            )

    return results


def export_to_csv(results: List[Dict[str, Any]], output_file: Path):
    """
    分析結果をCSVファイルに出力する。

    Args:
        results (List[Dict[str, Any]]): 分析結果のリスト
        output_file (Path): 出力ファイルパス
    """
    if not results:
        logger.warning("No results to export")
        return

    # CSVヘッダー: unit_id, file_name, source_ext, source_size_kb, md_size_kb, score, qc_01~qc_10
    fieldnames = [
        "unit_id",
        "file_name",
        "source_ext",
        "source_size_kb",
        "md_size_kb",
        "score",
        "qc_01_repetition",
        "qc_02_density",
        "qc_03_blank_lines",
        "qc_04_consecutive_spaces",
        "qc_05_control_chars",
        "qc_06_validity",
        "qc_07_digit_only",
        "qc_08_single_char",
        "qc_09_whitespace",
        "qc_10_length",
    ]

    try:
        with open(output_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(results)

        logger.info(f"Results exported to: {output_file}")
        logger.info(f"Total records: {len(results)}")

    except Exception as e:
        logger.error(f"Failed to export CSV: {e}")
        raise


def main():
    """メイン関数"""
    parser = argparse.ArgumentParser(
        description="phase2_rag結果ディレクトリ内のMDファイルのパース品質をチェックしてCSV出力"
    )
    parser.add_argument(
        "base_dir", type=str, help="基準ディレクトリ (例: /home/ec2-user/work/rag_system/result/phase2_rag)"
    )
    parser.add_argument(
        "-o", "--output", type=str, default="check_result.csv", help="出力CSVファイル名 (デフォルト: check_result.csv)"
    )

    args = parser.parse_args()

    # ディレクトリパス確認
    base_dir = Path(args.base_dir)
    if not base_dir.exists():
        logger.error(f"Base directory not found: {base_dir}")
        sys.exit(1)

    if not base_dir.is_dir():
        logger.error(f"Not a directory: {base_dir}")
        sys.exit(1)

    logger.info(f"Base directory: {base_dir}")

    # MDファイル検索
    md_files = find_md_files(base_dir)

    if not md_files:
        logger.error("No MD files found")
        sys.exit(1)

    # 分析実行
    results = analyze_files(md_files)

    # CSV出力
    output_file = Path(args.output)
    export_to_csv(results, output_file)

    # サマリー表示
    print("\n" + "=" * 60)
    print("Parse Quality Check Summary")
    print("=" * 60)
    print(f"Total files analyzed: {len(results)}")

    if results:
        scores = [r["score"] for r in results if "score" in r]
        if scores:
            print(f"Average score: {sum(scores)/len(scores):.3f}")
            print(f"Min score: {min(scores):.3f}")
            print(f"Max score: {max(scores):.3f}")

            # スコア分布
            high = sum(1 for s in scores if s >= 0.7)
            medium = sum(1 for s in scores if 0.4 <= s < 0.7)
            low = sum(1 for s in scores if s < 0.4)

            print("\nScore distribution:")
            print(f"  High (>= 0.7):   {high:3d} ({high/len(scores)*100:.1f}%)")
            print(f"  Medium (0.4-0.7): {medium:3d} ({medium/len(scores)*100:.1f}%)")
            print(f"  Low (< 0.4):     {low:3d} ({low/len(scores)*100:.1f}%)")

    print(f"\nOutput: {output_file}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    main()
