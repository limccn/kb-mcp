#!/usr/bin/env python3
"""
Parse Quality Check Module

テキストのパース品質を評価するモジュール。
テキストのパース成功度を0.0〜1.0で算出する。
"""

import argparse
import logging
import re
import sys
from pathlib import Path
from typing import Any, Dict

# ロギング設定
logger = logging.getLogger(__name__)


def calculate_parse_confidence(text: str) -> Dict[str, Any]:
    """
    テキストのパース成功度を0.0〜1.0で算出する。
    1.0に近いほど自然な文章としてパースできている可能性が高い。

    Args:
        text (str): 評価対象のテキスト

    Returns:
        Dict[str, Any]: 各スコアの詳細と最終スコア
            - qc_01_repetition: 繰り返しパターンスコア
            - qc_02_density: 密度スコア
            - qc_03_blank_lines: 連続空行スコア
            - qc_04_consecutive_spaces: 連続空白スコア
            - qc_05_control_chars: 制御文字スコア
            - qc_06_validity: 有効文字率スコア
            - qc_07_digit_only: 数字行スコア
            - qc_08_single_char: 単一文字連続スコア
            - qc_09_whitespace: 空白率スコア
            - qc_10_length: 文字数スコア
            - score: 最終スコア (0.0〜1.0)
    """
    if not text or len(text.strip()) == 0:
        logger.warning("Empty text provided")
        return {"score": 0.0}

    # 前処理: 空白除去した実質的な文字数
    clean_text = text.strip()
    total_len = len(text)
    all_lines = text.splitlines()
    lines = [line for line in all_lines if line.strip()]  # 空行を除いた行リスト

    if not lines:
        logger.warning("No valid lines found")
        return 0.0

    logger.debug(f"Text length: {total_len}, Lines: {len(lines)}")

    # --- QC-01: 繰り返しパターン検出 (パースエラーで重複抽出対策) ---
    # 同じ文字が5回以上連続、または同じ単語が3回以上連続
    char_repeat = len(re.findall(r"(.)\1{4,}", text))  # 5回以上同じ文字
    word_repeat = len(re.findall(r"(\S{2,}?)(?:\1){2,}", text))  # 2文字以上の単語が3回以上
    total_repeats = char_repeat + word_repeat
    repetition_score = max(1.0 - (total_repeats * 0.1), 0.0)  # 繰り返しが多いほど減点

    # --- QC-02: 平均行長 (Excelの1文字パース対策) ---
    avg_line_len = len(clean_text) / len(lines)
    # 5文字以下なら0点、20文字以上なら1.0点
    density_score = min(max((avg_line_len - 5) / (20 - 5), 0.0), 1.0)

    # --- QC-03: 連続空行の割合 ---
    consecutive_blank_lines = len(re.findall(r"\n\n\n+", text))  # 3行以上の連続空行
    blank_line_score = max(1.0 - (consecutive_blank_lines * 0.2), 0.0)

    # --- QC-04: 連続空白 ---
    consecutive_spaces = len(re.findall(r"  {3,}", text))  # 5つ以上の連続空白
    consecutive_space_score = max(1.0 - (consecutive_spaces * 0.1), 0.0)

    # --- QC-05: 制御文字・特殊文字の混入 ---
    # 改行(\n=0x0A)、タブ(\t=0x09)、CR(\r=0x0D)を除く制御文字
    control_chars = len(re.findall(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]", text))
    control_char_score = max(1.0 - (control_chars / max(total_len, 1) * 10), 0.0)

    # --- QC-06: 文字種別の妥当性 (文字化け・記号対策) ---
    # \u3040-\u309F: ひらがな, \u30A0-\u30FF: カタカナ, \u4E00-\u9FFF: 漢字
    valid_char_pattern = re.compile(r"[a-zA-Z0-9\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF]")
    valid_chars = len(valid_char_pattern.findall(text))
    validity_score = valid_chars / total_len if total_len > 0 else 0.0

    # --- QC-07: 数字のみの行の割合 ---
    digit_only_lines = sum(1 for line in lines if line.strip() and re.match(r"^\d+$", line.strip()))
    digit_only_ratio = digit_only_lines / len(lines)
    digit_only_score = max(1.0 - digit_only_ratio * 2, 0.0)  # 50%超えると0点

    # --- QC-08: 単一文字行の連続 ---
    single_char_consecutive = 0
    consecutive_count = 0
    for line in lines:
        if len(line.strip()) == 1:
            consecutive_count += 1
            if consecutive_count >= 3:
                single_char_consecutive += 1
        else:
            consecutive_count = 0
    single_char_score = max(1.0 - (single_char_consecutive * 0.2), 0.0)

    # --- QC-09: 無駄な空白・改行の割合 (スカスカ対策) ---
    whitespace_count = len(re.findall(r"\s", text))
    whitespace_ratio = whitespace_count / total_len
    if whitespace_ratio < 0.3:
        whitespace_score = 1.0
    else:
        whitespace_score = max(1.0 - (whitespace_ratio - 0.3) * 2, 0.0)

    # --- QC-10: 絶対的な文字数 (少なすぎ対策) ---
    length_score = min(len(clean_text) / 100, 1.0)

    # --- 総合スコア算出 ---
    # 重み付け
    weights = {
        "repetition": 0.10,  # 繰り返しパターン
        "density": 0.20,  # 行の細切れ具合
        "blank_lines": 0.05,  # 連続空行
        "consecutive_spaces": 0.05,  # 連続空白
        "control_chars": 0.10,  # 制御文字
        "validity": 0.20,  # 文字化け・記号率
        "digit_only": 0.10,  # 数字のみの行
        "single_char": 0.10,  # 単一文字行の連続
        "whitespace": 0.05,  # 空白の多さ
        "length": 0.05,  # 全体の長さ
    }

    final_score = (
        repetition_score * weights["repetition"]
        + density_score * weights["density"]
        + blank_line_score * weights["blank_lines"]
        + consecutive_space_score * weights["consecutive_spaces"]
        + control_char_score * weights["control_chars"]
        + validity_score * weights["validity"]
        + digit_only_score * weights["digit_only"]
        + single_char_score * weights["single_char"]
        + whitespace_score * weights["whitespace"]
        + length_score * weights["length"]
    )

    # スコア詳細をINFOレベルで出力
    logger.info(f"[QC-01] Repetition score: {repetition_score:.3f} (繰り返し: {total_repeats}回)")
    logger.info(f"[QC-02] Density score: {density_score:.3f} (平均行長: {avg_line_len:.2f})")
    logger.info(f"[QC-03] Blank lines score: {blank_line_score:.3f} (連続空行: {consecutive_blank_lines}箇所)")
    logger.info(
        f"[QC-04] Consecutive spaces score: {consecutive_space_score:.3f} (連続空白: {consecutive_spaces}箇所)"
    )
    logger.info(f"[QC-05] Control chars score: {control_char_score:.3f} (制御文字: {control_chars}個)")
    logger.info(f"[QC-06] Validity score: {validity_score:.3f} (有効文字: {valid_chars}/{total_len})")
    logger.info(f"[QC-07] Digit-only lines score: {digit_only_score:.3f} (数字行: {digit_only_lines}/{len(lines)})")
    logger.info(f"[QC-08] Single char score: {single_char_score:.3f} (単一文字連続: {single_char_consecutive}箇所)")
    logger.info(f"[QC-09] Whitespace score: {whitespace_score:.3f} (空白率: {whitespace_ratio:.3f})")
    logger.info(f"[QC-10] Length score: {length_score:.3f} (文字数: {len(clean_text)})")
    logger.info(f"Final score: {final_score:.3f}")

    # 全スコアを辞書で返す
    return {
        "qc_01_repetition": round(repetition_score, 3),
        "qc_02_density": round(density_score, 3),
        "qc_03_blank_lines": round(blank_line_score, 3),
        "qc_04_consecutive_spaces": round(consecutive_space_score, 3),
        "qc_05_control_chars": round(control_char_score, 3),
        "qc_06_validity": round(validity_score, 3),
        "qc_07_digit_only": round(digit_only_score, 3),
        "qc_08_single_char": round(single_char_score, 3),
        "qc_09_whitespace": round(whitespace_score, 3),
        "qc_10_length": round(length_score, 3),
        "score": round(final_score, 3),
    }


def analyze_file(file_path: Path) -> Dict[str, Any]:
    """
    ファイルを読み込んでパース品質を分析する。

    Args:
        file_path (Path): 分析対象のファイルパス

    Returns:
        Dict[str, Any]: 分析結果
    """
    logger.info(f"Analyzing file: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception as e:
        logger.error(f"Failed to read file {file_path}: {e}")
        return {"file": str(file_path), "error": str(e), "score": 0.0}

    score_result = calculate_parse_confidence(text)

    return {
        "file": str(file_path),
        "text_length": len(text),
        "lines": len(text.splitlines()),
        **score_result,  # 全スコアをマージ
    }


def main():
    """メイン関数"""
    parser = argparse.ArgumentParser(description="テキストファイルのパース品質を評価する")
    parser.add_argument("file", type=str, help="評価対象のテキストファイルパス")
    parser.add_argument("-d", "--detail-scores", action="store_true", help="各スコアの詳細を表示")

    args = parser.parse_args()

    # ファイルパス確認
    file_path = Path(args.file)
    if not file_path.exists():
        logger.error(f"File not found: {file_path}")
        sys.exit(1)

    if not file_path.is_file():
        logger.error(f"Not a file: {file_path}")
        sys.exit(1)

    # 分析実行
    result = analyze_file(file_path)

    # 結果表示
    print("\n" + "=" * 60)
    print("Parse Quality Check Result")
    print("=" * 60)
    if "error" in result:
        print(f"Error: {result['error']}")
    else:
        print(f"File:        {result['file']}")
        print(f"Score:       {result['score']:.3f}")
        print(f"Text Length: {result['text_length']}")
        print(f"Lines:       {result['lines']}")

        # 詳細スコア表示
        if args.detail_scores:
            print("=" * 60)
            print("Detail Scores:")
            print(f"  [QC-01] Repetition:          {result['qc_01_repetition']:.3f}")
            print(f"  [QC-02] Density:             {result['qc_02_density']:.3f}")
            print(f"  [QC-03] Blank lines:         {result['qc_03_blank_lines']:.3f}")
            print(f"  [QC-04] Consecutive spaces:  {result['qc_04_consecutive_spaces']:.3f}")
            print(f"  [QC-05] Control chars:       {result['qc_05_control_chars']:.3f}")
            print(f"  [QC-06] Validity:            {result['qc_06_validity']:.3f}")
            print(f"  [QC-07] Digit-only lines:    {result['qc_07_digit_only']:.3f}")
            print(f"  [QC-08] Single char:         {result['qc_08_single_char']:.3f}")
            print(f"  [QC-09] Whitespace:          {result['qc_09_whitespace']:.3f}")
            print(f"  [QC-10] Length:              {result['qc_10_length']:.3f}")

        print("=" * 60)

        # スコア評価
        if result["score"] >= 0.7:
            print("✓ High quality parse (良好)")
        elif result["score"] >= 0.4:
            print("△ Medium quality parse (中程度)")
        else:
            print("✗ Low quality parse (低品質)")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    main()
