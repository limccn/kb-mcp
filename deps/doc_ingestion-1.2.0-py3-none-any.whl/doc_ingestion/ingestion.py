"""
前処理(ingestion)モジュール

処理フロー:
拡張子に応じて各モジュールへ委譲:
   - .docx → ingestion_docx  (パース → チャンキング)
   - .xlsx / .xlsm → ingestion_xlsx  (クレンジング → パース → チャンキング)
   - .xls  → ingestion_xlsx  (クレンジング非対応のためパースから。excel_parser 側が xlrd で読む)
   - .pptx → ingestion_pptx_v2  (パース → チャンキング)
   - .pdf  → ingestion_pdf   (パース → チャンキング, pymupdf のみ)
   - .txt  → ingestion_txt   (パース → チャンキング)
   - .json → ingestion_json  (チャンキング)
"""

import argparse
import logging
from pathlib import Path

import yaml

from . import ingestion_docx as _ingestion_docx_mod
from . import ingestion_json as _ingestion_json_mod
from . import ingestion_pdf as _ingestion_pdf_mod
from . import ingestion_pptx_v2 as _ingestion_pptx_v2_mod
from . import ingestion_txt as _ingestion_txt_mod
from . import ingestion_xlsx as _ingestion_xlsx_mod

logger = logging.getLogger(__name__)

# 拡張子 → 処理モジュールのマッピング
_EXT_MODULE_MAP = {
    ".json": _ingestion_json_mod,
    ".docx": _ingestion_docx_mod,
    ".xlsx": _ingestion_xlsx_mod,
    ".xlsm": _ingestion_xlsx_mod,
    ".xls": _ingestion_xlsx_mod,
    ".pptx": _ingestion_pptx_v2_mod,
    ".pdf": _ingestion_pdf_mod,
    ".txt": _ingestion_txt_mod,
}

from ._progress import _cb_progress  # noqa: E402  # 循環import回避のためモジュールマップ定義後にimport


def load_config(yaml_path: str) -> dict:
    """YAMLファイルから設定を読み込む。

    Args:
        yaml_path: YAMLファイルのパス。

    Returns:
        設定辞書。
    """
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def ingestion(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict = None,
    step_callback: callable = None,
) -> None:
    """前処理パイプラインを実行する。

    拡張子に応じて各モジュールへ委譲する。
    .docx → ingestion_docx / .xlsx,.xlsm,.xls → ingestion_xlsx /
    .pptx → ingestion_pptx_v2 / .pdf → ingestion_pdf /
    .txt → ingestion_txt / .json → ingestion_json

    Args:
        input_path: 入力ファイルパス。
        work_dir: ワークディレクトリパス。
        output_md_path: 出力パースファイルパス (.md)。
        output_chunk_path: 出力チャンクファイルパス (.json)。
        config: 設定辞書 (ingestion.yaml)。Noneの場合はデフォルト設定を使用。
        step_callback: 進捗通知用コールバック関数 (prog: float, msg: str) -> None。
            Noneの場合はコールバックを呼び出さない。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        ValueError: 未対応の拡張子の場合。
    """
    if config is None:
        config = {}

    input_p = Path(input_path).resolve()
    if not input_p.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    work_p = Path(work_dir).resolve()
    work_p.mkdir(parents=True, exist_ok=True)

    current_path = input_p
    ext = current_path.suffix.lower()

    _cb_progress(step_callback, 0.05, f"パース処理スタート: {current_path.name}")

    # --------------------------------------------------
    # 拡張子に応じて各モジュールへ委譲
    # --------------------------------------------------
    mod = _EXT_MODULE_MAP.get(ext)

    if mod is None:
        _cb_progress(step_callback, -1, f"未対応の拡張子です: {ext}")
        raise ValueError(f"未対応の拡張子です: {ext}")

    mod.run(
        input_path=str(current_path),
        work_dir=work_dir,
        output_md_path=output_md_path,
        output_chunk_path=output_chunk_path,
        config=config,
        step_callback=step_callback,
    )


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    parser = argparse.ArgumentParser(description="前処理(ingestion)パイプライン")
    parser.add_argument("--input", required=True, help="入力ファイルパス")
    parser.add_argument("--work_dir", required=True, help="ワークディレクトリパス")
    parser.add_argument("--output_md", required=True, help="出力パースファイルパス (.md)")
    parser.add_argument("--output_chunk", required=True, help="出力チャンクファイルパス (.json)")
    parser.add_argument(
        "--config",
        default=None,
        help="設定YAMLファイルのパス (ingestion.yaml)",
    )
    args = parser.parse_args()

    # 設定の読み込み
    config = {}
    if args.config:
        config = load_config(args.config)

    ingestion(
        input_path=args.input,
        work_dir=args.work_dir,
        output_md_path=args.output_md,
        output_chunk_path=args.output_chunk,
        config=config,
    )


if __name__ == "__main__":
    main()
