import sys
import unittest
from pathlib import Path


_HERE = Path(__file__).resolve().parent
_MODULE_ROOT = _HERE.parent.parent
if str(_MODULE_ROOT) not in sys.path:
    sys.path.insert(0, str(_MODULE_ROOT))

from doc_ingestion.chunking.page_metadata import parse_markdown_page_markers
from doc_ingestion.ingestion_pdf.parse_pdf import TextBlock, _blocks_to_markdown


class ParsePdfMarkdownTest(unittest.TestCase):
    def test_page_markers_do_not_break_cross_page_indented_lists(self):
        blocks = [
            TextBlock("本文1", 10.0, 10.0, 0.0, 0, x_end=300.0),
            TextBlock("本文2", 10.0, 20.0, 0.0, 0, x_end=300.0),
            TextBlock("本文3", 10.0, 30.0, 0.0, 0, x_end=300.0),
            TextBlock("alpha", 10.0, 40.0, 40.0, 0, x_end=300.0),
            TextBlock("beta", 10.0, 50.0, 40.0, 0, x_end=300.0),
            TextBlock("gamma", 10.0, 10.0, 40.0, 1, x_end=300.0),
            TextBlock("本文4", 10.0, 20.0, 0.0, 1, x_end=300.0),
        ]

        markdown, _ = _blocks_to_markdown(
            all_blocks=blocks,
            tables_by_page={},
            heading_tiers=[],
            total_pages=2,
        )

        self.assertIn("<!-- page:1 -->", markdown)
        self.assertIn("<!-- page:2 -->", markdown)
        self.assertNotIn("- <!-- page:2 -->", markdown)
        self.assertIn("- alpha", markdown)
        self.assertIn("- beta", markdown)
        self.assertIn("- gamma", markdown)

        stripped = parse_markdown_page_markers(markdown)["stripped_text"]
        self.assertIn("- alpha\n- beta\n- gamma", stripped)


if __name__ == "__main__":
    unittest.main()