#!/usr/bin/env python3
"""
PDF → Markdown 直接パーサー

PyMuPDF を使用して PDF から直接テキストを取得し、Markdown 形式に変換する。
Docling を経由しない。

処理内容:
- フォントサイズに基づく見出し検出
- テーブル検出 → Markdown テーブル変換
- ヘッダー・フッター除外
- ページ単位でのテキスト抽出
- 見出し・ページマップの同時抽出
"""

import argparse
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path

import pymupdf as fitz

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# データクラス
# ─────────────────────────────────────────────


@dataclass
class TextBlock:
    """テキストブロック情報"""

    text: str
    font_size: float
    y_pos: float
    x_pos: float
    page_num: int
    is_bold: bool = False
    block_type: str = "text"  # "text", "heading", "table"
    x_end: float = 0.0  # ブロック右端 x 座標


@dataclass
class TableCell:
    """テーブルセルの情報"""

    text: str
    row: int
    col: int


# ─────────────────────────────────────────────
# フォントサイズ解析: 本文サイズ・見出し閾値の決定
# ─────────────────────────────────────────────


def _analyze_font_sizes(doc: fitz.Document, header_y: float, footer_y: float) -> tuple[float, float]:
    """
    全テキストのフォントサイズ分布を解析し、本文サイズと見出し閾値を返す。

    - 本文サイズ = フォントサイズ分布の中央値
    - 見出し閾値 = 本文サイズ × 1.05

    Returns:
        (body_font_size, heading_threshold)
    """
    font_sizes = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        blocks = page.get_text("dict")["blocks"]
        for block in blocks:
            if "lines" not in block:
                continue
            y_pos = block["bbox"][1]
            if y_pos <= header_y or y_pos >= footer_y:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    text = span["text"].strip()
                    if text and len(text) >= 2 and re.search(r"[\w\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]", text):
                        font_sizes.append(span["size"])

    if not font_sizes:
        return 10.0, 11.0

    font_sizes.sort()
    body_font_size = font_sizes[len(font_sizes) // 2]
    heading_threshold = body_font_size * 1.05

    return body_font_size, heading_threshold


def _detect_header_footer_y(doc: fitz.Document, sample_pages: int = 10) -> tuple[float, float]:
    """
    ヘッダー・フッター領域の Y 座標を検出する。

    短いドキュメント (3ページ未満) ではヘッダー・フッターの繰り返しパターンを
    検出できないため、フィルタリングを無効化する。

    Returns:
        (header_y_max, footer_y_min)
    """
    from collections import Counter

    pages_to_check = min(sample_pages, len(doc))

    # 短いドキュメントではヘッダー・フッター検出をスキップ
    if pages_to_check < 3:
        page_height = doc[0].rect.height if len(doc) > 0 else 800
        return 0, page_height

    header_positions = []
    footer_positions = []

    for page_num in range(pages_to_check):
        page = doc[page_num]
        page_height = page.rect.height
        blocks = page.get_text("dict")["blocks"]

        for block in blocks:
            if "lines" not in block:
                continue
            y_top = block["bbox"][1]
            y_bottom = block["bbox"][3]

            if y_top < min(page_height * 0.05, 40):
                header_positions.append(round(y_bottom))
            if y_bottom > page_height * 0.95:
                footer_positions.append(round(y_top))

    # 半数以上のページで出現するパターンのみ採用
    min_frequency = max(pages_to_check // 2, 2)

    if header_positions:
        counter = Counter(header_positions)
        common = [pos for pos, count in counter.items() if count >= min_frequency]
        header_y_max = max(common) if common else 0
    else:
        header_y_max = 0

    if footer_positions:
        counter = Counter(footer_positions)
        common = [pos for pos, count in counter.items() if count >= min_frequency]
        footer_y_min = min(common) if common else (doc[0].rect.height if len(doc) > 0 else 800)
    else:
        footer_y_min = doc[0].rect.height if len(doc) > 0 else 800

    return header_y_max, footer_y_min


# ─────────────────────────────────────────────
# 見出しレベル判定
# ─────────────────────────────────────────────


def _detect_heading_tiers(
    doc: fitz.Document, header_y: float, footer_y: float, heading_threshold: float
) -> list[tuple[float, int]]:
    """
    ドキュメント内の見出しフォントサイズを収集し、レベル階層を自動検出する。

    フォントサイズの分布から大→小の順に H1, H2 を割り当てる。
    1pt 以内の差は同一レベルとみなす。
    章見出し (#) と節見出し (##) の2段階のみ使用する。
    3段以上のサイズ差がある場合、タイトル等は章と同じ H1 に圧縮する。

    Returns:
        [(代表サイズ, レベル), ...] サイズ降順。レベルは最大 2。
    """
    heading_sizes: list[float] = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        blocks = page.get_text("dict")["blocks"]
        for block in blocks:
            if "lines" not in block:
                continue
            y_pos = block["bbox"][1]
            if y_pos <= header_y or y_pos >= footer_y:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    text = span["text"].strip()
                    if (
                        text
                        and len(text) >= 2
                        and span["size"] >= heading_threshold
                        and re.search(r"[\w\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]", text)
                    ):
                        heading_sizes.append(round(span["size"], 1))

    if not heading_sizes:
        return []

    # 1pt 以内の差を同一レベルとしてクラスタリング
    unique_sizes = sorted(set(heading_sizes), reverse=True)
    tiers: list[tuple[float, int]] = []
    for size in unique_sizes:
        merged = False
        for tier_size, _ in tiers:
            if abs(size - tier_size) < 1.0:
                merged = True
                break
        if not merged:
            level = min(len(tiers) + 1, 2)
            tiers.append((size, level))

    # 3段以上ある場合: 最小フォントを H2、それ以外を H1 に圧縮
    if len(tiers) > 2:
        compressed = [(size, 1) for size, _ in tiers[:-1]]
        compressed.append((tiers[-1][0], 2))
        tiers = compressed

    return tiers


def _get_heading_level(font_size: float, heading_tiers: list[tuple[float, int]]) -> int:
    """
    フォントサイズからティア対応表を使って見出しレベルを返す。
    マッチしない場合は H2 を返す。
    """
    for tier_size, level in heading_tiers:
        if abs(font_size - tier_size) < 1.0:
            return level
    return 2


def _get_heading_level_from_text(text: str) -> int | None:
    """
    テキスト先頭の章節番号のドット区切り数から見出しレベルを返す。

    例:
        "1. 共通画面"       → 1 (H1)
        "1.1. 詳細"         → 2 (H2)
        "1.1.1. サブ項目"   → 3 (H3)
        "1.1.1.1. 細目"     → 4 (H4)

    マッチしない場合は None を返す。
    最大 H6 に制限。
    """
    m = re.match(r"^([0-9０-９]+[\.\．])+", text.strip())
    if not m:
        return None
    matched = m.group(0)
    # 半角・全角ドットの数をカウント
    dot_count = matched.count(".") + matched.count("．")
    return min(max(dot_count, 1), 6)


_HEADING_NUM_RE = re.compile(r"([0-9０-９]+[\.\．])+\s*\S")


def _extract_headings_from_table(
    table_md: str,
    page: int,
    current_heading_level: int,
    heading_page_map: list[dict],
    md_lines: list[str],
) -> None:
    """テーブルセルのテキストから章節番号見出しを探して heading_page_map / md_lines に追加する。"""
    existing = {e["heading"] for e in heading_page_map}
    for line in table_md.split("\n"):
        if line.startswith("| ---"):
            continue
        cells = [c.strip() for c in line.split("|")]
        for cell in cells:
            if not cell:
                continue
            # セル先頭の見出しパターンを抽出
            for m in _HEADING_NUM_RE.finditer(cell):
                heading_candidate = cell[m.start():].strip()
                # 次の見出しパターンが続く場合は最初の見出しだけ切り出す
                next_m = _HEADING_NUM_RE.search(heading_candidate, pos=len(m.group(0)))
                if next_m:
                    heading_candidate = heading_candidate[: next_m.start()].strip()
                level = _get_heading_level_from_text(heading_candidate)
                if level is None:
                    continue
                # 見出しテキストからタイトル部分を抽出 (番号 + 最初の名称、句点等で区切る)
                title_m = re.match(
                    r"((?:[0-9０-９]+[\.\．])+\s*[^\s。、][^。、]*?)"
                    r"(?=\s+[0-9０-９]+[\.\．]|\s+[^\S\n]*$|\s*$)",
                    heading_candidate,
                )
                if not title_m:
                    # フォールバック: 番号 + 続くテキスト（句点まで）
                    title_m = re.match(
                        r"((?:[0-9０-９]+[\.\．])+\s*[^。、]+?)(?:[。、\s]|$)",
                        heading_candidate,
                    )
                if not title_m:
                    continue
                title = title_m.group(1).strip()
                if title in existing:
                    continue
                existing.add(title)
                heading_page_map.append(
                    {"heading": title, "level": level, "page": page}
                )
                prefix = "#" * level
                if md_lines and md_lines[-1] != "":
                    md_lines.append("")
                md_lines.append(f"{prefix} {title}")
                md_lines.append("")


# ─────────────────────────────────────────────
# テーブル検出・変換
# ─────────────────────────────────────────────


def _fix_cell_text(cell_text: str) -> str:
    """
    PyMuPDF find_tables() のアンダースコア分離バグを修復する。

    find_tables() は '_' を含むテキストで、'_' をスペースに置き換えて
    前の行に残し、'_' 自体を独立した行に分離することがある。
    例: "PMAIN_SystemName" → "PMAIN SystemName\\n_\\n"

    直前の行の最後のスペースを '_' に復元し、孤立した '_' 行を除去する。
    """
    # \n_\n パターン: 直前行の最後のスペースを '_' に復元
    while "\n_\n" in cell_text:
        idx = cell_text.index("\n_\n")
        before = cell_text[:idx]
        after = cell_text[idx + 3:]
        last_space = before.rfind(" ")
        if last_space >= 0:
            before = before[:last_space] + "_" + before[last_space + 1:]
        cell_text = before + "\n" + after

    # 末尾の \n_ パターン
    if cell_text.endswith("\n_"):
        before = cell_text[:-2]
        last_space = before.rfind(" ")
        if last_space >= 0:
            cell_text = before[:last_space] + "_" + before[last_space + 1:]

    # 先頭の _\n パターン (前のセルからの残骸)
    if cell_text.startswith("_\n"):
        cell_text = cell_text[2:]

    return cell_text


def _extract_tables_from_page(page: fitz.Page) -> list[dict]:
    """
    ページからテーブルを検出し、各テーブルの情報を返す。

    PyMuPDF の find_tables() を使用してテーブルを検出する。

    Returns:
        [{
            "bbox": (x0, y0, x1, y1),
            "markdown": "| ... |\\n| --- |\\n| ... |",
        }, ...]
    """
    tables_info = []

    try:
        tables = page.find_tables()
        for table in tables:
            bbox = table.bbox  # (x0, y0, x1, y1)
            rows = table.extract()

            if not rows:
                continue

            # 列数を揃える
            max_cols = max(len(row) for row in rows)
            normalized_rows = []
            for row in rows:
                cells = [_fix_cell_text(cell or "").replace("|", "\\|").replace("\n", " ").strip() for cell in row]
                while len(cells) < max_cols:
                    cells.append("")
                normalized_rows.append(cells)

            # Markdown テーブル生成
            lines = []
            # ヘッダー行
            lines.append("| " + " | ".join(normalized_rows[0]) + " |")
            # 区切り行
            lines.append("| " + " | ".join(["---"] * max_cols) + " |")
            # データ行
            for row in normalized_rows[1:]:
                lines.append("| " + " | ".join(row) + " |")

            tables_info.append(
                {
                    "bbox": bbox,
                    "markdown": "\n".join(lines),
                }
            )
    except Exception as e:
        logger.debug(f"テーブル検出エラー (ページ {page.number + 1}): {e}")

    return tables_info


def _is_in_table(y_pos: float, x_pos: float, tables: list[dict]) -> bool:
    """テキスト位置がテーブル領域内にあるかを判定する"""
    for table in tables:
        x0, y0, x1, y1 = table["bbox"]
        if y0 <= y_pos <= y1 and x0 <= x_pos <= x1:
            return True
    return False


# ─────────────────────────────────────────────
# ページ跨ぎテーブルの結合
# ─────────────────────────────────────────────


def _merge_cross_page_tables(tables_by_page: dict[int, list[dict]], total_pages: int) -> dict[int, list[dict]]:
    """
    ページをまたいで続くテーブルを検出し結合する。

    前ページ末尾のテーブルと次ページ先頭のテーブルについて、
    列数が一致し、かつヘッダー行の内容が一致する場合に
    継続テーブルと判断して結合する。
    """
    if not tables_by_page:
        return tables_by_page

    pages_to_remove_first_table: list[int] = []

    for page_num in range(total_pages - 1):
        if page_num not in tables_by_page:
            continue
        next_page = page_num + 1
        if next_page not in tables_by_page:
            continue

        last_table = tables_by_page[page_num][-1]
        first_table_next = tables_by_page[next_page][0]

        # Markdown テーブルの列数を比較
        last_lines = last_table["markdown"].strip().split("\n")
        next_lines = first_table_next["markdown"].strip().split("\n")

        if len(last_lines) < 2 or len(next_lines) < 3:
            continue

        last_cols = last_lines[0].count("|") - 1
        next_cols = next_lines[0].count("|") - 1

        if last_cols != next_cols or last_cols <= 0:
            continue

        # ヘッダー行の内容が異なる場合は別テーブルとみなしスキップ
        last_header = last_lines[0]
        next_header = next_lines[0]
        if last_header != next_header:
            continue

        # 元テーブル末尾の空行を除去
        orig_lines = last_lines.copy()
        while orig_lines and all(c.strip() == "" for c in orig_lines[-1].split("|")[1:-1]):
            orig_lines.pop()

        # 継続テーブルのヘッダー + セパレータ行をスキップしデータ行を取得
        data_rows = next_lines[2:]
        while data_rows and all(c.strip() == "" for c in data_rows[0].split("|")[1:-1]):
            data_rows.pop(0)

        if data_rows:
            merged_md = "\n".join(orig_lines + data_rows)
            tables_by_page[page_num][-1] = {
                "bbox": last_table["bbox"],
                "markdown": merged_md,
            }
            pages_to_remove_first_table.append(next_page)
            logger.info(f"テーブル結合: ページ {page_num + 1} - {next_page + 1}")

    # 結合済みテーブルを次ページから除去
    for pg in pages_to_remove_first_table:
        if pg in tables_by_page:
            if len(tables_by_page[pg]) == 1:
                del tables_by_page[pg]
            else:
                tables_by_page[pg] = tables_by_page[pg][1:]

    return tables_by_page


# ─────────────────────────────────────────────
# key-value リスト後処理
# ─────────────────────────────────────────────

_KV_PATTERN = re.compile(r"^(.{2,}?)[:：]\s*(.+)$")


def _postprocess_key_value_lists(md_lines: list[str]) -> list[str]:
    """
    連続する key: value 行を Markdown リスト形式に変換する後処理。

    2行以上連続する key: value パターンのみ変換する。
    見出し行・テーブル行・既存リスト行は対象外。
    """
    result: list[str] = []
    kv_buffer: list[str] = []

    def flush_kv():
        if len(kv_buffer) >= 2:
            for line in kv_buffer:
                result.append(f"- {line.strip()}")
        else:
            result.extend(kv_buffer)
        kv_buffer.clear()

    for line in md_lines:
        stripped = line.strip()
        is_kv = bool(
            stripped
            and _KV_PATTERN.match(stripped)
            and not stripped.startswith("#")
            and not stripped.startswith("|")
            and not stripped.startswith("-")
        )
        if is_kv:
            kv_buffer.append(line)
        else:
            flush_kv()
            result.append(line)

    flush_kv()
    return result


# ─────────────────────────────────────────────
# インデント行リスト後処理
# ─────────────────────────────────────────────

_SENTENCE_END_RE = re.compile(r"[。．.]\s*$")


def _postprocess_indented_lists(md_lines: list[str], indented_flags: list[bool]) -> list[str]:
    """
    連続するインデント行（文末が句点でない）を Markdown リスト形式に変換する。

    2行以上連続するインデント候補のみ変換する。
    """
    result: list[str] = []
    buffer: list[int] = []  # indices into md_lines

    def flush():
        if len(buffer) >= 2:
            for idx in buffer:
                result.append(f"- {md_lines[idx].strip()}")
        else:
            for idx in buffer:
                result.append(md_lines[idx])
        buffer.clear()

    for i, line in enumerate(md_lines):
        stripped = line.strip()
        is_candidate = bool(
            stripped
            and i < len(indented_flags)
            and indented_flags[i]
            and not stripped.startswith("#")
            and not stripped.startswith("|")
            and not stripped.startswith("-")
            and not _SENTENCE_END_RE.search(stripped)
        )
        if is_candidate:
            buffer.append(i)
        else:
            flush()
            result.append(line)

    flush()
    return result


# ─────────────────────────────────────────────
# ワードラップ結合
# ─────────────────────────────────────────────

_WRAP_BREAK_RE = re.compile(r"[。．.」）\)）]\s*$")


def _merge_wrapped_blocks(all_blocks: list[TextBlock], page_width: float) -> list[TextBlock]:
    """
    PDF のワードラップにより別ブロックに分割されたテキストを結合する。

    条件:
    - 同一ページ・同一 x 座標 (±3pt)
    - 前ブロックの右端がページ幅の 80% 以上（行末までテキストが届いている）
    - 前ブロックが句点等で終わっていない
    - 両方とも text ブロック（heading でない）
    """
    if not all_blocks:
        return all_blocks

    right_threshold = page_width * 0.80
    result: list[TextBlock] = [all_blocks[0]]

    for block in all_blocks[1:]:
        prev = result[-1]
        if (
            prev.page_num == block.page_num
            and prev.block_type == "text"
            and block.block_type == "text"
            and abs(prev.x_pos - block.x_pos) <= 3
            and prev.x_end >= right_threshold
            and not _WRAP_BREAK_RE.search(prev.text)
        ):
            # 結合: テキストを連結し、x_end を更新
            result[-1] = TextBlock(
                text=prev.text + block.text,
                font_size=max(prev.font_size, block.font_size),
                y_pos=prev.y_pos,
                x_pos=prev.x_pos,
                page_num=prev.page_num,
                is_bold=prev.is_bold or block.is_bold,
                block_type="text",
                x_end=block.x_end,
            )
        else:
            result.append(block)

    return result


# ─────────────────────────────────────────────
# ページ単位のテキスト抽出
# ─────────────────────────────────────────────


def _extract_page_blocks(
    page: fitz.Page,
    header_y: float,
    footer_y: float,
    heading_threshold: float,
    body_font_size: float,
    tables: list[dict],
) -> list[TextBlock]:
    """
    1 ページ分のテキストブロックを抽出する。

    テーブル領域内のテキストはスキップし、テーブルはテーブルとして個別に返す。
    """
    blocks_out: list[TextBlock] = []
    page_num = page.number
    dict_blocks = page.get_text("dict")["blocks"]

    for block in dict_blocks:
        if "lines" not in block:
            continue

        y_top = block["bbox"][1]
        x_left = block["bbox"][0]
        x_right = block["bbox"][2]

        # ヘッダー・フッター除外
        if y_top <= header_y or y_top >= footer_y:
            continue

        # テーブル領域内テキストはスキップ
        if _is_in_table(y_top, x_left, tables):
            continue

        # ブロック内の行を結合
        line_texts = []
        max_font_size = 0.0
        is_bold = False

        for line in block["lines"]:
            span_texts = []
            for span in line["spans"]:
                text = span["text"]
                if text.strip():
                    span_texts.append(text)
                    if span["size"] > max_font_size:
                        max_font_size = span["size"]
                    if "bold" in span.get("font", "").lower():
                        is_bold = True
                    # flags ビットで太字を判定 (bit 4)
                    if span.get("flags", 0) & (1 << 4):
                        is_bold = True

            if span_texts:
                line_texts.append("".join(span_texts))

        if not line_texts:
            continue

        combined_text = "\n".join(line_texts)
        stripped = combined_text.strip()
        if not stripped:
            continue

        # 見出し判定: フォントサイズが閾値以上のテキストを見出し候補とする
        is_heading = (
            max_font_size >= heading_threshold
            and len(stripped) >= 2
            and re.search(r"[\w\u3040-\u309f\u30a0-\u30ff\u4e00-\u9fff]", stripped)
        )

        blocks_out.append(
            TextBlock(
                text=stripped,
                font_size=max_font_size,
                y_pos=y_top,
                x_pos=x_left,
                page_num=page_num,
                is_bold=is_bold,
                block_type="heading" if is_heading else "text",
                x_end=x_right,
            )
        )

    return blocks_out


# ─────────────────────────────────────────────
# Markdown 生成
# ─────────────────────────────────────────────


def _blocks_to_markdown(
    all_blocks: list[TextBlock],
    tables_by_page: dict[int, list[dict]],
    heading_tiers: list[tuple[float, int]],
    total_pages: int,
    skip_ranges: list[tuple[int, float, int, float]] | None = None,
) -> tuple[str, list[dict]]:
    """
    抽出したブロックとテーブルを Markdown テキストに統合する。

    テーブルは y 座標に基づいて正しい位置に挿入する。
    連続する key: value パターンはリスト形式に変換する。

    Returns:
        (markdown_text, heading_page_map)
    """
    md_lines: list[str] = []
    md_indented: list[bool] = []  # parallel: True if line comes from indented block
    page_marker_insertions: list[tuple[int, int]] = []
    heading_page_map: list[dict] = []
    current_heading_level = 0  # 直近の数字見出しのレベルを追跡（ページ跨ぎで保持）

    # 本文の基準 x 座標を算出（テキストブロックの最頻 x 位置）
    from collections import Counter

    text_x_positions = [round(b.x_pos) for b in all_blocks if b.block_type == "text"]
    body_x = Counter(text_x_positions).most_common(1)[0][0] if text_x_positions else 0
    indent_threshold = 10  # pt

    for page_num in range(total_pages):
        # このページのテキストブロック + テーブルを y 座標でソート
        page_blocks = [b for b in all_blocks if b.page_num == page_num]
        page_tables = tables_by_page.get(page_num, [])

        page_marker_insertions.append((len(md_lines), page_num + 1))

        # テーブルを TextBlock 形式で統合
        # (y_pos, type, content, font_size, x_pos)
        items: list[tuple[float, str, str, float, float]] = []

        for block in page_blocks:
            if block.block_type == "heading":
                items.append((block.y_pos, "heading", block.text, block.font_size, block.x_pos))
            else:
                items.append((block.y_pos, "text", block.text, 0.0, block.x_pos))

        for table in page_tables:
            y_pos = table["bbox"][1]
            items.append((y_pos, "table", table["markdown"], 0.0, 0.0))

        # y 座標でソート
        items.sort(key=lambda x: x[0])

        for y_pos, item_type, content, font_size, x_pos_item in items:
            if skip_ranges and _is_in_skip_range(page_num, y_pos, skip_ranges):
                continue
            if item_type == "heading":
                section_level = _get_heading_level_from_text(content)
                if section_level is not None:
                    # 数字パターンの見出し → テキストの番号構造からレベルを決定
                    level = section_level
                    current_heading_level = level
                else:
                    # 非数字パターン (Ａ., MEMO 等)
                    if current_heading_level > 0:
                        # 親見出しが存在 → 親レベル + 1
                        level = min(current_heading_level + 1, 6)
                    else:
                        # 親見出し未出現 → フォントサイズのティア判定
                        level = _get_heading_level(font_size, heading_tiers)
                heading_page_map.append(
                    {"heading": content, "level": level, "page": page_num + 1}
                )
                prefix = "#" * level
                if md_lines and md_lines[-1] != "":
                    md_lines.append("")
                    md_indented.append(False)
                md_lines.append(f"{prefix} {content}")
                md_indented.append(False)
                md_lines.append("")
                md_indented.append(False)
            elif item_type == "table":
                # テーブルセルから見出しパターンを抽出してヘッダーとして登録
                before_len = len(md_lines)
                _extract_headings_from_table(
                    content, page_num + 1, current_heading_level,
                    heading_page_map, md_lines,
                )
                md_indented.extend([False] * (len(md_lines) - before_len))
                if md_lines and md_lines[-1] != "":
                    md_lines.append("")
                    md_indented.append(False)
                md_lines.append(content)
                md_indented.append(False)
                md_lines.append("")
                md_indented.append(False)
            else:
                # テキストブロック: 行単位でリストに追加 (後処理用)
                is_indented = x_pos_item > body_x + indent_threshold
                for line in content.split("\n"):
                    md_lines.append(line)
                    md_indented.append(is_indented)

    # key: value パターンをリスト化
    md_lines = _postprocess_key_value_lists(md_lines)

    # インデント行のリスト化
    md_lines = _postprocess_indented_lists(md_lines, md_indented)

    # ページマーカーは後処理完了後に挿入し、リスト化判定へ影響させない。
    inserted = 0
    for insert_at, page in page_marker_insertions:
        md_lines.insert(insert_at + inserted, f"<!-- page:{page} -->")
        inserted += 1

    # 末尾の余分な空行を除去
    while md_lines and md_lines[-1] == "":
        md_lines.pop()

    # 各見出しに page_end を付与（同レベル以上の次の見出しの開始ページから推定）
    for i, entry in enumerate(heading_page_map):
        page_end = total_pages
        for j in range(i + 1, len(heading_page_map)):
            if heading_page_map[j]["level"] <= entry["level"]:
                page_end = max(entry["page"], heading_page_map[j]["page"] - 1)
                break
        entry["page_end"] = page_end

    return "\n".join(md_lines) + "\n", heading_page_map


# ─────────────────────────────────────────────
# セクションスキップ
# ─────────────────────────────────────────────


def _is_in_skip_range(
    page_num: int, y_pos: float, skip_ranges: list[tuple[int, float, int, float]]
) -> bool:
    """指定位置がスキップ範囲内にあるか判定する。"""
    for start_page, start_y, end_page, end_y in skip_ranges:
        after_start = page_num > start_page or (page_num == start_page and y_pos >= start_y)
        before_end = page_num < end_page or (page_num == end_page and y_pos < end_y)
        if after_start and before_end:
            return True
    return False


def _find_skip_ranges(
    all_blocks: list[TextBlock],
    skip_sections: list[str],
    total_pages: int,
) -> list[tuple[int, float, int, float]]:
    """
    スキップ対象セクションのページ・Y座標範囲を特定する。

    cleansing_pdf の find_section_range と同等のロジック。
    見出しブロックからキーワードを検索し、次の見出しまでの範囲を返す。
    見出しで見つからない場合は全テキストブロックをフォールバック検索する。

    Returns:
        [(start_page, start_y, end_page, end_y), ...]
    """
    headings = [b for b in all_blocks if b.block_type == "heading"]
    ranges: list[tuple[int, float, int, float]] = []

    for keyword in skip_sections:
        # 1. 見出しからキーワードを検索
        match_block = None
        match_idx = -1
        for i, h in enumerate(headings):
            if keyword in h.text:
                match_block = h
                match_idx = i
                break

        # 2. 見出しで見つからない場合、全テキストから検索
        if match_block is None:
            for block in all_blocks:
                if keyword in block.text:
                    match_block = block
                    for i, h in enumerate(headings):
                        if h.page_num > block.page_num or (
                            h.page_num == block.page_num and h.y_pos > block.y_pos
                        ):
                            match_idx = i - 1
                            break
                    else:
                        match_idx = len(headings) - 1
                    break

        if match_block is None:
            logger.info(f"「{keyword}」セクションは見つかりませんでした。")
            continue

        logger.info(
            f"スキップ対象「{keyword}」を検出: ページ {match_block.page_num + 1}, "
            f"y={match_block.y_pos:.0f}"
        )

        # 3. 次の見出しを探す（セクションの終端）
        search_start = max(match_idx + 1, 0)
        end_page = total_pages
        end_y = float("inf")
        for h in headings[search_start:]:
            if h.page_num > match_block.page_num or (
                h.page_num == match_block.page_num and h.y_pos > match_block.y_pos
            ):
                end_page = h.page_num
                end_y = h.y_pos
                logger.info(f"  次のセクション: ページ {end_page + 1} - {h.text[:30]}")
                break

        ranges.append((match_block.page_num, match_block.y_pos, end_page, end_y))

    return ranges


# ─────────────────────────────────────────────
# メインパース関数
# ─────────────────────────────────────────────


def parse_pdf_to_markdown(
    file_path: str,
    output_path: str,
    skip_sections: list[str] | None = None,
    min_headings: int = 0,
    merge_wrapped_lines: bool = False,
) -> tuple[bool, list[dict]]:
    """
    PDF ファイルを直接 Markdown に変換して保存する。

    パース時に見出し・ページマップも同時に抽出する。
    extract_heading_page_map() と同等のマップをパース処理の副産物として生成
    するため、別途呼び出す必要がない。

    処理:
    1. ヘッダー・フッター領域を推定
    2. フォントサイズ分布から本文サイズ・見出し閾値を算出
    3. 各ページでテーブルを検出
    4. テーブル以外のテキストブロックを抽出
    5. 見出し・テーブル・本文を y 座標順に Markdown 統合
    6. 見出しブロックから heading_page_map を生成

    Args:
        file_path: 入力 PDF ファイルパス
        output_path: 出力 Markdown ファイルパス
        skip_sections: スキップするセクションのキーワードリスト
        min_headings: セクション削除を実行する最低見出し数（未満ならスキップ）

    Returns:
        (成功フラグ, heading_page_map)。失敗時は (False, [])。
    """
    if not os.path.exists(file_path):
        logger.error(f"ファイルが見つかりません: {file_path}")
        return False, []

    logger.info(f"パース開始 (PDF直接): {file_path}")
    doc = fitz.open(file_path)

    # 1. ヘッダー・フッター推定
    header_y, footer_y = _detect_header_footer_y(doc)
    logger.info(f"ヘッダー y < {header_y:.0f}, フッター y > {footer_y:.0f}")

    # 2. フォントサイズ解析
    body_font_size, heading_threshold = _analyze_font_sizes(doc, header_y, footer_y)
    logger.info(f"本文フォントサイズ: {body_font_size:.1f}pt, 見出し閾値: {heading_threshold:.1f}pt")

    # 3. 見出しレベル階層の自動検出
    heading_tiers = _detect_heading_tiers(doc, header_y, footer_y, heading_threshold)
    logger.info(f"見出しレベル階層: {heading_tiers}")

    # 4. ページ単位でテーブル検出 → テキスト抽出
    all_blocks: list[TextBlock] = []
    tables_by_page: dict[int, list[dict]] = {}

    for page_num in range(len(doc)):
        page = doc[page_num]

        # テーブル検出
        page_tables = _extract_tables_from_page(page)
        if page_tables:
            tables_by_page[page_num] = page_tables

        # テキストブロック抽出
        page_blocks = _extract_page_blocks(page, header_y, footer_y, heading_threshold, body_font_size, page_tables)
        all_blocks.extend(page_blocks)

    # 5. ページ跨ぎテーブルの結合
    tables_by_page = _merge_cross_page_tables(tables_by_page, len(doc))

    # 5b. ワードラップで分割されたブロックの結合
    if merge_wrapped_lines:
        page_width = doc[0].rect.width if len(doc) > 0 else 595
        all_blocks = _merge_wrapped_blocks(all_blocks, page_width)

    # 6. セクションスキップ範囲の特定
    skip_ranges: list[tuple[int, float, int, float]] = []
    if skip_sections:
        heading_blocks = [b for b in all_blocks if b.block_type == "heading"]
        if min_headings > 0 and len(heading_blocks) < min_headings:
            logger.info(
                f"見出し数が閾値未満のためセクション削除をスキップします "
                f"(検出={len(heading_blocks)}, 閾値={min_headings})"
            )
        else:
            skip_ranges = _find_skip_ranges(all_blocks, skip_sections, len(doc))
            if skip_ranges:
                logger.info(f"セクションスキップ範囲: {len(skip_ranges)} 件")

    # 7. Markdown 生成 + 見出し・ページマップ同時抽出
    markdown_output, heading_page_map = _blocks_to_markdown(
        all_blocks, tables_by_page, heading_tiers, len(doc), skip_ranges
    )
    logger.info(f"見出しマップ同時抽出: {len(heading_page_map)} 件")

    doc.close()

    if not markdown_output.strip():
        logger.warning(f"パース結果が空です: {file_path}")
        return False, heading_page_map

    # 出力
    out_p = Path(output_path)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(markdown_output, encoding="utf-8")
    logger.info(f"パース完了 (PDF直接): {output_path}")
    return True, heading_page_map


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PDF → Markdown 直接パーサー")
    parser.add_argument("--input_path", required=True, help="入力 PDF ファイルパス")
    parser.add_argument("--output_path", required=True, help="出力 Markdown ファイルパス")
    parser.add_argument(
        "--extract_meta",
        action="store_true",
        help="見出し・ページマップも抽出して表示",
    )

    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

    success, heading_map = parse_pdf_to_markdown(args.input_path, args.output_path)

    if args.extract_meta:
        import json

        print(json.dumps(heading_map, ensure_ascii=False, indent=2))

    if not success:
        exit(1)
