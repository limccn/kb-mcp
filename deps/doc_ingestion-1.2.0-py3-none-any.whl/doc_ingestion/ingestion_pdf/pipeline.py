#!/usr/bin/env python3
"""
ingestion_pdf — pdf 前処理

処理フロー:
1. クレンジング + パース (pdf → Markdown 直接変換、見出し・ページマップ同時抽出)
2. チャンキング (Markdown → JSON、見出し・ページメタデータ付与)

"""

import json
import logging
import time
from datetime import datetime
from pathlib import Path

from ..chunking.chunking_heading import chunk_markdown_with_metadata
from .._progress import _cb_progress
from .parse_pdf import parse_pdf_to_markdown

logger = logging.getLogger(__name__)


def run(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict | None = None,
    step_callback: callable = None,
) -> None:
    """pdf 前処理パイプラインを実行する。

    Args:
        input_path: 入力ファイルパス (.pdf)。
        work_dir: ワークディレクトリパス。
        output_md_path: 出力パースファイルパス (.md)。
        output_chunk_path: 出力チャンクファイルパス (.json)。
        config: 設定辞書。clensing / chunking セクションを含む。
        step_callback: 進捗通知用コールバック関数 (prog: float, msg: str) -> None。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        RuntimeError: 各処理ステップが失敗した場合。
    """
    config = config or {}
    input_p = Path(input_path).resolve()
    work_p = Path(work_dir).resolve()
    output_md_p = Path(output_md_path).resolve()
    output_chunk_p = Path(output_chunk_path).resolve()

    if not input_p.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    work_p.mkdir(parents=True, exist_ok=True)

    processing_times: dict = {}

    # --------------------------------------------------
    # 1. パース (pdf → Markdown、見出しマップ同時抽出、セクションスキップ)
    # --------------------------------------------------
    cleansing_config = config.get("ingestion", {}).get("pdf", {})
    pdf_config = cleansing_config.get("cleansing", {})
    skip_sections = pdf_config.get("sections", [])
    min_headings = pdf_config.get("min_headings", 0)
    merge_wrapped_lines = cleansing_config.get("merge_wrapped_lines", False)

    output_md_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[1/2] パース (PDF直接): {input_p.name} -> {output_md_p.name}")
    _cb_progress(step_callback, 0.20, f"[1/2] パース (PDF直接): {input_p.name} -> {output_md_p.name}")
    s = time.time()
    success, heading_page_map = parse_pdf_to_markdown(
        str(input_p),
        str(output_md_p),
        skip_sections=skip_sections,
        min_headings=min_headings,
        merge_wrapped_lines=merge_wrapped_lines,
    )
    elapsed = time.time() - s
    if not success:
        _cb_progress(step_callback, -1, f"[1/2] パース失敗: {input_p}")
        raise RuntimeError(f"[1/2] パース失敗: {input_p}")
    processing_times["1_parse_pdf"] = round(elapsed, 2)
    logger.info(f"[1/2] パース完了 ({elapsed:.1f}s, 見出し{len(heading_page_map)}件): {output_md_p}")
    _cb_progress(step_callback, 0.40, f"[1/2] パース完了 ({elapsed:.1f}s, 見出し{len(heading_page_map)}件)")
    # 見出しマップをJSONに保存 (デバッグ用)
    map_json_p = work_p / "heading_page_map.json"
    with open(map_json_p, "w", encoding="utf-8") as f:
        json.dump(heading_page_map, f, ensure_ascii=False, indent=2)
    logger.info(f"見出しマップ保存: {map_json_p}")

    # --------------------------------------------------
    # 2. チャンキング (Markdown → JSON、メタデータ付き)
    # --------------------------------------------------
    output_chunk_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[2/2] チャンキング: {output_md_p.name} -> {output_chunk_p.name}")
    _cb_progress(step_callback, 0.45, f"[2/2] チャンキング: {output_md_p.name} -> {output_chunk_p.name}")
    chunking_config = config.get("chunking", {})
    chunk_size = chunking_config.get("chunk_size", 8192)
    chunk_overlap = chunking_config.get("chunk_overlap", 200)
    intermediate_md_p = work_p / "chunking_intermediate.md"
    s = time.time()
    chunks = chunk_markdown_with_metadata(
        str(output_md_p),
        str(output_chunk_p),
        heading_page_map=heading_page_map,
        intermediate_md_path=str(intermediate_md_p),
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    elapsed = time.time() - s
    processing_times["2_chunking"] = round(elapsed, 2)
    logger.info(f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク -> {output_chunk_p}")
    _cb_progress(step_callback, 0.60, f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク")

    # --------------------------------------------------
    # 処理時間の記録 (work/processing_time.json)
    # --------------------------------------------------
    if processing_times:
        _save_processing_times(work_p, input_p, processing_times)

    logger.info(f"[pdf] 前処理パイプライン完了: {input_path}")


def _save_processing_times(work_p: Path, input_p: Path, processing_times: dict) -> None:
    time_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input": str(input_p),
        "steps": processing_times,
    }
    time_json_p = work_p / "processing_time.json"
    existing: list = []
    if time_json_p.exists():
        try:
            with open(time_json_p, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                existing = [existing]
        except Exception:
            existing = []
    existing.append(time_record)
    with open(time_json_p, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
    logger.info(f"処理時間を記録しました: {time_json_p}")
