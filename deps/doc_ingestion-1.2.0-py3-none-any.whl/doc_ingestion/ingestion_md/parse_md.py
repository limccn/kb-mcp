"""Markdown 直通パーサー

Markdown は kb のネイティブ形式なので、本文には一切手を加えない。
先頭の YAML frontmatter ブロックだけを剥がして本文を返す — 剥がさないと
出力が「frontmatter が二つある文書」になり、kb 側は二つ目のブロックを
本文として読む（メタデータが本文に混ざる）。

エンコーディングは ingestion_txt と同じ凍結チェーンを使う
(utf-8-sig → utf-8 → cp932 → cp1252)。鎖は一箇所にしか置かない。
"""

import logging

from doc_ingestion.ingestion_txt.parse_txt import parse_txt

logger = logging.getLogger(__name__)


def strip_frontmatter(text: str) -> tuple[str, int]:
    """先頭の YAML frontmatter ブロックを剥がす。

    先頭行が ``---`` ちょうどで、その後に閉じの ``---`` 行があるときだけ
    frontmatter とみなす（Git 衝突マーカーや水平線を誤認しない）。
    閉じが無い場合は frontmatter とみなさずそのまま返す。

    Returns:
        (本文, 剥がしたブロック数) — 剥がさなかったときは (text, 0)。
    """
    lines = text.split("\n")
    if not lines or lines[0].strip() != "---":
        return text, 0
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return "\n".join(lines[i + 1:]).lstrip("\n"), 1
    return text, 0


def parse_md(file_path: str) -> tuple[str, dict]:
    """Markdown を読み、本文を返す。

    Args:
        file_path: 入力ファイルパス。

    Returns:
        (本文, stats)。stats は剥がした frontmatter があるときだけ
        ``{"frontmatter": 1}``、無いときは空 dict。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        ValueError: 凍結チェーンのいずれでもデコードできない場合。
    """
    body, stripped = strip_frontmatter(parse_txt(file_path))
    # 空出力の判定は convert() が一箇所で持っている（「空の markdown を返さない」
    # という契約）。ここで二つ目の判定を足さない。
    logger.info(f"[md] 読み込み完了 ({file_path})")
    return body, ({"frontmatter": stripped} if stripped else {})