#!/usr/bin/env python3
"""
ingestion_docx — docx 前処理

処理フロー:
1. クレンジング + パース (docx → Markdown 直接変換、見出し・ページマップ同時抽出)
2. チャンキング (Markdown → JSON、見出し・ページメタデータ付与)

"""

import json
import logging
import time
from datetime import datetime
from pathlib import Path

from ..chunking.chunking_heading import chunk_markdown_with_metadata
from .._progress import _cb_progress
from .parse_docx import parse_docx_to_markdown

logger = logging.getLogger(__name__)


def run(
    input_path: str,
    work_dir: str,
    output_md_path: str,
    output_chunk_path: str,
    config: dict | None = None,
    step_callback: callable = None,
) -> None:
    """docx 前処理パイプラインを実行する。

    Args:
        input_path: 入力ファイルパス (.docx)。
        work_dir: ワークディレクトリパス。
        output_md_path: 出力パースファイルパス (.md)。
        output_chunk_path: 出力チャンクファイルパス (.json)。
        config: 設定辞書。clensing / chunking セクションを含む。
        step_callback: 進捗通知用コールバック関数 (prog: float, msg: str) -> None。

    Raises:
        FileNotFoundError: 入力ファイルが存在しない場合。
        RuntimeError: 各処理ステップが失敗した場合。
    """
    config = config or {}
    input_p = Path(input_path).resolve()
    work_p = Path(work_dir).resolve()
    output_md_p = Path(output_md_path).resolve()
    output_chunk_p = Path(output_chunk_path).resolve()

    if not input_p.exists():
        raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    work_p.mkdir(parents=True, exist_ok=True)

    processing_times: dict = {}

    # --------------------------------------------------
    # 1. パース (docx → Markdown、見出しマップ同時抽出)
    #    クレンジング（TOC・セクション除外）はパース内で実施し、
    #    オリジナルのページ番号を保持する。
    # --------------------------------------------------
    # 1a. パース (Markdown変換 + 見出しマップ抽出)
    output_md_p.parent.mkdir(parents=True, exist_ok=True)
    parse_config = config.get("ingestion", {}).get("docx", {})
    resolve_numbering = parse_config.get("resolve_numbering", False)
    extract_textbox = parse_config.get("extract_textbox", True)
    textbox_min_chars = parse_config.get("textbox_min_chars", 10)
    # スキップ設定をパーサーに渡す
    skip_sections = parse_config.get("skip_sections", [])
    current_path = input_p
    logger.info(f"[1/2] パース (DOCX直接, 番号解決={'ON' if resolve_numbering else 'OFF'}, テキストボックス={'ON' if extract_textbox else 'OFF'}, セクションスキップ={skip_sections or 'なし'}): {current_path.name} -> {output_md_p.name}")
    _cb_progress(step_callback, 0.20, f"[1/2] パース (DOCX直接): {current_path.name} -> {output_md_p.name}")
    s = time.time()
    success, heading_page_map, _stats = parse_docx_to_markdown(
        str(current_path), str(output_md_p),
        resolve_numbering=resolve_numbering,
        extract_textbox=extract_textbox,
        textbox_min_chars=textbox_min_chars,
        skip_sections=skip_sections,
    )
    elapsed = time.time() - s
    if not success:
        _cb_progress(step_callback, -1, f"[1/2] パース失敗: {current_path}")
        raise RuntimeError(f"[1/2] パース失敗: {current_path}")
    processing_times["1_parse_docx"] = round(elapsed, 2)
    logger.info(f"[1/2] パース完了 ({elapsed:.1f}s, 見出し{len(heading_page_map)}件): {output_md_p}")
    _cb_progress(step_callback, 0.40, f"[1/2] パース完了 ({elapsed:.1f}s, 見出し{len(heading_page_map)}件)")
    # 見出しマップをJSONに保存 (デバッグ用)
    map_json_p = work_p / "heading_page_map.json"
    with open(map_json_p, "w", encoding="utf-8") as f:
        json.dump(heading_page_map, f, ensure_ascii=False, indent=2)
    logger.info(f"見出しマップ保存: {map_json_p}")

    # --------------------------------------------------
    # 2. チャンキング (Markdown → JSON、メタデータ付き)
    # --------------------------------------------------
    output_chunk_p.parent.mkdir(parents=True, exist_ok=True)
    logger.info(f"[2/2] チャンキング: {output_md_p.name} -> {output_chunk_p.name}")
    _cb_progress(step_callback, 0.45, f"[2/2] チャンキング: {output_md_p.name} -> {output_chunk_p.name}")
    chunking_config = config.get("chunking", {})
    chunk_size = chunking_config.get("chunk_size", 8192)
    chunk_overlap = chunking_config.get("chunk_overlap", 200)
    intermediate_md_p = work_p / "chunking_intermediate.md"
    s = time.time()
    chunks = chunk_markdown_with_metadata(
        str(output_md_p),
        str(output_chunk_p),
        heading_page_map=heading_page_map,
        intermediate_md_path=str(intermediate_md_p),
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    elapsed = time.time() - s
    processing_times["2_chunking"] = round(elapsed, 2)
    logger.info(f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク -> {output_chunk_p}")
    _cb_progress(step_callback, 0.60, f"[2/2] チャンキング完了 ({elapsed:.1f}s): {len(chunks)}チャンク")

    # --------------------------------------------------
    # 処理時間の記録 (work/processing_time.json)
    # --------------------------------------------------
    if processing_times:
        _save_processing_times(work_p, input_p, processing_times)

    logger.info(f"[docx] 前処理パイプライン完了: {input_path}")


def _save_processing_times(work_p: Path, input_p: Path, processing_times: dict) -> None:
    time_record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "input": str(input_p),
        "steps": processing_times,
    }
    time_json_p = work_p / "processing_time.json"
    existing: list = []
    if time_json_p.exists():
        try:
            with open(time_json_p, "r", encoding="utf-8") as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                existing = [existing]
        except Exception:
            existing = []
    existing.append(time_record)
    with open(time_json_p, "w", encoding="utf-8") as f:
        json.dump(existing, f, ensure_ascii=False, indent=2)
    logger.info(f"処理時間を記録しました: {time_json_p}")
