#!/usr/bin/env python3
"""
DOCX → Markdown 直接パーサー

python-docx を使用して docx ファイルから直接テキストを取得し、
Markdown形式に変換する。Docling / PDF変換を経由しない。

対応要素:
- 見出し (Heading 1-9) → Markdown # / ## / ###
- テーブル → Markdown テーブル
- リスト → Markdown リスト (箇条書き / 番号付き)
- 段落 → テキスト
- インライン書式 (太字 / 斜体)
- ハイパーリンク → [テキスト](URL)
- 非テキスト要素 (画像 / ヘッダー・フッター / 脚注 / コメント) は
  Markdown 化せず stats としてカウントのみ行う
"""

import argparse
import logging
import os
import re
from pathlib import Path

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml.ns import qn

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# ヘルパー: スタイル判定
# ─────────────────────────────────────────────


def _get_style_name(doc, element):
    """段落要素のスタイル名を取得する"""
    pPr = element.find(qn("w:pPr"))
    if pPr is not None:
        pStyle = pPr.find(qn("w:pStyle"))
        if pStyle is not None:
            style_id = pStyle.get(qn("w:val"))
            if style_id:
                try:
                    for style in doc.styles:
                        if style.style_id == style_id:
                            return style.name
                except Exception:
                    pass
    return None


def _get_heading_level(doc, element):
    """見出しレベルを返す (1-9)。見出しでなければ None"""
    style_name = _get_style_name(doc, element)
    if style_name and re.match(r"(Heading|見出し)\s*\d", style_name, re.IGNORECASE):
        m = re.search(r"\d+", style_name)
        if m:
            return int(m.group())
    return None


def _is_toc_paragraph(doc, element):
    """目次 (TOC) スタイルの段落かどうかを判定する"""
    style_name = _get_style_name(doc, element)
    if style_name:
        if re.match(r"toc\s*\d", style_name, re.IGNORECASE) or "目次" in style_name:
            return True
    return False


def _is_list_paragraph(doc, element):
    """リスト項目かどうかを判定する"""
    style_name = _get_style_name(doc, element)
    if style_name and re.match(r"(List|リスト)", style_name, re.IGNORECASE):
        return True
    # numPr (番号付けプロパティ) の存在で判定
    pPr = element.find(qn("w:pPr"))
    if pPr is not None:
        numPr = pPr.find(qn("w:numPr"))
        if numPr is not None:
            return True
    return False


def _get_list_level(element):
    """リストのインデントレベルを返す (0-based)"""
    pPr = element.find(qn("w:pPr"))
    if pPr is not None:
        numPr = pPr.find(qn("w:numPr"))
        if numPr is not None:
            ilvl = numPr.find(qn("w:ilvl"))
            if ilvl is not None:
                return int(ilvl.get(qn("w:val"), "0"))
    return 0


def _has_explicit_page_break(element):
    """明示的ページブレーク (w:br type="page") が含まれるか"""
    for br in element.iter(qn("w:br")):
        if br.get(qn("w:type")) == "page":
            return True
    return False


def _has_rendered_page_break(element):
    """レンダリング済みページブレーク (w:lastRenderedPageBreak) が含まれるか"""
    for _ in element.iter(qn("w:lastRenderedPageBreak")):
        return True
    return False


# ─────────────────────────────────────────────
# 自動番号付け解決 (numbering.xml + styles.xml)
# ─────────────────────────────────────────────


def _to_roman(num: int) -> str:
    """整数をローマ数字に変換する"""
    vals = [
        (1000, "M"), (900, "CM"), (500, "D"), (400, "CD"),
        (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
        (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I"),
    ]
    result = ""
    for val, sym in vals:
        while num >= val:
            result += sym
            num -= val
    return result


def _format_number(value: int, num_fmt: str) -> str:
    """numFmt に従って整数を書式化する"""
    if num_fmt in ("decimal", "decimalFullWidth"):
        return str(value)
    elif num_fmt == "lowerLetter":
        return chr(ord("a") + (value - 1) % 26) if value >= 1 else str(value)
    elif num_fmt == "upperLetter":
        return chr(ord("A") + (value - 1) % 26) if value >= 1 else str(value)
    elif num_fmt == "lowerRoman":
        return _to_roman(value).lower() if value >= 1 else str(value)
    elif num_fmt == "upperRoman":
        return _to_roman(value) if value >= 1 else str(value)
    elif num_fmt in ("japaneseCounting", "japaneseDigitalTenThousand"):
        jp_digits = "〇一二三四五六七八九"
        if 0 <= value <= 9:
            return jp_digits[value]
        return str(value)
    elif num_fmt == "bullet":
        return "•"
    elif num_fmt == "none":
        return ""
    return str(value)


class _NumberingResolver:
    """Word の自動番号付け (w:numbering) を解決する。

    w:numbering.xml と w:styles.xml をパースし、各段落の番号テキストを
    逐次的に解決する。parse_docx_to_markdown のループ内で段落ごとに
    resolve() を呼び出すことで、カウンタを管理しつつ番号テキストを返す。
    """

    def __init__(self, doc):
        # abstractNumId -> {ilvl -> {"start", "numFmt", "lvlText"}}
        self._abstract_nums: dict[str, dict[int, dict]] = {}
        # numId -> abstractNumId
        self._num_map: dict[str, str] = {}
        # numId -> {ilvl -> {"start": int}} (startOverride)
        self._lvl_overrides: dict[str, dict[int, dict]] = {}
        # styleId -> (numId, ilvl)
        self._style_numpr: dict[str, tuple[str, int]] = {}
        # numId -> {ilvl -> current_counter}
        self._counters: dict[str, dict[int, int]] = {}

        self._parse(doc)

    # ── パース ──────────────────────────────────

    def _parse(self, doc):
        self._parse_numbering(doc)
        self._parse_styles(doc)

    def _parse_numbering(self, doc):
        """numbering.xml から abstractNum / num 定義を読み取る"""
        try:
            numbering_part = doc.part.numbering_part
            if numbering_part is None:
                return
            numbering_el = numbering_part.element
        except Exception:
            return

        # abstractNum
        for abstract_num in numbering_el.findall(qn("w:abstractNum")):
            abstract_num_id = abstract_num.get(qn("w:abstractNumId"))
            levels: dict[int, dict] = {}
            for lvl in abstract_num.findall(qn("w:lvl")):
                ilvl = int(lvl.get(qn("w:ilvl"), "0"))
                start_el = lvl.find(qn("w:start"))
                start = int(start_el.get(qn("w:val"), "1")) if start_el is not None else 1
                numfmt_el = lvl.find(qn("w:numFmt"))
                numfmt = numfmt_el.get(qn("w:val"), "decimal") if numfmt_el is not None else "decimal"
                lvltext_el = lvl.find(qn("w:lvlText"))
                lvltext = lvltext_el.get(qn("w:val"), "") if lvltext_el is not None else ""
                levels[ilvl] = {"start": start, "numFmt": numfmt, "lvlText": lvltext}
            self._abstract_nums[abstract_num_id] = levels

        # num -> abstractNumId + lvlOverride
        for num in numbering_el.findall(qn("w:num")):
            num_id = num.get(qn("w:numId"))
            abstract_ref = num.find(qn("w:abstractNumId"))
            if abstract_ref is not None:
                self._num_map[num_id] = abstract_ref.get(qn("w:val"))
            for override in num.findall(qn("w:lvlOverride")):
                ilvl = int(override.get(qn("w:ilvl"), "0"))
                start_override = override.find(qn("w:startOverride"))
                if start_override is not None:
                    self._lvl_overrides.setdefault(num_id, {})[ilvl] = {
                        "start": int(start_override.get(qn("w:val"), "1"))
                    }
                # lvlOverride 内の lvl 要素 (フォーマット上書き)
                lvl_el = override.find(qn("w:lvl"))
                if lvl_el is not None:
                    start_el = lvl_el.find(qn("w:start"))
                    numfmt_el = lvl_el.find(qn("w:numFmt"))
                    lvltext_el = lvl_el.find(qn("w:lvlText"))
                    ovr: dict = self._lvl_overrides.setdefault(num_id, {}).setdefault(ilvl, {})
                    if start_el is not None:
                        ovr["start"] = int(start_el.get(qn("w:val"), "1"))
                    if numfmt_el is not None:
                        ovr["numFmt"] = numfmt_el.get(qn("w:val"))
                    if lvltext_el is not None:
                        ovr["lvlText"] = lvltext_el.get(qn("w:val"))

    def _parse_styles(self, doc):
        """styles.xml からスタイルに紐付いた numPr を取得する"""
        try:
            styles_el = doc.styles.element
        except Exception:
            return
        for style in styles_el.findall(qn("w:style")):
            style_id = style.get(qn("w:styleId"))
            pPr = style.find(qn("w:pPr"))
            if pPr is None:
                continue
            numPr = pPr.find(qn("w:numPr"))
            if numPr is None:
                continue
            numId_el = numPr.find(qn("w:numId"))
            if numId_el is None:
                continue
            num_id = numId_el.get(qn("w:val"))
            if not num_id or num_id == "0":
                continue
            ilvl_el = numPr.find(qn("w:ilvl"))
            ilvl = int(ilvl_el.get(qn("w:val"), "0")) if ilvl_el is not None else 0
            self._style_numpr[style_id] = (num_id, ilvl)

    # ── 番号解決 ────────────────────────────────

    def _get_numpr(self, element):
        """段落の numId / ilvl を直接指定またはスタイル経由で取得する。

        Returns:
            (numId, ilvl) or (None, None)
        """
        pPr = element.find(qn("w:pPr"))
        num_id = None
        ilvl = None

        if pPr is not None:
            numPr = pPr.find(qn("w:numPr"))
            if numPr is not None:
                numId_el = numPr.find(qn("w:numId"))
                ilvl_el = numPr.find(qn("w:ilvl"))
                if numId_el is not None:
                    num_id = numId_el.get(qn("w:val"))
                if ilvl_el is not None:
                    ilvl = int(ilvl_el.get(qn("w:val"), "0"))

        # numId="0" は明示的な「番号なし」指定
        if num_id == "0":
            return None, None

        # 直接指定がなければスタイル経由で取得
        if num_id is None:
            style_id = None
            if pPr is not None:
                pStyle_el = pPr.find(qn("w:pStyle"))
                if pStyle_el is not None:
                    style_id = pStyle_el.get(qn("w:val"))
            if style_id and style_id in self._style_numpr:
                s_num_id, s_ilvl = self._style_numpr[style_id]
                num_id = s_num_id
                if ilvl is None:
                    ilvl = s_ilvl

        if num_id is None:
            return None, None

        return num_id, ilvl if ilvl is not None else 0

    def _get_level_def(self, num_id: str, ilvl: int) -> dict | None:
        """numId + ilvl に対応するレベル定義を取得する (override 考慮)"""
        abstract_id = self._num_map.get(num_id)
        if abstract_id is None:
            return None
        levels = self._abstract_nums.get(abstract_id, {})
        base = levels.get(ilvl)
        if base is None:
            return None
        # lvlOverride でフォーマットが上書きされている場合はマージ
        ovr = (self._lvl_overrides.get(num_id) or {}).get(ilvl)
        if ovr:
            merged = dict(base)
            if "numFmt" in ovr:
                merged["numFmt"] = ovr["numFmt"]
            if "lvlText" in ovr:
                merged["lvlText"] = ovr["lvlText"]
            if "start" in ovr:
                merged["start"] = ovr["start"]
            return merged
        return base

    def resolve(self, element) -> tuple[str | None, bool]:
        """段落の番号テキストを解決する。

        内部カウンタを更新するため、文書中の全段落に対して順番に呼び出す必要がある。

        Args:
            element: 段落 XML 要素 (w:p)

        Returns:
            (numbering_text, is_bullet)
            - numbering_text: 番号テキスト ("1.", "1.1" 等)。番号なしは None。
            - is_bullet: 箇条書きの場合 True
        """
        num_id, ilvl = self._get_numpr(element)
        if num_id is None:
            return None, False

        level_def = self._get_level_def(num_id, ilvl)
        if level_def is None:
            return None, False

        num_fmt = level_def["numFmt"]

        # 箇条書き
        if num_fmt == "bullet":
            return None, True

        # 番号なし (none)
        if num_fmt == "none":
            return None, False

        # ── カウンター管理 (abstractNumId 単位で共有) ──
        abstract_id = self._num_map.get(num_id)
        if abstract_id is None:
            return None, False

        if abstract_id not in self._counters:
            self._counters[abstract_id] = {}

        start = level_def["start"]
        if ilvl not in self._counters[abstract_id]:
            self._counters[abstract_id][ilvl] = start
        else:
            self._counters[abstract_id][ilvl] += 1

        # 下位レベルをリセット
        for lvl_key in list(self._counters[abstract_id].keys()):
            if lvl_key > ilvl:
                del self._counters[abstract_id][lvl_key]

        # ── lvlText パターンを解決 (%1, %2, … → 数値) ──
        lvl_text = level_def["lvlText"]
        levels = self._abstract_nums.get(abstract_id, {})

        result = lvl_text
        for i in range(8, -1, -1):  # %9 → %1 の順で置換
            placeholder = f"%{i + 1}"
            if placeholder not in result:
                continue
            ref_def = self._get_level_def(num_id, i)
            if ref_def:
                # abstract 定義の start をフォールバックに使用
                base = levels.get(i)
                fallback = base["start"] if base else ref_def["start"]
                ref_value = self._counters[abstract_id].get(i, fallback)
                formatted = _format_number(ref_value, ref_def["numFmt"])
                result = result.replace(placeholder, formatted)

        if not result.strip():
            return None, False

        return result, False


# ─────────────────────────────────────────────
# ヘルパー: インライン書式抽出
# ─────────────────────────────────────────────


def _extract_run_text(run_element):
    """run 要素からテキストとインライン書式を抽出する"""
    text_parts = []
    for child in run_element:
        tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
        if tag == "t":
            text_parts.append(child.text or "")
        elif tag == "tab":
            text_parts.append("\t")
        elif tag == "br":
            br_type = child.get(qn("w:type"))
            if br_type != "page":
                text_parts.append("\n")
    raw_text = "".join(text_parts)
    if not raw_text.strip():
        return ""

    # 太字 / 斜体の判定
    rPr = run_element.find(qn("w:rPr"))
    is_bold = False
    is_italic = False
    if rPr is not None:
        b = rPr.find(qn("w:b"))
        if b is not None and b.get(qn("w:val"), "true") != "false":
            is_bold = True
        bCs = rPr.find(qn("w:bCs"))
        if bCs is not None and bCs.get(qn("w:val"), "true") != "false":
            is_bold = True
        i = rPr.find(qn("w:i"))
        if i is not None and i.get(qn("w:val"), "true") != "false":
            is_italic = True

    if is_bold and is_italic:
        return f"***{raw_text}***"
    elif is_bold:
        return f"**{raw_text}**"
    elif is_italic:
        return f"*{raw_text}*"
    return raw_text


def _local_name(tag) -> str:
    """タグから名前空間を除いたローカル名を返す"""
    return tag.split("}")[-1] if "}" in tag else tag


# 削除済みテキストのコンテナ (w:del は w:delText, w:moveFrom は移動元の痕跡)
_SKIPPED_TEXT_CONTAINERS = ("del", "moveFrom")

# テキストボックス。段落テキストからは除外し、
# _extract_textbox_paragraphs がコードブロックとして別途出力する。
_TEXTBOX_TAG = "txbxContent"


def _resolve_hyperlink_url(hyperlink_element, rels):
    """w:hyperlink の r:id から外部 URL を解決する。

    Args:
        hyperlink_element: w:hyperlink 要素
        rels: 文書パートのリレーションシップ (doc.part.rels)。None なら解決しない。

    Returns:
        str | None: 外部 URL。解決できない場合は None。
    """
    if rels is None:
        return None
    rid = hyperlink_element.get(qn("r:id"))
    if not rid:
        return None
    rel = rels.get(rid)
    if rel is None:
        return None
    return getattr(rel, "target_ref", None) or None


def _extract_paragraph_text(element, rels=None):
    """段落要素から全テキストを抽出する (インライン書式付き)。

    run / ハイパーリンク / インラインコンテナ (w:ins, w:sdt, w:smartTag,
    w:fldSimple など) を子孫方向に辿って収集する。削除痕跡 (w:del /
    w:moveFrom) とテキストボックス (w:txbxContent) は除外する。

    Args:
        element: 段落 (w:p) またはその配下の要素
        rels: ハイパーリンク URL 解決に使うリレーションシップ。None の場合は
            ハイパーリンクのテキストのみを出力する。

    Returns:
        str: 抽出されたテキスト
    """
    parts = []
    for child in element:
        tag = _local_name(child.tag)
        if tag in _SKIPPED_TEXT_CONTAINERS or tag == _TEXTBOX_TAG:
            continue
        if tag == "r":
            parts.append(_extract_run_text(child))
        elif tag == "hyperlink":
            text = _extract_paragraph_text(child, rels)
            if not text:
                continue
            url = _resolve_hyperlink_url(child, rels)
            parts.append(f"[{text}]({url})" if url else text)
        else:
            # w:ins / w:sdt / w:sdtContent / w:smartTag / w:fldSimple などの
            # インラインコンテナは配下の run をそのまま収集する
            parts.append(_extract_paragraph_text(child, rels))
    return "".join(parts)


# テキストボックスとみなす最小文字数のデフォルト (これ以下は注釈的テキストとしてスキップ)
_DEFAULT_TEXTBOX_MIN_CHARS = 10


def _extract_textbox_paragraphs(element, min_chars=_DEFAULT_TEXTBOX_MIN_CHARS, rels=None):
    """段落要素内のテキストボックス (w:txbxContent) からテキストを抽出する。

    テキストボックスの内容は ``` コードブロックで囲んで出力する。
    全文字数が *min_chars* 以下の短い注釈的テキストボックスは
    スキップする (min_chars=0 でフィルタ無効)。

    Args:
        element: 段落 XML 要素 (w:p)
        min_chars: テキストボックスの最小文字数。これ以下はスキップ。
        rels: ハイパーリンク URL 解決に使うリレーションシップ。

    Returns:
        list[str]: テキストボックスごとの Markdown テキスト (コードブロック囲み)。
        テキストボックスがない場合は空リスト。
    """
    txbx_contents = list(element.iter(qn("w:txbxContent")))
    if not txbx_contents:
        return []

    results = []
    for txbx in txbx_contents:
        txbx_lines = []
        for p in txbx.findall(qn("w:p")):
            text = _extract_paragraph_text(p, rels).strip()
            txbx_lines.append(text)
        # 末尾の空行を除去
        while txbx_lines and not txbx_lines[-1]:
            txbx_lines.pop()
        # テキストボックスにテキストがある場合のみ
        combined = "\n".join(txbx_lines).strip()
        if not combined:
            continue
        # 短い注釈的テキストはスキップ
        if min_chars > 0 and len(combined) <= min_chars:
            continue
        # コードブロックで囲む
        result = "```\n" + combined + "\n```"
        results.append(result)
    return results


# ─────────────────────────────────────────────
# テーブル → Markdown 変換
# ─────────────────────────────────────────────


def _table_to_markdown(table_element, doc):
    """テーブル要素を Markdown テーブルに変換する"""
    rels = doc.part.rels
    rows_data = []
    for tr in table_element.findall(qn("w:tr")):
        cells = []
        for tc in tr.findall(qn("w:tc")):
            # セル内の全段落テキストを結合
            cell_texts = []
            for p in tc.findall(qn("w:p")):
                text = _extract_paragraph_text(p, rels).strip()
                cell_texts.append(text)
            cell_text = " ".join(cell_texts).replace("|", "\\|")
            # gridSpan (列結合) の処理
            tcPr = tc.find(qn("w:tcPr"))
            grid_span = 1
            if tcPr is not None:
                gs = tcPr.find(qn("w:gridSpan"))
                if gs is not None:
                    grid_span = int(gs.get(qn("w:val"), "1"))
            cells.append(cell_text)
            # 結合セルの場合、空セルを補完
            for _ in range(grid_span - 1):
                cells.append("")
        rows_data.append(cells)

    if not rows_data:
        return ""

    # 列数を揃える
    max_cols = max(len(row) for row in rows_data)
    for row in rows_data:
        while len(row) < max_cols:
            row.append("")

    # Markdown テーブル生成
    lines = []
    # ヘッダー行
    header = rows_data[0]
    lines.append("| " + " | ".join(header) + " |")
    # 区切り行
    lines.append("| " + " | ".join(["---"] * max_cols) + " |")
    # データ行
    for row in rows_data[1:]:
        lines.append("| " + " | ".join(row) + " |")

    return "\n".join(lines)


# ─────────────────────────────────────────────
# 非テキスト要素のカウント (stats)
# ─────────────────────────────────────────────

# VML 名前空間 (画像データのみを画像として数えるため)
_VML_IMAGEDATA_TAG = "{urn:schemas-microsoft-com:vml}imagedata"


def _empty_stats() -> dict:
    """未変換要素カウントのゼロ値 (キーは固定)"""
    return {"images": 0, "headers_footers": 0, "footnotes": 0, "comments": 0}


def _part_element(part):
    """OPC パートの XML ルート要素を返す (未知のパートは blob から解析)"""
    element = getattr(part, "element", None)
    if element is not None:
        return element
    blob = getattr(part, "blob", None)
    if not blob:
        return None
    from lxml import etree

    try:
        return etree.fromstring(blob)
    except Exception:
        return None


def _related_part(doc, reltype):
    """文書パートから reltype で辿れるパートを返す (無ければ None)"""
    try:
        return doc.part.part_related_by(reltype)
    except KeyError:
        return None


def _has_visible_content(element) -> bool:
    """要素配下にテキストまたは描画コンテンツがあるか"""
    if element is None:
        return False
    for t in element.iter(qn("w:t")):
        if (t.text or "").strip():
            return True
    for _ in element.iter(qn("w:drawing")):
        return True
    return False


def _count_images(body) -> int:
    """本文中の画像 (a:blip / v:imagedata を持つ描画) を数える。

    描画テキストボックスは Markdown 化されるため、画像データを持つ
    ものだけを画像として数える。
    """
    return (
        sum(1 for _ in body.iter(qn("a:blip")))
        + sum(1 for _ in body.iter(_VML_IMAGEDATA_TAG))
    )


def _count_headers_footers(doc) -> int:
    """内容を持つヘッダー / フッター部品の数を返す"""
    partnames = set()
    for rel in doc.part.rels.values():
        if rel.is_external or rel.reltype not in (RT.HEADER, RT.FOOTER):
            continue
        part = rel.target_part
        if part.partname in partnames:
            continue
        if _has_visible_content(_part_element(part)):
            partnames.add(part.partname)
    return len(partnames)


def _count_footnotes(doc) -> int:
    """footnotes.xml 内の脚注 (区切り用の特殊脚注を除く) の数を返す"""
    part = _related_part(doc, RT.FOOTNOTES)
    element = _part_element(part) if part is not None else None
    if element is None:
        return 0
    return sum(1 for fn in element.iter(qn("w:footnote")) if fn.get(qn("w:type")) is None)


def _count_comments(doc) -> int:
    """comments.xml 内のコメントの数を返す"""
    part = _related_part(doc, RT.COMMENTS)
    element = _part_element(part) if part is not None else None
    if element is None:
        return 0
    return sum(1 for _ in element.iter(qn("w:comment")))


def _collect_stats(doc) -> dict:
    """未変換要素 (画像 / ヘッダー・フッター / 脚注 / コメント) を数える"""
    return {
        "images": _count_images(doc.element.body),
        "headers_footers": _count_headers_footers(doc),
        "footnotes": _count_footnotes(doc),
        "comments": _count_comments(doc),
    }


# ─────────────────────────────────────────────
# 見出し終了ページの算出
# ─────────────────────────────────────────────


def _fill_page_end(heading_page_map: list[dict], last_page: int) -> None:
    """各見出しの終了ページ (page_end) を算出して辞書に追加する。

    同レベル以上の次の見出しの開始ページを参照し、
    その見出しの直前ページまでを範囲とする。
    最後の見出しはドキュメント最終ページを終了ページとする。
    """
    n = len(heading_page_map)
    for i in range(n):
        current_level = heading_page_map[i]["level"]
        page_end = heading_page_map[i]["page"]  # 自身の開始ページから開始
        # 同レベル以上の次の見出しを探す
        for j in range(i + 1, n):
            next_level = heading_page_map[j]["level"]
            if next_level <= current_level:
                # 次の同レベル以上の見出しの開始ページの直前
                # ただし下位見出しで追跡済みのページは維持
                next_page = heading_page_map[j]["page"]
                page_end = max(next_page - 1, page_end)
                break
            else:
                # 下位見出しの開始ページも終了ページ候補として追跡
                page_end = max(heading_page_map[j]["page"], page_end)
        else:
            # 同レベル以上の見出しが後続にない → ドキュメント最終ページまで
            page_end = max(page_end, last_page)
        # ドキュメント最終ページを超えないように
        page_end = min(page_end, last_page)
        heading_page_map[i]["page_end"] = page_end


# ─────────────────────────────────────────────
# メインパース関数
# ─────────────────────────────────────────────


def parse_docx_to_markdown(
    file_path: str,
    output_path: str,
    resolve_numbering: bool = True,
    extract_textbox: bool = True,
    textbox_min_chars: int = _DEFAULT_TEXTBOX_MIN_CHARS,
    skip_sections: list[str] | None = None,
) -> tuple[bool, list[dict], dict]:
    """
    DOCX ファイルを直接 Markdown に変換して保存する。

    パース時に見出し・ページマップも同時に抽出する。
    extract_heading_page_map() と同等のマップをパース処理の副産物として生成
    するため、別途呼び出す必要がない。
    目次 (TOC) スタイルの段落は常にスキップされる。

    Args:
        file_path: 入力 DOCX ファイルパス
        output_path: 出力 Markdown ファイルパス
        resolve_numbering: True の場合、スタイル定義の自動番号付けを解決して
            見出し・リストに番号を付与する。False の場合は番号なし。
        extract_textbox: True の場合、テキストボックスの内容を抽出する。
        textbox_min_chars: テキストボックスの最小文字数。これ以下はスキップ。
            0 でフィルタ無効。
        skip_sections: スキップ対象の見出しキーワードリスト。
            キーワードを含む見出しから次の同レベル以上の見出しまでをスキップする。

    Returns:
        (成功フラグ, heading_page_map, stats)。失敗時は (False, [], stats)。
        stats は Markdown 化しなかった要素のカウント (キー固定):
        images / headers_footers / footnotes / comments (int、無しは 0)。
    """
    if not os.path.exists(file_path):
        logger.error(f"ファイルが見つかりません: {file_path}")
        return False, [], _empty_stats()

    logger.info(f"パース開始 (DOCX直接): {file_path}")
    doc = Document(file_path)
    body = doc.element.body
    rels = doc.part.rels
    stats = _collect_stats(doc)

    # 自動番号付けリゾルバの初期化
    numbering_resolver = _NumberingResolver(doc) if resolve_numbering else None

    md_lines = []
    heading_page_map = []
    current_page = 1
    # 明示的改ページ直後の lastRenderedPageBreak 二重カウント防止フラグ
    _suppress_rendered_break = False

    # セクションスキップ状態
    skip_sections = skip_sections or []
    _skipping_section = False       # セクションスキップ中フラグ
    _skipping_section_level = None  # スキップ開始見出しのレベル

    def _ensure_page_marker() -> None:
        if md_lines and md_lines[-1] == f"<!-- page:{current_page} -->":
            return
        if not md_lines or md_lines[-1] != f"<!-- page:{current_page} -->":
            md_lines.append(f"<!-- page:{current_page} -->")

    for element in body:
        tag = element.tag.split("}")[-1] if "}" in element.tag else element.tag

        # ─── セクションブレーク (新規ページ) ───
        if tag == "sectPr":
            sect_type = element.find(qn("w:type"))
            if sect_type is not None:
                val = sect_type.get(qn("w:val"), "")
                if val in ("nextPage", "oddPage", "evenPage"):
                    current_page += 1
                    _suppress_rendered_break = True
            continue

        # ─── sdt (目次ブロック) ───
        if tag == "sdt":
            from lxml import etree
            xml_str = etree.tostring(element, encoding="unicode")
            if "TOC" in xml_str or "Table of Contents" in xml_str:
                continue

        # ─── テーブル ───
        if tag == "tbl":
            if _skipping_section:
                continue
            _ensure_page_marker()
            if md_lines and md_lines[-1] != "":
                md_lines.append("")
            md_lines.append(_table_to_markdown(element, doc))
            md_lines.append("")
            _suppress_rendered_break = False
            continue

        # ─── 段落 ───
        if tag != "p":
            continue

        # ページブレーク検出 (明示的 / レンダリング済みの二重カウントを防止)
        if _has_explicit_page_break(element):
            current_page += 1
            _suppress_rendered_break = True
        elif _has_rendered_page_break(element):
            if not _suppress_rendered_break:
                current_page += 1
            _suppress_rendered_break = False
        else:
            _suppress_rendered_break = False

        text = _extract_paragraph_text(element, rels)
        heading_level = _get_heading_level(doc, element)

        # 自動番号付けの解決 (カウンタ更新のため全段落で呼び出す)
        if numbering_resolver is not None:
            numbering_text, is_bullet = numbering_resolver.resolve(element)
        else:
            numbering_text, is_bullet = None, False

        # ─── TOC スキップ (常時有効) ───
        if _is_toc_paragraph(doc, element):
            continue

        # ─── セクションスキップ制御 ───
        if heading_level is not None:
            if _skipping_section:
                # 同レベル以上の見出しに到達 → スキップ終了
                if heading_level <= _skipping_section_level:
                    _skipping_section = False
                    _skipping_section_level = None
            if not _skipping_section and skip_sections:
                stripped_for_check = text.strip()
                if numbering_text:
                    stripped_for_check = f"{numbering_text} {stripped_for_check}"
                for keyword in skip_sections:
                    if keyword in stripped_for_check:
                        _skipping_section = True
                        _skipping_section_level = heading_level
                        logger.info(f"セクションスキップ開始: '{stripped_for_check}' (level={heading_level}, page={current_page})")
                        break

        if _skipping_section:
            continue

        # テキストボックスの抽出 (コードブロックで囲む)
        textbox_texts = (
            _extract_textbox_paragraphs(element, min_chars=textbox_min_chars, rels=rels)
            if extract_textbox
            else []
        )

        # 見出し
        if heading_level is not None:
            stripped = text.strip()
            if not stripped:
                # 見出しテキストが空でもテキストボックスがあれば出力
                if textbox_texts:
                    _ensure_page_marker()
                    for tb_text in textbox_texts:
                        if md_lines and md_lines[-1] != "":
                            md_lines.append("")
                        md_lines.append(tb_text)
                continue
            # スタイル経由の自動番号付けを先頭に付与
            if numbering_text:
                stripped = f"{numbering_text} {stripped}"
            prefix = "#" * min(heading_level, 6)
            _ensure_page_marker()
            if md_lines and md_lines[-1] != "":
                md_lines.append("")
            md_lines.append(f"{prefix} {stripped}")
            md_lines.append("")
            # 見出し・ページマップに追加
            heading_page_map.append(
                {
                    "heading": stripped,
                    "level": heading_level,
                    "page": current_page,
                }
            )
            # テキストボックスを見出し直後に追加
            for tb_text in textbox_texts:
                md_lines.append(tb_text)
                md_lines.append("")
            continue

        # リスト (番号付き / 箇条書き)
        if _is_list_paragraph(doc, element) or is_bullet or numbering_text is not None:
            indent_level = _get_list_level(element)
            indent = "  " * indent_level
            stripped = text.strip()
            if stripped:
                _ensure_page_marker()
                if numbering_text:
                    md_lines.append(f"{indent}- {numbering_text} {stripped}")
                else:
                    md_lines.append(f"{indent}- {stripped}")
            # テキストボックスをリスト項目の直後に追加
            for tb_text in textbox_texts:
                _ensure_page_marker()
                if md_lines and md_lines[-1] != "":
                    md_lines.append("")
                md_lines.append(tb_text)
            continue

        # 通常段落
        stripped = text.strip()
        if not stripped:
            # 空行でもテキストボックスがあれば出力
            if textbox_texts:
                _ensure_page_marker()
                for tb_text in textbox_texts:
                    if md_lines and md_lines[-1] != "":
                        md_lines.append("")
                    md_lines.append(tb_text)
            else:
                if md_lines and md_lines[-1] != "":
                    md_lines.append("")
            continue

        _ensure_page_marker()
        md_lines.append(stripped)
        # テキストボックスを段落直後に追加
        for tb_text in textbox_texts:
            _ensure_page_marker()
            if md_lines and md_lines[-1] != "":
                md_lines.append("")
            md_lines.append(tb_text)

    # 末尾の余分な空行を除去
    while md_lines and md_lines[-1] == "":
        md_lines.pop()

    # 見出しごとの終了ページ (page_end) を算出
    _fill_page_end(heading_page_map, last_page=current_page)

    markdown_output = "\n".join(md_lines) + "\n"

    if not markdown_output.strip():
        logger.warning(f"パース結果が空です: {file_path}")
        return False, heading_page_map, stats

    # 出力
    out_p = Path(output_path)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text(markdown_output, encoding="utf-8")
    logger.info(f"パース完了 (DOCX直接, 見出し{len(heading_page_map)}件): {output_path}")
    return True, heading_page_map, stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DOCX → Markdown 直接パーサー")
    parser.add_argument("--input_path", required=True, help="入力 DOCX ファイルパス")
    parser.add_argument("--output_path", required=True, help="出力 Markdown ファイルパス")
    parser.add_argument("--extract_meta", action="store_true", help="見出し・ページマップも抽出して表示")
    parser.add_argument("--no_numbering", action="store_true", help="自動番号付けを無効にする")
    parser.add_argument("--no_textbox", action="store_true", help="テキストボックス抽出を無効にする")
    parser.add_argument("--textbox_min_chars", type=int, default=_DEFAULT_TEXTBOX_MIN_CHARS,
                        help=f"テキストボックスの最小文字数 (デフォルト: {_DEFAULT_TEXTBOX_MIN_CHARS}、0でフィルタ無効)")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

    success, heading_map, _stats = parse_docx_to_markdown(
        args.input_path, args.output_path,
        resolve_numbering=not args.no_numbering,
        extract_textbox=not args.no_textbox,
        textbox_min_chars=args.textbox_min_chars,
    )

    if args.extract_meta:
        import json

        print(json.dumps(heading_map, ensure_ascii=False, indent=2))

    if not success:
        exit(1)
